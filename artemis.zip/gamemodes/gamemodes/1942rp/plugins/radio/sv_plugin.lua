
EncryptedFrequencies = EncryptedFrequencies or {}

do
	EncryptedFrequencies = {}
	local EncryptedFrequenciesRaw = util.JSONToTable(file.Read("encryptedfrequencies.txt") or "[]") or {}
	for k,v in pairs(EncryptedFrequenciesRaw) do
		EncryptedFrequencies[tostring(k)] = v
	end
	file.Write("encryptedfrequencies.txt", util.TableToJSON(EncryptedFrequencies))
end

netstream.Hook("delEncryptedFrequency", function(client, frequency)
	if (!client:IsAdmin()) then return end
	if (type(frequency) != "string") then return end
	EncryptedFrequencies[frequency] = nil
	file.Write("encryptedfrequencies.txt", util.TableToJSON(EncryptedFrequencies))
	netstream.Start(client, "EncryptedFreqMenu", EncryptedFrequencies)
end)

netstream.Hook("addEncryptedFrequency", function(client, frequency)
	if (!client:IsAdmin()) then return end
	if (type(frequency) != "string" || EncryptedFrequencies[frequency]) then return end
	EncryptedFrequencies[frequency] = {}
	file.Write("encryptedfrequencies.txt", util.TableToJSON(EncryptedFrequencies))
	netstream.Start(client, "EncryptedFreqMenu", EncryptedFrequencies, frequency)
end)


netstream.Hook("addEncryptedFrequencyFaction", function(client, frequency, faction)
	if (!client:IsAdmin()) then return end
	if (type(frequency) != "string" || type(faction) != "string" || !EncryptedFrequencies[frequency]) then return end
	EncryptedFrequencies[frequency][faction] = true
	file.Write("encryptedfrequencies.txt", util.TableToJSON(EncryptedFrequencies))
	netstream.Start(client, "EncryptedFreqMenu", EncryptedFrequencies, frequency)
end)

netstream.Hook("delEncryptedFrequencyFaction", function(client, frequency, faction)
	if (!client:IsAdmin()) then return end
	if (type(frequency) != "string" || type(faction) != "string" || !EncryptedFrequencies[frequency]) then return end
	EncryptedFrequencies[frequency][faction] = nil
	file.Write("encryptedfrequencies.txt", util.TableToJSON(EncryptedFrequencies))
	netstream.Start(client, "EncryptedFreqMenu", EncryptedFrequencies, frequency)
end)