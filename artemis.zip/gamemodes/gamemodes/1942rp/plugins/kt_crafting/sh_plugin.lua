local PLUGIN = PLUGIN
PLUGIN.name = "Crafting"
PLUGIN.author = "Black Tea / Killing Torcher"
PLUGIN.desc = "How about getting new foods in NutScript?"
PLUGIN.craftingData = {}


PLUGIN.CraftingTableModel = "models/comradebear/props/workstation/workstation_workbench.mdl"
PLUGIN.FurnaceModel = "models/props_c17/FurnitureFireplace001a.mdl"

PLUGIN.SmeltingSound = "player/general/flesh_burn.wav" // Should be a looping sound. Here's a list you don't have to use: https://wiki.facepunch.com/gmod/HL2_Sound_List
PLUGIN.SmeltingSoundLevel = 45 // Default: 75 - how far the sound travels
PLUGIN.SmeltingSoundPitch = 100 // Default: 100 - it's pitch
PLUGIN.SmeltingSoundVolume = 1 // Default 1 - it's volume where 1 = 100%

PLUGIN.SmeltingAddFuelSound = "items/ammocrate_open.wav"
PLUGIN.SmeltingAddFuelSoundLevel = 45
PLUGIN.SmeltingAddFuelSoundPitch = 100
PLUGIN.SmeltingAddFuelSoundVolume = 1


PLUGIN.Recipes = {
	{
		Name = "Vanilla Cake",
		Requirements = {
			["milk"] = 1,
			["egg"] = 3,
			["flour"] = 2,
			["bakingsoda"] = 1,
			["sugar"] = 2
		},
		Result = {
			["cake"] = 1
		}
	},
	{
		Name = "Dough",
		Requirements = {
			["watercup"] = 1,
			["flour"] = 1,
			["sugar"] = 1
		},
		Result = {
			["dough"] = 2
		}
	},
	{
		Name = "Cheese Pizza",
		Requirements = {
			["tomato"] = 1,
			["dough"] = 1,
			["cheese"] = 1
		},
		Result = {
			["pizza_cheese"] = 1
		}
	},
	{
		Name = "Apple Pie",
		Requirements = {
			["sugar"] = 1,
			["flour"] = 2,
			["apple"] = 3
		},
		Result = {
			["pie"] = 1
		}
	},
	{
		Name = "Electrical Wires",
		Requirements = {
			["copperbar"] = 1,
			["steelbar"] = 1,
		},
		Result = {
			["wire"] = 1
		}
	},
	{
		Name = "Ammunition",
		Requirements = {
			["gunpowder"] = 1,
			["steelbar"] = 2,
		},
		Result = {
			["ammo_generic"] = 1
		}
	},
	{
		Name = "Circuit Board",
		Requirements = {
			["wire"] = 1,
			["steelbar"] = 1,
			["screws"] = 1,
		},
		Result = {
			["circuitboard"] = 1
		}
	},
	{
		Name = "Gunpowder",
		Requirements = {
			["sulfurore"] = 1,
			["charcoal"] = 1,
		},
		Result = {
			["gunpowder"] = 2
		}
	},
	{
		Name = "Bolt Action",
		Requirements = {
			["screws"] = 1,
			["steelbar"] = 1,
		},
		Result = {
			["riflebolt"] = 1
		}
	},
	{
		Name = "Splint",
		Requirements = {
			["tape"] = 2,
			["copperbar"] = 1,
		},
		Result = {
			["splint"] = 1
		}
	},
	{
		Name = "Transponder",
		Requirements = {
			["circuitboard"] = 1,
			["wire"] = 1,
			["steel"] = 1,
		},
		Result = {
			["transponder"] = 1
		}
	},
	{
		Name = "Cables",
		Requirements = {
			["wire"] = 2,
			["tape"] = 1,
		},
		Result = {
			["cables"] = 1
		}
	},
	{
		Name = "Weapon Stock",
		Requirements = {
			["wood"] = 2,
			["screws"] = 1,
		},
		Result = {
			["stock"] = 1
		}
	},
	{
		Name = "Gewehr 43",
		Requirements = {
			["stock"] = 1,
			["glue"] = 1,
			["weaponparts"] = 1,
			["riflebolt"] = 1,
		},
		Result = {
			["gewehr"] = 1,
		}
	},
	{
		Name = "Screws",
		Requirements = {
			["steelbar"] = 2,
		},
		Result = {
			["screws"] = 1
		}
	},
	{
		Name = "Lemonade",
		Requirements = {
			["food_lemon_juice"] = 1,
			["sugar"] = 1,
		},
		Result = {
			["lemonade"] = 1
		}
	},
	{
		Name = "Lemon Juice",
		Requirements = {
			["food_lemon"] = 2,
		},
		Result = {
			["food_lemon_juice"] = 1
		}
	},
	{
		Name = "Receiver",
		Requirements = {
			["screws"] = 1,
			["steelbar"] = 2,
		},
		Result = {
			["receiver"] = 1
		}
	}
}

// Smelting Time is in seconds

PLUGIN.Smeltables = {
	["ironore"] = {
		Output = {
			["steelbar"] = 1,
		},
		SmeltingTime = 6,
	},
	["copperore"] = {
		Output = {
			["copperbar"] = 1,
		},
		SmeltingTime = 6,
	},
	["rawchicken"] = {
		Output = {
			["cookedchicken"] = 1,
		},
		SmeltingTime = 5,
	},
	["egg"] = {
		Output = {
			["friedegg"] = 1,
		},
		SmeltingTime = 3,
	},
	["wood"] = {
		Output = {
			["charcoal"] = 3,
		},
		SmeltingTime = 6,
	}
}

PLUGIN.FuelSources = {
	["coalore"] = 15,
	["cookingoil"] = 7,
	["charcoal"] = 10,
}

PLUGIN.MaxFuel = 100 // Fuel is in item-ticks (meaning more stuff being smelted = fuel used quicker)
PLUGIN.FurnaceTimeBetweenTicks = 1 // Time between ticks. Higher value = slower furnace.



local playerMeta = FindMetaTable("Player")
local entityMeta = FindMetaTable("Entity")

function playerMeta:canCraft(craftID)
	-- is player occuping the crafting table?
	-- is player is capable of crafting? (ex. not dead, not tied, etc...)
	-- does player has enough ingredients?
	-- has flags or perks that preventing player from crafting item?
	if (!self:Alive()) then
		return false
	end

	return true -- add some conditions
end

function playerMeta:doCraft(craftID)
	-- check the condition
	-- strip the ingredients
	-- add the result into player's inventory

	return true
end

function entityMeta:isCraftingTable()
	local class = self:GetClass()

	return (class == "nut_craftingtable")
end
-- Register HUD Bars.
if (CLIENT) then

	netstream.Hook("craftingTableOpen", function(entity, index)
		local inventory = nut.item.inventories[index]

		if (IsValid(entity) and inventory and inventory.slots) then
			nut.gui.inv1 = vgui.Create("nutInventory")
			nut.gui.inv1:ShowCloseButton(true)

			local inventory2 = LocalPlayer():getChar():getInv()

			if (inventory2) then
				nut.gui.inv1:setInventory(inventory2)
			end

			local panel = vgui.Create("nutInventory")
			panel:ShowCloseButton(true)
			panel:SetTitle("Crafting Table")
			panel:setInventory(inventory)
			panel:MoveLeftOf(nut.gui.inv1, 4)
			panel.OnClose = function(this)
				if (IsValid(nut.gui.inv1)) then
					nut.gui.inv1:Remove()
				end

				netstream.Start("invExit")
			end

			function nut.gui.inv1:OnClose()
				if (IsValid(panel)) then
					panel:Remove()
				end

				netstream.Start("invExit")
			end

			local actPanel = vgui.Create("DPanel")
			actPanel.Paint = function(panel)
				nut.util.drawBlur(panel, 10)
				surface.SetDrawColor(45, 45, 45, 200)
				surface.DrawRect(0, 0, panel:GetWide(), panel:GetTall())

				surface.SetDrawColor(nut.config.get("color"))
				surface.DrawOutlinedRect(0, 0, panel:GetWide(), panel:GetTall())
			end
			actPanel:SetDrawOnTop(true)
			actPanel:SetSize(panel:GetWide(), 100)
			actPanel.Think = function(this)
				if (!panel or !panel:IsValid() or !panel:IsVisible()) then
					this:Remove()

					return
				end

				local x, y = panel:GetPos()
				this:SetPos(x, y + panel:GetTall() + 5)
			end
			
			
			local textX, textY = actPanel:GetWide()/2, 35
			actPanel.PaintOver = function(self)
				local text = self.drawItem and self.drawText or "No Result"
				nut.util.drawText(text, textX, textY, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, #text > 20 and "nutMediumFont" or "nutBigFont")
				
				if (!self.nextCraftUpdate || CurTime() > self.nextCraftUpdate) then
					self.nextCraftUpdate = CurTime() + 0.2
					
					local blueprintCount, blueprints = 0, {}
					for k, v in pairs(PLUGIN.Recipes) do
						local hasMaterials = true
						for reqItem, reqCount in pairs(v.Requirements) do
							if (inventory:getItemCount(reqItem) < reqCount) then
								hasMaterials = false
								break
							end
						end
						
						if (hasMaterials) then
							table.insert(blueprints, v)
							blueprintCount = blueprintCount + 1
						end
					end
					
					if (blueprintCount <= 0) then
						self.drawItem = nil
						return
					elseif (blueprintCount == 1) then
						blueprint = blueprints[1]
					else
						local blueprintMax = 0
						for k,v in pairs(blueprints) do
							local reqCount = 0
							for k,v in pairs(v.Requirements) do
								reqCount = reqCount + v
							end
							
							if (!blueprint || reqCount > blueprintMax) then
								blueprint = v
								blueprintMax = reqCount
							end
						end
					end
					
					if (blueprint && blueprint.Result) then
						local found = false
						for k,v in pairs(blueprint.Result) do
							found = true
							self.drawItem = k
							self.drawText = blueprint.Name
							break
						end
						
						if (!found) then
							self.drawItem = nil
						end
					end
				end
			end

			local btn = actPanel:Add("DButton")
			btn:Dock(BOTTOM)
			btn:SetText("Craft Item")
			btn:SetColor(color_white)
			btn:DockMargin(5, 5, 5, 5)
			
			function btn.DoClick()
				netstream.Start("doCraft", entity, v)
			end

			nut.gui["inv"..index] = panel
		end
	end)
else
	local PLUGIN = PLUGIN

	function PLUGIN:LoadData()
		/*
		local savedTable = self:getData() or {}

		for k, v in ipairs(savedTable) do
			local stove = ents.Create(v.class)
			stove:SetPos(v.pos)
			stove:SetAngles(v.ang)
			stove:Spawn()
			stove:Activate()
		end
		*/
	end
	
	function PLUGIN:SaveData()
		/*
		local savedTable = {}

		for k, v in ipairs(ents.GetAll()) do
			if (v:isStove()) then
				table.insert(savedTable, {class = v:GetClass(), pos = v:GetPos(), ang = v:GetAngles()})
			end
		end

		self:setData(savedTable)
		*/
	end

	function PLUGIN:PlayerDeath(client)
	end

	function PLUGIN:PlayerSpawn(client)
	end
end