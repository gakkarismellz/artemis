ITEM.name = "Dough"
ITEM.model = "models/foodnhouseholditems/bread-1.mdl"
ITEM.desc = "A mound of dough made from scratch."
ITEM.uniqueID = "dough"
ITEM.noBusiness = true
