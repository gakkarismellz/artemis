ITEM.name = "Egg Carton"
ITEM.desc = "A carton of eggs."
ITEM.model = "models/foodnhouseholditems/egg_box4.mdl"
ITEM.price = 25
ITEM.uniqueid = "eggcarton"
ITEM.PackNum = 5

ITEM.functions.TakeOutEgg = {
	name = "Take egg from carton",
	onRun = function(item)
		local client = item.player
		local inv = client:getChar():getInv()
		item.PackNum = item:getData("eggLeft")

		if (item.PackNum > 1) then
			item:setData("eggLeft", item.PackNum - 1)

			inv:add("egg")
		else
			inv:add("egg")
			item:remove()
		end

		return false
	end
}

function ITEM:getDesc()
	local eggLeft = self:getData("eggLeft") or 5
	local description = "A carton of "..eggLeft.." eggs."

	if (eggLeft == 1) then
		description = "A lone egg in a carton."
	end

	return description
end