PLUGIN.name = "Generic Ammo"
PLUGIN.author = "Chancer"
PLUGIN.desc = "Ammo that can be loaded into any gun."