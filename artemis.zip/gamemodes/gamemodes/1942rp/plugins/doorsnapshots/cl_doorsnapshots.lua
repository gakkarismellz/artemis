nut.command.add("doorsnapshotsave", {
	syntax = "<string name>",
	adminOnly = true,
	onRun = function(client, arguments)

	end
})

nut.command.add("doorsnapshotload", {
	syntax = "<string name>",
	adminOnly = true,
	onRun = function(client, arguments)

	end
})


nut.command.add("findbaddoor", {
	syntax = "",
	adminOnly = true,
	onRun = function(client, arguments)
	end
})