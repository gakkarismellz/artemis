function WIKI:ShowTopic(panel, topic)
	local cc = {}

	--Showing back button
	cc.backbtn = panel:Add("DButton")
	cc.backbtn:SetText("Back")
	cc.backbtn:SetFont("WB_Small")
	cc.backbtn:SetColor(color_white)
	cc.backbtn:SetSize(60,30)
	cc.backbtn:SetAlpha(0)
	cc.backbtn:AlphaTo(255, 0.2, 0.2)
	function cc.backbtn:Paint(w,h)
		draw.RoundedBoxEx(4, 0, 0, w, h, Color(200,200,200,20), true, false, false, false)
	end
	function cc.backbtn:DoClick()
		for k,v in pairs(cc) do
			v:AlphaTo(0, 0.2, 0, function()
				v:Remove()
			end)
		end

		panel.pse:MoveTo(0, 0, 0.2, 0.2) --Move the nav panel back
		self:Remove()
	end

	--Admin functions
	if LocalPlayer():IsSuperAdmin() then
		cc.edit = panel:Add("DButton") --Edit Button
		cc.edit:SetText("Edit")
		cc.edit:SetFont("WB_Small")
		cc.edit:SetColor(color_white)
		cc.edit:SetSize(60,30)
		cc.edit:SetPos(60,0)
		function cc.edit:Paint(w,h)
			draw.RoundedBox(0, 0, 0, w, h, BC_NEUTRAL)
		end
		function cc.edit:DoClick()
			for k,v in pairs(cc) do
				v:Remove()

				panel.pse:Hide()
			end

			WIKI:pageEditor(panel, topic)
		end

		cc.del = panel:Add("DButton")
		cc.del:SetText("Remove")
		cc.del:SetFont("WB_Small")
		cc.del:SetColor(color_white)
		cc.del:SetSize(60,30)
		cc.del:SetPos(cc.backbtn:GetWide()+cc.edit:GetWide(),0)
		function cc.del:Paint(w,h)
			draw.RoundedBox(0,0,0,w,h,BC_WARNING)
		end
		function cc.del:DoClick()
			netstream.Start("IGDelTopic", topic.topicName)
			cc.backbtn:DoClick()
		end
	end

	--Moving search panel off-screen
	panel.pse:MoveTo(-panel.pse:GetWide(), 0, 0.2, 0, -0.01)

	--Topic Title
	cc.title = panel:Add("DLabel")
	cc.title.noFade = true
	cc.title:SetText(topic.topicName)
	cc.title:SetFont("WB_Large")
	cc.title:SetColor(color_white)
	cc.title:SizeToContents()
	cc.title:SetPos(panel:GetWide()/2-cc.title:GetWide()/2-120,60-cc.title:GetTall())

	cc.title:SetAlpha(0)
	cc.title:AlphaTo(255,1.2,0.1)
	cc.title:MoveTo(panel:GetWide()/2-cc.title:GetWide()/2, cc.title:GetY(), 0.3)

	--Displaying panels
	cc.scroll = panel:Add("DScrollPanel")
	cc.scroll:SetSize(panel:GetWide(), panel:GetTall()-80)
	cc.scroll:SetPos(0,80)
	cc.list = cc.scroll:Add("DIconLayout")
	cc.list:SetSize(cc.scroll:GetWide()-20,cc.scroll:GetTall()-20)
	cc.list:SetPos(10,10)
	cc.list:SetSpaceY(8)

	for k,v in pairs(topic) do
		if type(v) == "string" then continue end

		local sec = cc.list:Add("DPanel")
		function sec:Paint(w,h) end

		--Size the section
		if v.ns.half then
			sec:SetWide(cc.list:GetWide()/2)
		else
			sec:SetWide(cc.list:GetWide())
		end

		--TEXT
		if v.type == "text" then
			--Adds a little background to text.
			local mup = markup.Parse(v.content, w)
			local w,h = mup:Size()
			sec:SetTall(h+20)
			function sec:Paint(w,h)
				draw.RoundedBox(0, 0, 0, w, h, Color(50,50,50,80))
				mup:Draw(5, 10, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
			end
		end

		--IMAGE
		if v.type == "image" then
			local wi = WebMaterial(v.url, "smooth")
			wi:Download()

			--Change the sec height if the image height is set.
			if v.iw and v.ih then
				sec:SetTall(v.ih)
			end

			function sec:PaintOver(w,h) --Painting image
				local wm = wi:GetMaterial()
				if wi:IsDownloading() or not wi:GetMaterial() then --Showing "Loading..."
					surface.SetTextColor(255, 255, 255, 255)
					surface.SetTextPos(w/2, h/2)
					surface.DrawText("Loading Image...")
					return
				end

				--Drawing image (finally)
				local iw = v.iw or wm:Width()
				local ih = v.ih or wm:Height()
				surface.SetDrawColor(255, 255, 255)
				surface.SetMaterial(wm)
				surface.DrawTexturedRect(w/2-iw/2, h/2-ih/2, iw, ih)

				sec:SetTall(ih)
			end
		end

		--VIDEO
		if v.type == "video" then
			sec:SetTall(450)

			local w = (sec:GetTall()*16)/9
			sec.content = sec:Add("DHTML")
			sec.content:SetSize(w, sec:GetTall())
			sec.content:Center()

			local html = [[
				<style> overflow:hidden; </style>
				<video style="width:100%; height:95%;" loop muted autoplay><source src="$vid" type="video/webm"></video>
				]]
			sec.content:SetHTML(html:Replace("$vid", v.url))
		end
	end

	for k,v in pairs(cc) do
		if cc.noFade then continue end
		v:SetAlpha(0)
		v:AlphaTo(255,0.2,0.3)
	end
end
