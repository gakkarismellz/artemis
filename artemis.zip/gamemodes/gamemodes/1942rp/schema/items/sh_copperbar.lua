ITEM.name = "Copper Bar"
ITEM.model = "models/comradebear/props/codww2/resource/copper_bar_01.mdl"
ITEM.desc = "A bar of copper."
ITEM.uniqueID = "copperbar"
ITEM.noBusiness = true
