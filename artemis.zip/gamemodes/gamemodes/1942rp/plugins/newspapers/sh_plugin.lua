local PLUGIN = PLUGIN
PLUGIN.name = "Newspapers"
PLUGIN.author = "Zoephix"
PLUGIN.desc = "Adds newspapers."

PLUGIN.allowed = {
    ".PNG",
    ".JPG",
    ".JPEG",
    "drive.google.com",
    "docs.google.com"
}

nut.flag.add("N", "Access to spawn newspapers.")

nut.util.include("sv_plugin.lua")

if CLIENT then
    netstream.Hook("WriteNewspaper", function(newspaper)
        print(newspaper)
        Derma_StringRequest(
            "Newspaper",
            "Input URL to newspaper",
            "",
            function(text)
                if newspaper then
                    netstream.Start("WriteNewspaper", text, newspaper)
                else
                    netstream.Start("WriteNewspaper", text)
                end
            end,
            function(text)
                print(text)
            end
        )
    end)

    netstream.Hook("ShowNewspaper", function(text)
        local newspaper = vgui.Create("newspaper")
        newspaper:ShowNews(text)
    end)

    function PLUGIN:HUDPaint()
		local traceEnt = LocalPlayer():GetEyeTrace().Entity
		if not IsValid(traceEnt) then return end
		if traceEnt:GetClass() ~= "nut_newspaper" then return end

		local sizeX = 200
		local sizeY = 50

		local text = "USE to read"

		surface.SetDrawColor(Color(25, 25, 25, 150))
		surface.DrawRect(ScrW() * 0.5 - sizeX / 2, ScrH() * 0.5 - sizeY / 2, sizeX, sizeY)
		draw.SimpleText(text, "nutBigFont", ScrW() * 0.55 - (sizeX / 2), ScrH() * 0.503 - (sizeY / 2), Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
end
