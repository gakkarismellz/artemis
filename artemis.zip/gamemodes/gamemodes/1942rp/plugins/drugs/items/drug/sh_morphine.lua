ITEM.name = "Morphine"
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "A pain medication of the opiate variety which is found naturally in a number of plants and animals."
ITEM.addictChance = 80
ITEM.addiction = "drug_morp_w"
ITEM.effect = "drug_morp" --the effect