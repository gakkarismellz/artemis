include("shared.lua")

local PLUGIN = PLUGIN

function ENT:Draw()
	self:DrawModel()
end

function ENT:onShouldDrawEntityInfo()
	return true
end

function ENT:onDrawEntityInfo(alpha)
	local position = (self:LocalToWorld(self:OBBCenter()) + self:GetUp()*16):ToScreen()
	local x, y = position.x, position.y

	nut.util.drawText(L"Crafting Table", x, y, ColorAlpha(nut.config.get("color"), alpha), 1, 1, nil, alpha * 0.65)
	nut.util.drawText(L"A table used for assembling items.", x, y + 16, ColorAlpha(color_white, alpha), 1, 1, "nutSmallFont", alpha * 0.65)
end