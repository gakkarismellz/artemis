ITEM.name = "Luger Extended Barrel"
ITEM.desc = "An extended barrel specifically for the luger pistol."
ITEM.price = 200
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_attpack_luger"
