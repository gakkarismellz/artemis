ITEM.name = "Skull Mask"
ITEM.desc = "maskDesc"
ITEM.model = "models/Gibs/HGIBS.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.outfitCategory = "hat"
ITEM.price = 200
ITEM.worldModel = true
ITEM.pacData = {
	[1] = {
		["children"] = {
			[1] = {
				["children"] = {
				},
				["self"] = {
					["Angles"] = Angle(10.840716362, -69.425964355469, -89.468048095703),
					["Position"] = Vector(2.3395767211914, -1.6490173339844, -0.2786865234375),
					["ClassName"] = "model",
					["Model"] = "models/barneyhelmet_faceplate.mdl",
					["UniqueID"] = "4181992209",
				},
			},
		},
		["self"] = {
			["EditorExpand"] = true,
			["UniqueID"] = "1346796114",
			["ClassName"] = "group",
			["Name"] = "my outfit",
			["Description"] = "add parts to me!",
		},
	},
}