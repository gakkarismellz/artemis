--Business Ranks
BUSINESS_OWNER = 5
BUSINESS_SUPERADMIN = 4
BUSINESS_ADMIN = 3
BUSINESS_MODERATOR = 2
BUSINESS_TRUSTED = 1
BUSINESS_MEMBER = 0
BUSINESS_RANK_NAME = {
	[BUSINESS_OWNER] = "Owner",
	[BUSINESS_SUPERADMIN] = "Superadmin",
	[BUSINESS_ADMIN] = "Admin",
	[BUSINESS_MODERATOR] = "Moderator",
	[BUSINESS_TRUSTED] = "Trusted",
	[BUSINESS_MEMBER] = "Member",
}

--BUSINESS CATEGORIES
BCAT_FOOD = 1
BCAT_WEAPONS = 2
BUSINESS_CATEGORIES = {
	[BCAT_FOOD] = "Food",
	[BCAT_WEAPONS] = "Weapons"
}
--[[WEAPON CUSTOM SHIPMENT]]
local weaponShipmentConfig = {
	boatTime = 180 --The time for the boat to arrive
}
hook.Add("CustomProductShipment", "WeaponsCustomShipment", function(ply, biz, prod, amt)
/*  if prod.category == BCAT_WEAPONS then

  	if ply:getChar():getData("waitingForWepShipment") then
  		ply:notify("You're already waiting for a weapon shipment")
  		return
  	end

    local s = "Your shipment has been order, the boat will arrive in %s"
    s = string.format(s, string.FormattedTime(weaponShipmentConfig.boatTime, "%02i:%02i"))
    ply:notify(s)

  	--Creating timer for boat
  	local timerName = "weaponBoatShipment" .. os.time()
  	timer.Create(timerName, weaponShipmentConfig.boatTime, 1, function ()
  		local uid = prod.nutItem

  		local drugs = DRUGPLUGIN
  		drugs:SpawnBoat(uid, amt)

  		ply:notify("The boat arrived! Go get your weapon shipment!")
  	end)

  	--Taking money
  	local price = prod.price * amt
  	biz:setFunds(biz:getFunds() - price)

    return true
  end*/
end)
