do
	BizInvites = {}

	function nut.biz.Invited(char, business)
		if BizInvites[char:getID()] then
			for _, v in pairs(BizInvites[char:getID()]) do
				if v == business then return true end
			end
		end

		return false
	end

	netstream.Hook("nutBizCreate", function(client, data)
		local name, desc = data.name, data.desc

		if (not name) then
			client:notify("Business Name Missing")

			return
		elseif (not desc) then
			client:notify("Business Description Missing")

			return
		end

		if (name and name:len() < 8) then
			client:notify("Business Name Too Short")

			return
		elseif (desc and desc:len() < 16) then
			client:notify("Business Description Too Short")

			return
		end

		local char = client:getChar()

		if (char) then
			local bool, reason = hook.Run("CanCreateBusiness", client)

			if (bool == false) then
				if (reason) then
						client:notify(reason)
				end

				return
			end

			nut.biz.create(function(bizObject)
				bizObject:setOwner(char)
				bizObject:setName(data.name)
				bizObject:setData("desc", data.desc)
				bizObject:setData("type",  data.type)
				netstream.Start(client, "nutBizJoined")
				hook.Run("OnCreateBusiness", client, bizObject)
			end)
		end
	end)

	netstream.Hook("nutBizJoin", function(client, bizID)
		local char = client:getChar()

		if (char) then
			local biz = nut.biz.loaded[bizID]

			if (biz) then
				local bool, reason = char:canJoinBusiness()

				if (bool ~= false) then
						biz:addCharacter(char, BUSINESS_MEMBER)
						netstream.Start(client, "nutBizJoined")
				else
						client:notify(reason)
				end
			else
				client:notify("invalidBiz")
			end
		end
	end)

	netstream.Hook("bizHire", function(owner, client, bizID)
		local ownerChar = owner:getChar()

		if (ownerChar) then
			if (ownerChar:getBusiness() == -1) then
				owner:notify("You must be in a business to hire someone.")

				return
			elseif (ownerChar:getBusinessRank() ~= BUSINESS_OWNER) then
				owner:notify("You must be the business owner to hire someone.")

				return
			end
		else
			return
		end

		local char = client:getChar()

		if (char) then
			local biz = nut.biz.loaded[bizID]

			if (biz) then
				local bool, reason = char:canJoinBusiness()

				if (bool ~= false) then
					--[[biz:addCharacter(char, BUSINESS_MEMBER)
																	netstream.Start(client, "nutBizJoined")
																	netstream.Start(owner, "nutBizUpdateManager")]]
					--
					if nut.biz.Invited(char, bizID) then
						owner:notify("You have already send a invite to this player!")
					else
						if not BizInvites[char:getID()] then
							BizInvites[char:getID()] = {}
						end

						table.insert(BizInvites[char:getID()], bizID)
						owner:notify("You've invited '" .. char:getName() .. "' to join your business")
						client:notify("You have been invited to join '" .. biz:getName() .. "' type '/bizaccept " .. bizID .. "' to join.")
					end
				else
					owner:notify(reason)
				end
			else
				owner:notify("invalidBiz")
			end
		end
	end)

	netstream.Hook("nutBizExit", function(client)
		local char = client:getChar()

		if (char) then
			local biz = char:getBusinessInfo()

			if (biz) then
				local bool, reason = biz:removeCharacter(char, true)

				if (bool == false and reason) then
						client:notify(reason)
				else
						netstream.Start(client, "nutBizExited")
				end
			else
				client:notify("invalidBiz")
			end
		end
	end)

	netstream.Hook("nutBizDelete", function(client)
			local char = client:getChar()

			if (char) then
					local biz = char:getBusinessInfo()

					if (biz) then
							nut.biz.delete(biz:getID())
					else
							client:notify("invalidBiz")
					end
			end
	end)

	netstream.Hook("nutBizKick", function(client, target)
		local char = client:getChar()

		if (char) then
			local rank = char:getBusinessRank()

			if (rank >= BUSINESS_ADMIN) then
				local biz = char:getBusinessInfo()

				if (biz) then
					biz:removeCharacter(target)
					netstream.Start(client, "nutBizUpdateManager")
					local targetChar = nut.char.loaded[target]

					if (targetChar) then
						local targetClient = targetChar:getPlayer()

						if (IsValid(targetClient)) then
							netstream.Start(targetClient, "nutBizKicked")
						end
					end
				else
					client:notify("invalidBiz")
				end
			else
				client:notify("notBizAdmin")
			end
		end
	end)

	netstream.Hook("nutBizChangeSalary", function(client, id, salary)
		local char = client:getChar()

		if (char) then
			local rank = char:getBusinessRank()

			if (rank >= BUSINESS_ADMIN) then
				local biz = char:getBusinessInfo()

				if (biz) then
						biz:setData("salary_" .. id, math.Round(salary))
				else
						client:notify("invalidBiz")
				end
			else
				client:notify("notBizAdmin")
			end
		end
	end)

	netstream.Hook("nutBizAssign", function(client, target, targetRank)
		local char = client:getChar()

		if (char and target) then
			local rank = char:getBusinessRank()
			local targetChar = nut.char.loaded[target]
			if (targetChar and targetChar:getBusinessRank() == rank) then return end

			if (rank >= BUSINESS_SUPERADMIN) then
				local biz = char:getBusinessInfo()

				if (biz) then
					if (targetRank >= rank) then
						client:notify("noBizPermission")
					else
						local bool, reason = biz:adjustMemberRank(target, targetRank)

						if (bool) then
							client:notify("rankBizAdjusted")
							netstream.Start(client, "nutBizUpdateManager")

							if (targetChar) then
								local targetClient = targetChar:getPlayer()

								if (IsValid(targetClient)) then
										netstream.Start(targetClient, "nutBizUpdateManager")
								end
							end
						else
							client:notify(reason)
						end
					end
					--nut.biz.delete(biz:getID())
				else
					client:notify("invalidBiz")
				end
			else
				client:notify("notBizAdmin")
			end
		end
	end)

	netstream.Hook("nutBizFund", function(client, val)
		local char = client:getChar()

		if (char) then
			local rank = char:getBusinessRank()

			if (rank == BUSINESS_OWNER) then
				local biz = char:getBusinessInfo()

				if (biz) then
					local val = tonumber(val)

					if (val) then
						--val = math.Round(math.Round(val), 0, 2147483640) fixed it - damian
						val = math.Round(math.Clamp(val, 0, 2147483640))

						if (char:hasMoney(val)) then
							local fund = biz:getFunds()
							biz:addFunds(val)
							char:takeMoney(val)
							client:notify("bizAddedFund", nut.currency.get(val))
						else
							client:notify("cantAfford")
						end
					end
				else
					client:notify("invalidBiz")
				end
			else
				client:notify("notBizAdmin")
			end
		end
	end)

	netstream.Hook("nutBizTakeFund", function(client, val)
		local char = client:getChar()

		if (char) then
			local rank = char:getBusinessRank()

			if (rank == BUSINESS_OWNER) then
				local biz = char:getBusinessInfo()

				if (biz) then
					local val = tonumber(val)

					if (val) then
						val = math.Round(math.Clamp(val, 0, 2147483640))
						local funds = biz:getFunds()

						if (funds - val >= 0) then
							biz:addFunds(-val)
							char:giveMoney(val)
							client:notify("bizTakenFund", nut.currency.get(val))
						else
							client:notify("cantAffordBiz")
						end
					end
				else
					client:notify("invalidBiz")
				end
			else
				client:notify("notBizAdmin")
			end
		end
	end)

	netstream.Hook("nutBizChangeOwner", function(client, target) end)

	netstream.Hook("nutBizChangeValue", function(client, key, value)
		local char = client:getChar()

		if (char) then
			local biz = char:getBusinessInfo()

			if (biz) then
				local bool, reason = hook.Run("CanChangeBusinessVariable", client, key, value)

				if (bool) then
					if (key == "name") then
							biz:setName(value)
					else
							biz:setData(key, value)
					end
				else
					client:notify(reason)
				end
			else
				client:notify("invalidBiz")
			end
		end
	end)
end
