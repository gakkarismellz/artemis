local PLUGIN = PLUGIN or {}
PLUGIN.clothes = {}
PLUGIN.name = "Clothing System"
PLUGIN.desc = "Allows players to change their outfits."
PLUGIN.author = "Robert Bearson"

PLUGIN.strings = {
	nef = "You do not have enough funds!",
	wanswitchchange = "Are you sure you want to switch to Wardrobe before checking out?",
	outsavename = "What would you like to save your outfit as?",
	outsavesucc = "Outfit successfuly saved as '%s'!"
}

--Icons
resource.AddFile("materials/artemis/clothingicons/shirt_icon.png")
resource.AddFile("materials/artemis/clothingicons/tie_icon.png")
resource.AddFile("materials/artemis/clothingicons/changeclothes.png")

nut.util.include("sh_config.lua")
nut.util.include("hooks/sv_clothing_hooks.lua")
nut.util.include("hooks/sv_outfits_hooks.lua")

PLUGIN.defaultPrice = 30

local PLAYER = FindMetaTable("Player")
function PLAYER:GetAppliedBodygroups()
	local abg = {}
	for k,v in pairs(self:GetBodyGroups()) do
		if v.id > 0 then
			abg[v.id] = self:GetBodygroup(v.id)
		end
	end

	return abg
end

function PLUGIN:GetFullModel(curModel, newModel)
	--Getting the model class (male_01)
	local startp,endp = curModel:lower():find("male")
	local modelClass = curModel:sub(startp, endp+3)

	--Format newmodel
	local fullModel = newModel:format(modelClass)
	return fullModel
end

if CLIENT then
	function PLUGIN:GetPrice(t)
		local cc = self:getClothingConfig()
		if cc.prices and cc.prices[t] then
			return cc.prices[t]
		else
			return self.defaultPrice
		end
	end

	function PLUGIN:GetPreviewPayload()
		local pMdl = self.pMdl
		local payload = {}
		payload.model = pMdl:GetModel()
		payload.skin = pMdl:GetSkin()
		payload.bgs = {}
		for k,v in pairs(pMdl:GetBodyGroups()) do
			if v.id > 0 then
				payload.bgs[v.id] = pMdl:GetBodygroup(v.id)
			end
		end

		return payload
	end

	function PLUGIN:CheckForChanges()
		local ply = LocalPlayer()
		local pMdl = self.pMdl
		local payload = {}
		payload.bgs = {}

		--Check for bodygroup changes
		local changed = false
		local cham = 0 --Changes amount
		local bgs = pMdl:GetBodyGroups()
		local price = 0

		for k,v in pairs(bgs) do --Checking for bodygroup changes
			if v.id == 0 then continue end
			local owns = OwnsBodygroup(ply, pMdl:GetModel(), v.id, pMdl:GetBodygroup(v.id))
			if ply:GetModel() == pMdl:GetModel() then
				if pMdl:GetBodygroup(v.id) == 0 then continue end

				if pMdl:GetBodygroup(v.id) ~= ply:GetBodygroup(v.id) and not owns then
					cham = cham + 1
					changed = true

					price = price + self:GetPrice(v.name)
					payload.bgs[v.id] = pMdl:GetBodygroup(v.id) --Adding bodygroup to checkout
				end
			else
				if pMdl:GetBodygroup(v.id) > 0 and not owns then --Check if bodygroup actually changed (from default one)
					cham = cham + 1
					changed = true

					price = price + self:GetPrice(v.name)
					payload.bgs[v.id] = pMdl:GetBodygroup(v.id) --Adding bodygroup to checkout
				end
			end
		end

		--Check for skin change
		local skin = pMdl:GetSkin()
		local ownsSkin = OwnsSkin(ply, pMdl:GetModel(), skin)
		if skin ~= ply:GetSkin() and not ownsSkin then
			cham = cham + 1
			changed = true

			price = price + self:GetPrice("skin")
			payload.skin = skin
		end

		--Check for model change
		local ownsModel = OwnsModel(ply, pMdl:GetModel())
		if pMdl:GetModel() ~= ply:GetModel() and not ownsModel then
			cham = cham + 1
			changed = true

			price = price + self:GetPrice("model")
			payload.model = pMdl:GetModel()
		end
		
		if price == 0 then
			changed = false
			cham = 0
		end

		return changed, cham, price, payload
	end
end

concommand.Add("GetTruePos", function(ply)
	local pos = ply:GetPos()
	local ang = ply:GetAngles()
end)

--USEFUL FUNCTIONS
local function getCosTable(ply)
	if ply.getChar and ply:getChar() then
		local char = ply:getChar()
		local cost = char:getData("cosmetics", {})

		return char, cost
	else
		return nil
	end
end

if (SERVER) then
	function PLUGIN:SaveData()
		local data = {}
		local entList = ents.FindByClass("sh_cc_ent")

		for k,v in pairs(entList) do
			table.insert(data, {
				Pos = v:GetPos(),
				Angles = v:GetAngles(),
				Class = v:GetClass(),
				Model = v:GetModel()
			})
		end
		self:setData(data)
	end

	function PLUGIN:LoadData()
		local data = self:getData() or {}

		for k,v in pairs(data) do
			local ent = ents.Create(v.Class)
			ent:SetPos(v.Pos)
			ent:SetAngles(v.Angles)
			ent:Spawn()
			ent:SetModel(v.Model)
		end
	end
end


function OwnsBodygroup(ply, mdl, bgid, bgindex)
	local char, cost = getCosTable(ply)

	if char and cost then
		if not cost[mdl] then return nil end
		if cost[mdl].bgs[bgid] and cost[mdl].bgs[bgid][bgindex] then
			return true
		else
			return false
		end
	end
end

function OwnsSkin(ply, mdl, skinid)
	local char, cost = getCosTable(ply)
	if char and cost then
		if not cost[mdl] then return false end
		if cost[mdl].skins[skinid] then return true end
	end
end

function OwnsModel(ply, mdl)
	local char, cost = getCosTable(ply)
	if char and cost then
		if cost[mdl] then return true end
	end

	return false
end