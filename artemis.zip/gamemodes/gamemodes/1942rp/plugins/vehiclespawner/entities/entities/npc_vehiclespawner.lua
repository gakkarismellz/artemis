AddCSLuaFile()
ENT.Type = "anim"
ENT.PrintName = "Vehicle Spawner"
ENT.Author = "Zoephix"
ENT.Category = "Typhon NPCs"
ENT.Spawnable = true
ENT.AdminOnly = true

ENT.models = {
	"models/player/suits/male_01_closed_coat_tie.mdl",
	"models/player/suits/male_01_closed_tie.mdl",
	"models/player/suits/male_01_open.mdl",
	"models/player/suits/male_01_open_tie.mdl",
	"models/player/suits/male_01_open_waistcoat.mdl",
	"models/player/suits/male_01_shirt.mdl",
	"models/player/suits/male_01_shirt_tie.mdl",
	"models/player/suits/male_02_closed_coat_tie.mdl",
	"models/player/suits/male_02_closed_tie.mdl",
	"models/player/suits/male_02_open.mdl",
	"models/player/suits/male_02_open_tie.mdl",
	"models/player/suits/male_02_open_waistcoat.mdl",
	"models/player/suits/male_02_shirt.mdl",
	"models/player/suits/male_02_shirt_tie.mdl",
	"models/player/suits/male_03_closed_coat_tie.mdl",
	"models/player/suits/male_03_closed_tie.mdl",
	"models/player/suits/male_03_open.mdl",
	"models/player/suits/male_03_open_tie.mdl",
	"models/player/suits/male_03_open_waistcoat.mdl",
	"models/player/suits/male_03_shirt.mdl",
	"models/player/suits/male_03_shirt_tie.mdl",
	"models/player/suits/male_04_closed_coat_tie.mdl",
	"models/player/suits/male_04_closed_tie.mdl",
	"models/player/suits/male_04_open.mdl",
	"models/player/suits/male_04_open_tie.mdl",
	"models/player/suits/male_04_open_waistcoat.mdl",
	"models/player/suits/male_04_shirt.mdl",
	"models/player/suits/male_04_shirt_tie.mdl",
	"models/player/suits/male_05_closed_coat_tie.mdl",
	"models/player/suits/male_05_closed_tie.mdl",
	"models/player/suits/male_05_open.mdl",
	"models/player/suits/male_05_open_tie.mdl",
	"models/player/suits/male_05_open_waistcoat.mdl",
	"models/player/suits/male_05_shirt.mdl",
	"models/player/suits/male_05_shirt_tie.mdl",
	"models/player/suits/male_06_closed_coat_tie.mdl",
	"models/player/suits/male_06_closed_tie.mdl",
	"models/player/suits/male_06_open.mdl",
	"models/player/suits/male_06_open_tie.mdl",
	"models/player/suits/male_06_open_waistcoat.mdl",
	"models/player/suits/male_06_shirt.mdl",
	"models/player/suits/male_06_shirt_tie.mdl",
	"models/player/suits/male_07_closed_coat_tie.mdl",
	"models/player/suits/male_07_closed_tie.mdl",
	"models/player/suits/male_07_open.mdl",
	"models/player/suits/male_07_open_tie.mdl",
	"models/player/suits/male_07_open_waistcoat.mdl",
	"models/player/suits/male_07_shirt.mdl",
	"models/player/suits/male_07_shirt_tie.mdl",
	"models/player/suits/male_08_closed_coat_tie.mdl",
	"models/player/suits/male_08_closed_tie.mdl",
	"models/player/suits/male_08_open.mdl",
	"models/player/suits/male_08_open_tie.mdl",
	"models/player/suits/male_08_open_waistcoat.mdl",
	"models/player/suits/male_08_shirt.mdl",
	"models/player/suits/male_08_shirt_tie.mdl",
	"models/player/suits/male_09_closed_coat_tie.mdl",
	"models/player/suits/male_09_closed_tie.mdl",
	"models/player/suits/male_09_open.mdl",
	"models/player/suits/male_09_open_tie.mdl",
	"models/player/suits/male_09_open_waistcoat.mdl",
	"models/player/suits/male_09_shirt.mdl",
	"models/player/suits/male_09_shirt_tie.mdl"
}

function ENT:Initialize()
	if (SERVER) then
		self:SetModel(self.models[math.random(1, #self.models)])
		self:SetSkin(math.random(1, self:SkinCount()))
		self:SetUseType(SIMPLE_USE)
		self:SetMoveType(MOVETYPE_NONE)
		self:DrawShadow(true)
		self:SetSolid(SOLID_BBOX)
		self:PhysicsInit(SOLID_BBOX)
	end

	timer.Simple(1, function()
		if (IsValid(self)) then
			self:SetupAnimation()
		end
	end)

	local physicsObject = self:GetPhysicsObject()
	if (IsValid(physicsObject)) then
		physicsObject:EnableMotion(false)
	end
end

function ENT:SetupAnimation()
	for k, v in ipairs(self:GetSequenceList()) do
		if (v:lower():find("idle") and v ~= "idlenoise") then
			return self:ResetSequence(k)
		end
	end

	self:ResetSequence(4)
end

if (SERVER) then
	function ENT:Use(activator)
		netstream.Start(activator, "createVehicleSpawnerMenu")
	end
end

if (CLIENT) then
	local TEXT_OFFSET = Vector(0, 0, 20)
	local toScreen = FindMetaTable("Vector").ToScreen
	local colorAlpha = ColorAlpha
	local drawText = nut.util.drawText
	local configGet = nut.config.get

	ENT.DrawEntityInfo = true
	function ENT:onDrawEntityInfo(alpha)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)) + TEXT_OFFSET)
		local x, y = position.x, position.y

		drawText("Vehicle Spawner", x, y, colorAlpha(configGet("color"), alpha), 1, 1, nil, alpha * 0.65)
		-- drawText("desc", x, y + 16, colorAlpha(color_white, alpha), 1, 1, "nutSmallFont", alpha * 0.65)
	end
end
