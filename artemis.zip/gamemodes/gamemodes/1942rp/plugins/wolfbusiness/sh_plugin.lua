PLUGIN.name = "Business"
PLUGIN.author = "It's A Joke"
PLUGIN.desc = "Business plugin."
nut.biz = nut.biz or {}
nut.biz.loaded = nut.biz.loaded or {}

--Loading Config
nut.util.include("config/sh_names.lua")
nut.util.include("config/sh_products.lua")

--Loading hooks
nut.util.include("hooks/sv_menu_hooks.lua")
nut.util.include("hooks/sv_products_hooks.lua")
nut.util.include("hooks/sh_workplace.lua")

--Loading everything else ;)
nut.util.include("meta/sh_character.lua")
nut.util.include("meta/sh_business.lua")
nut.util.include("sh_biz_zones.lua")
nut.util.include("sv_database.lua")
nut.util.include("sv_biz_lib.lua")

nut.command.add("zoneman",{
	adminOnly = true,
	syntax = "",
	onRun = function(ply,args)
		netstream.Start(ply, "openZonesManager")
	end
})

--Allow managing business for CEO, president and vice-president
local managingRanks = {
	BUSINESS_OWNER,
	BUSINESS_SUPERADMIN,
	BUSINESS_ADMIN
}
function PLUGIN:CanPlayerManageBusiness(ply)
	local bRank = ply:getChar():getBusinessRank()
	for _, rank in pairs(managingRanks) do
		if rank == bRank then
			return true
		end
	end

	return false
end

nut.command.add("bizaccept", {
	syntax = "[int id]",
	onRun = function(ply, args)
		if not args[1] then return end
		local bizID = tonumber(args[1])

		local char = ply:getChar()
		local invited = nut.biz.Invited(char, bizID)
		if not invited then return end

		local biz = nut.biz.loaded[bizID]
		biz:addCharacter(char, BUSINESS_MEMBER)
		netstream.Start(client, "nutBizJoined")

		local owner = biz:getOwner()
		netstream.Start(owner, "nutBizUpdateManager")
	end
})

hook.Add("IsAccessBuilding", "BusinessZoneCheck", function ( ply )
	if not ply.getChar then return false end

	local char = ply:getChar()
	if not char then return end 

	local zone, id = ply:GetCurrentZone()
	if not zone then return false end


	local biz = char:getBusinessInfo()
	if biz then
		if biz.data and biz.data.bizZone then
			local bZone = biz.data.bizZone
			return (id and id == bZone)
		end
	end

	return false
end)

if (CLIENT) then
	--Adding the tab to the F1 menu
	hook.Add("CreateMenuButtons", "BusinessesTab", function(tabs)
		tabs["zbusiness"] = function(panel)
			if (hook.Run("BuildEntitiesMenu", panel) ~= false) then
			panel:Add("bizTab")
			end
		end
	end)
end

if (CLIENT) then
	-- business networkings
	do
		netstream.Hook("nutBizCharSync", function(data)
			for id, syncDat in pairs(data) do
				local character = nut.char.loaded[id]

				if (character) then
					character.vars.data = character.vars.data or {}
					character:getData()["business"] = syncDat[1]
					character:getData()["businessRank"] = syncDat[2]
				end
			end
		end)

		--sync specific server business data
		netstream.Hook("nutBizSyncAll", function(bizsData)
			if (bizsData) then
				for id, data in pairs(bizsData) do
					local biz = nut.biz.loaded[id] or nut.biz.new()

					for k, v in pairs(data) do
						biz[k] = v
					end

					nut.biz.loaded[id] = biz
				end
			end
		end)

		--sync specific server business data
		netstream.Hook("nutBizSync", function(id, data)
			if (data) then
				local biz = nut.biz.loaded[id] or nut.biz.new()

				for k, v in pairs(data) do
					biz[k] = v
				end

				nut.biz.loaded[id] = biz
			else
				print("got biz sync request but no data found")
			end
		end)

		netstream.Hook("nutBizRemove", function(id)
			nut.biz.loaded[id] = nil
		end)

		--sync
		netstream.Hook("nutBizSyncValue", function(id, key, value)
			if (nut.biz.loaded[id]) then
				nut.biz.loaded[id][key] = value
			end
		end)

		netstream.Hook("nutBizSyncData", function(id, key, value)
			--print(id, key, value)

			if (nut.biz.loaded[id] and nut.biz.loaded[id].data) then
				nut.biz.loaded[id].data[key] = value
			end
		end)

		netstream.Hook("nutBizSyncMember", function(id, rank, charID, isChange)
			local biz = nut.biz.loaded[id]

			if (biz) then
				if (isChange) then
					for i = BUSINESS_MEMBER, BUSINESS_OWNER do
						if (biz.members[i] and biz.members[i][charID]) then
							biz.members[i][charID] = nil
							break
						end
					end
				end

				local char = nut.char.loaded[charID]
				biz.members[rank] = biz.members[rank] or {}
				biz.members[rank][charID] = char and char:getName() or true
			end
		end)
	end
end

--Bills
bill_cooldown = bill_cooldown or {}
local cooldowntime = 60
nut.command.add("bill", {
	syntax = "<number amount>",
	onRun = function(ply, args)
		if bill_cooldown[ply] and bill_cooldown[ply] > CurTime() then
			ply:notify("You need to wait before using this command again.", NOT_CANCELLED)
			return
		end

		local target = ply:GetEyeTrace().Entity
		local amount = tonumber(args[1])

		if not IsValid(target) then
			target = ply
		end

		--Checking money
		if not target:getChar():hasMoney(amount) then
				ply:notify("The player doesn't have enough money.", NOT_CANCELLED)
			return
		end

		--Cooldown
		bill_cooldown[ply] = CurTime() + cooldowntime

		--Net stuff/Proccessing
		netstream.Start(target, "bizSendBill", ply, amount)
		netstream.Hook("bizPayBill", function(payer, payee, amount)
			if not payee:getChar():hasMoney(amount) then return end --This shouldn't happen...
			payer:getChar():takeMoney(amount)
			payee:getChar():giveMoney(amount)
		end)
	end
	-- onCanRun = function(ply, args)
	-- 	local et = ply:GetEyeTrace().Entity
	-- 	if not IsValid(et) or not IsPlayer(et) then
	-- 		return false
	-- 	end

	-- 	return true
	-- end
})

if CLIENT then
	netstream.Hook("bizSendBill", function(sender, amount)
		Choice_Request("Do you want to pay this bill of " .. amount .. nut.currency.symbol .. " sent by: " .. sender:Nick(), function()
			netstream.Start("bizPayBill", sender, amount)
		end)
	end)
end

local registerZone = function()
	zones.RegisterClass(BUSINESS_ZONE_NAME, Color(255, 255, 0))
end

if (zones) then
	registerZone()
else
	hook.Add("OnZoneSystemInitialized", "BIZZONE", registerZone)
end
