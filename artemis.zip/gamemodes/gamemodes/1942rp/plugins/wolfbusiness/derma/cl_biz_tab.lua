--Something I need to move later
function bizName(self)
  local fd = group()
  fd.fdName = self:Add("DLabel") --Business Name
  fd.fdName:SetFont("fdName")
  fd.fdName:SetColor(color_white)
  fd.fdName:SetText("")
  function fd.fdName:PerformLayout()
    self:SizeToContents()
  end

  fd.fdDesc = self:Add("DLabel") --Business Desc
  fd.fdDesc:SetFont("fdDesc")
  fd.fdDesc:SetColor(color_white)
  fd.fdDesc:SetText("")
  function fd.fdDesc:PerformLayout(w, h)
    self:SizeToContents()
    self:SetPos(fd.fdName:GetX(), fd.fdName:GetY() + fd.fdName:GetTall())
  end

  return fd
end

--Special Fonts **
surface.CreateFont("fdName", {
  font = "Fira Mono",
  size = 45
})
surface.CreateFont("fdDesc", {
  font = "Fira Mono",
  size = 25
})

local PANEL = {}
function PANEL:Init()
  self:SetSize(self:GetParent():GetSize())
  local bsInfo = LocalPlayer():getChar():getBusinessInfo()
  
  if not bsInfo then
    local wel = group()
    wel.hint = self:Add("DLabel")
    wel.hint:SetText("You do not have a business yet! Create one here")
    wel.hint:SetFont("WB_Medium")
    wel.hint:SetColor(color_white)
    wel.hint:SizeToContents()
    wel.hint:CenterVertical(0.25)
    wel.hint:CenterHorizontal()

    wel.create = self:Add("WButton")
    wel.create:SetText("Create Business")
    wel.create:SetSize(200,35)
    wel.create.round = 6
    function wel.create:PerformLayout(w, h)
      wel.create:Center()
    end
    function wel.create.DoClick(this)
      if not LocalPlayer():getChar():getInv():hasItem("permit_biz") then
        this:Flash("First you need a permit!", BC_CRITICAL, 2, true)
        return
      end

      wel:FadeOutRem(function()
        local fd = bizName(self)
        local cr = group()
        cr.panel = self:Add("DPanel")
        cr.panel:SetSize(self:GetWide(), self:GetTall() * 0.40)
        cr.panel:SetPos(0, self:GetTall() - cr.panel:GetTall())
        function cr.panel:Paint(w,h)
          draw.RoundedBoxEx(4, 0, 0, w, h, color_white, false, false, true, true)
        end

        --Form
        cr.form = cr.panel:Add("WolfForm")
        cr.form:SetSize(cr.panel:GetWide() * 0.35, cr.panel:GetTall() - 10)
        cr.form:Center()
        local name = cr.form:AddTextEntry("Business Name")
        local desc = cr.form:AddTextEntry("Business Description")
        local bizType = cr.form:AddComboBox()
        bizType:SetValue("Business Type")
        
        --Add business types
        for k,v in pairs(BUSINESS_CATEGORIES) do
          bizType:AddChoice(v, k)
        end
        
        --Done Button
        cr.done = cr.form:Add("WButton")
        cr.done:SetSize(cr.form:GetWide(), 30)
        cr.done:SetPos(0,cr.form:GetTall() - cr.done:GetTall())
        cr.done:SetText("Done")
        cr.done:SetTextColor(color_white)
        cr.done:SetAccentColor(BC_NEUTRAL)
        cr.done.creating = false
        function cr.done:Paint(w,h)
          if self:GetDisabled() and not self.creating then
            draw.RoundedBox(4, 0, 0, w, h, Color(160,160,160))
          else
            draw.RoundedBox(4, 0, 0, w, h, self.color)
          end
        end
        function cr.done:Think()
          if name:GetText() != name.placeholder and 
          desc:GetText() != desc.placeholder and
          bizType:GetSelected() then
            self:SetDisabled(false)
          end
        end
        function cr.done.DoClick(this)
          local name, desc = name:GetText(),desc:GetText()
          if (name and name:len() < 8) then
            this:Flash("Name Too Short", BC_CRITICAL, 2, true)
            return
          elseif (desc and desc:len() < 16) then
            this:Flash("Description Too Short", BC_CRITICAL, 2, true)
            return
          end

          --Creating Business
          this.creating = true
          this:SetDisabled(true)
          this:SetText("Creating...")
          
          local _,id = bizType:GetSelected()

          netstream.Start("nutBizCreate", { --Telling server the good news
            name = name,
            desc = desc,
            type = id
          })

          --Switching to managing panel
          cr:FadeOutRem()
          fd:FadeOutRem()
          bizManage(self)
        end

        --Fancy Display I guess
        function fd.fdName:PerformLayout(w, h)
          self:SizeToContents()
          self:CenterVertical(0.30)
          self:CenterHorizontal()
        end
        function fd.fdName:Think()
          if name:GetText() != name.placeholder then
            self:SetText(name:GetText())
          end
        end
        function fd.fdDesc:Think()
          if desc:GetText() != desc.placeholder then
            self:SetText(desc:GetText())
          end
        end

        cr:FadeIn()
      end)
    end

    --Business List Button
    wel.blist = self:Add("WButton")
    wel.blist:SetText("Business List")
    wel.blist:SetSize(wel.create:GetSize())
    wel.blist.round = 6
    wel.blist:Center()
    wel.blist:SetPos(wel.blist:GetX(), wel.blist:GetY() + wel.blist:GetTall() + 10)
  else
    bizManage(self)
  end
end

function PANEL:Paint(w,h)
  surface.SetDrawColor(0, 0, 0, 15)
  surface.DrawRect(0, 0, w, h)
end
vgui.Register("bizTab", PANEL, "DPanel")

--Being able to open old version
concommand.Add("oldBizOpen", function()
  local frame = vgui.Create("WolfFrame")
  frame:SetSize(ScrW()-200, ScrH()-200)
  frame:Center()
  frame:MakePopup()

  local wp = frame:GetWorkPanel()
  
  local nutBusiness = LocalPlayer():getChar():getBusinessInfo()
  
  if (nutBusiness) then
    wp:Add("nutBizManager")
  else
    wp:Add("nutBizJoiner")
  end
end)