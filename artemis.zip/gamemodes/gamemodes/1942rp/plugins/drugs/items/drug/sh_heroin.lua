ITEM.name = "Heroin"
ITEM.model = "models/props_junk/garbage_bag001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.desc = "An opioid most commonly used as a recreational drug for its euphoric effects."
ITEM.addictChance = 90
ITEM.addiction = "drug_hero_w"
ITEM.effect = "drug_hero" --the effect