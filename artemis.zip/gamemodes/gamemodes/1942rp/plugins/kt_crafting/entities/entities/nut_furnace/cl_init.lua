include("shared.lua")

local PLUGIN = PLUGIN

function ENT:Draw()
	self:DrawModel()
end

function ENT:onShouldDrawEntityInfo()
	return true
end

function ENT:onDrawEntityInfo(alpha)
	local position = (self:LocalToWorld(self:OBBCenter()) + self:GetUp()*16):ToScreen()
	local x, y = position.x, position.y

	nut.util.drawText(L"Furnace", x, y, ColorAlpha(nut.config.get("color"), alpha), 1, 1, nil, alpha * 0.65)
	nut.util.drawText(L"The furnace is used to smelt items.", x, y + 16, ColorAlpha(color_white, alpha), 1, 1, "nutSmallFont", alpha * 0.65)
end


netstream.Hook("furnaceOpen", function(entity, index, index2)
	local inventory = nut.item.inventories[index]
	local fuelInventory = nut.item.inventories[index2]
	if (!IsValid(entity) || !inventory || !inventory.slots) then return end
	
	nut.gui.inv1 = vgui.Create("nutInventory")
	nut.gui.inv1:ShowCloseButton(true)

	local inventory2 = LocalPlayer():getChar():getInv()

	if (inventory2) then
		nut.gui.inv1:setInventory(inventory2)
	end

	local mainInventoryMenu = vgui.Create("nutInventory")
	mainInventoryMenu:ShowCloseButton(false)
	mainInventoryMenu:SetTitle("Furnace Inventory")
	mainInventoryMenu.addIconEx = mainInventoryMenu.addIcon
	mainInventoryMenu.addIcon = function(panel, model, x, y, w, h, skin)
		local icon = mainInventoryMenu.addIconEx(panel, model, x, y, w, h, skin)
		local itemID = icon.itemTable:getID()
		
		
		if (PLUGIN.Smeltables[icon.itemTable.uniqueID]) then
			icon.PaintOver = function(itemPanel, w, h)
				local smeltingTable = entity:getNetVar("SmeltingTable", {})
				local smeltedAmount = smeltingTable[itemID] or 0
				surface.SetDrawColor(247, 108, 57, 100)
				surface.DrawRect(0, 0, w * math.Clamp(smeltedAmount / PLUGIN.Smeltables[icon.itemTable.uniqueID].SmeltingTime, 0, 1), h)
			end
		else
			icon.PaintOver = function() end
		end
		
		return icon
	end
	mainInventoryMenu:setInventory(inventory)
	mainInventoryMenu:MoveLeftOf(nut.gui.inv1, 4)
	
	local fuelInventoryMenu = vgui.Create("nutInventory")
	fuelInventoryMenu:SetTitle("Fuel")
	fuelInventoryMenu:setInventory(fuelInventory)
	fuelInventoryMenu:MoveBelow(nut.gui.inv1, 5)
	fuelInventoryMenu:ShowCloseButton(false)
	fuelInventoryMenu.PaintOverEx = fuelInventoryMenu.PaintOver
	fuelInventoryMenu.PaintOver = function(panel, w, h)
		local fuelPercentage = entity:getNetVar("fuelAmount", 0) / PLUGIN.MaxFuel
		surface.SetDrawColor(247, 108, 57, 100)
		surface.DrawRect(0, 0, w * fuelPercentage, h)
	
		fuelInventoryMenu.PaintOverEx(panel, w, h)
	end
	
	function nut.gui.inv1:OnClose()
		if (IsValid(mainInventoryMenu)) then
			mainInventoryMenu:Remove()
		end
		
		if (IsValid(fuelInventoryMenu)) then
			fuelInventoryMenu:Remove()
		end

		netstream.Start("invExit")
	end
	
	nut.gui["inv"..index] = mainInventoryMenu
	nut.gui["inv"..index2] = fuelInventoryMenu
end)