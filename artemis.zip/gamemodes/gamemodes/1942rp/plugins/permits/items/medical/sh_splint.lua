ITEM.name = "Splint"
ITEM.model = "models/illusion/eftcontainers/splint.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.healAmount = 20
ITEM.healSeconds = 1
ITEM.price = 5
ITEM.desc = "A splint to treat leg injury."
ITEM.uniqueID = "medical_splint"
ITEM.permit = "permit_med"
ITEM.FixLegs = true

