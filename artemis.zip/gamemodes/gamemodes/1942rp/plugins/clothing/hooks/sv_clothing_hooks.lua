local PLUGIN = PLUGIN
local function applyCosmetic(ply, payload)
	--Applying bodygroups, skin & model to player
	if payload.skin then ply:SetSkin(payload.skin) end
	if payload.model then ply:getChar():setModel(payload.model) end
	for k,v in pairs(payload.bgs) do
		ply:SetBodygroup(k, v)
	end

	--Saving bodygroup to char
	ply:getChar():setData("groups", payload.bgs)
	ply:getChar():setData("skin", payload.skin or 0)

	ply:notify("Applied!", NOT_SUCCESS)
end

netstream.Hook("buyCosmetics", function(ply, payload)
	local char = ply:getChar()
	local price = payload.price

	if char:hasMoney(price) then
		char:takeMoney(price) --Remove money

		--Save to char data
		local emptyCos = {}
		local boughtCos = char:getData("cosmetics", {})

		--Formating the bought bodygroup table
		local bgt = {}
		for k,v in pairs(payload.bgs) do
			bgt[k] = bgt[k] or {}
			bgt[k][v] = true
		end

		local skins = {}
		if payload.skin then
			skins[payload.skin] = true
		end

		--Building cosmetic table (to merge)
		emptyCos[payload.model] = {
			bgs = bgt,
			skins = skins
		}

		--Merging and saving to char
		boughtCos = table.Merge(boughtCos, emptyCos)
		char:setData("cosmetics", boughtCos) --Set data on the char

		--Counting items
		payload.price = nil
		local count = 0
		count = count + table.Count(payload.bgs)

		if payload.skin ~= nil then count = count + 1 end
		if payload.model ~= nil then count = count + 1 end

		--Applying bodygroups, skin and model to the player
		applyCosmetic(ply, payload)

		--Notifying player of his purchase
		ply:notify("You just bought " .. count .. " cosmetic items for " .. nut.currency.get(price) .. "!", NOT_SUCCESS)

		netstream.Start(ply, "updateShopTab")
	else
		ply:notify(PLUGIN.strings.nef, NOT_ERROR)
	end
end)

netstream.Hook("applyCosmetic", function(ply, payload)
	applyCosmetic(ply, payload)
end)

concommand.Remove("getcos")
concommand.Remove("clearcos")
concommand.Remove("getouts")
concommand.Remove("clearouts")
concommand.Remove("getgroups")