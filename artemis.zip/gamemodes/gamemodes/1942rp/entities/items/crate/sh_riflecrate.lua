ITEM.name = "블랙티 소총스킨 상자"
ITEM.desc = "블랙티가 유통하는 소총스킨 상자"
ITEM.model = "models/props_c17/SuitCase_Passenger_Physics.mdl"
ITEM.price = 45000
ITEM.prizePool = {
    -- add weapons  
}