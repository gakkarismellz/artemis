ITEM.name = "Newspaper"
ITEM.uniqueID = "newspaper"
ITEM.desc = "A piece of paper containing news."

ITEM.functions.Write = {
    name = "Write",
    tip = "Write",
    icon = "icon16/newspaper_add.png",
    onRun = function(item)
        if (SERVER) then
            netstream.Start(item.player, "WriteNewspaper")
        end

        return true
    end,
}
