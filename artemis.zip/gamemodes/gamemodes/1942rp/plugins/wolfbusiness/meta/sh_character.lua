local CHAR = nut.meta.character

function CHAR:getBusiness()
    return self:getData("business", -1)
end

function CHAR:getBusinessRank(def)
    return self:getData("businessRank", def)
end

function CHAR:getBusinessInfo()
    return nut.biz.loaded[self:getBusiness()]
end

function CHAR:setBusiness(bizID)
    return self:setData("business", bizID)
end

function CHAR:canJoinBusiness(bizID)
    local biz = nut.biz.loaded[bizID]

    if (biz) then
        local client = self:getPlayer()

        if (client) then
            if (self:getBusinessInfo()) then
                return false, "bizJoined"
            end
            
            return hook.Run("PlayerCanJoinBusiness", client, biz)
        end
    end
end

function CHAR:isLeader()
    local biz = nut.biz.get(self:getBusiness())

    if (biz) then
        return biz.ownerID == self:getID()
    end
end