include("shared.lua")
AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")

local originalPlugin = PLUGIN
function ENT:Initialize()
	self:SetModel(originalPlugin.FurnaceModel)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:setNetVar("active", false)
	self:SetUseType(SIMPLE_USE)
	self.receivers = {}
	local physicsObject = self:GetPhysicsObject()

	if (IsValid(physicsObject)) then
		physicsObject:Wake()
	end

	nut.item.newInv(0, "nutFurnace", function(inventory)
		self:setInventory(inventory)
		inventory.noBags = true

		function inventory:onCanTransfer(client, oldX, oldY, x, y, newInvID)
			return hook.Run("StorageCanTransfer", inventory, client, oldX, oldY, x, y, newInvID)
		end
	end)
	
	nut.item.newInv(0, "nutFurnaceFuel", function(inventory)
		self:setFuelInventory(inventory)
		inventory.noBags = true

		function inventory:onCanTransfer(client, oldX, oldY, x, y, newInvID)
			return hook.Run("StorageCanTransfer", inventory, client, oldX, oldY, x, y, newInvID)
		end
	end)
end

function ENT:activate(client)

end

function ENT:setInventory(inventory)
	if (inventory) then
		self:setNetVar("id", inventory:getID())
		
		inventory.onAuthorizeTransfer = function(inventory, client, oldInventory, item)
			if (IsValid(client) and IsValid(self) and self.receivers[client]) then
				return true
			end
		end

		inventory.getReceiver = function(inventory)
			local receivers = {}

			for k, v in pairs(self.receivers) do
				if (IsValid(k)) then
					receivers[#receivers + 1] = k
				end
			end

			return #receivers > 0 and receivers or nil
		end
	end
end

function ENT:setFuelInventory(inventory)
	if (inventory) then
		self:setNetVar("fuelID", inventory:getID())
		
		inventory.onAuthorizeTransfer = function(inventory, client, oldInventory, item)
			if (IsValid(client) and IsValid(self) and self.receivers[client]) then
				return true
			end
		end

		inventory.getReceiver = function(inventory)
			local receivers = {}

			for k, v in pairs(self.receivers) do
				if (IsValid(k)) then
					receivers[#receivers + 1] = k
				end
			end

			return #receivers > 0 and receivers or nil
		end
	end
end

function ENT:getFuelInv()
	return nut.item.inventories[self:getNetVar("fuelID")]
end

function ENT:Use(activator)
	local inventory = self:getInv()
	local fuelInventory = self:getFuelInv()
	if (inventory and (activator.nutNextOpen or 0) < CurTime()) then
		if (activator:getChar()) then
			activator:setAction("Opening...", 1, function()
				if (activator:GetPos():Distance(self:GetPos()) <= 100) then
					self.receivers[activator] = true
					activator.nutBagEntity = self
					
					fuelInventory:sync(activator)
					inventory:sync(activator)
					netstream.Start(activator, "furnaceOpen", self, inventory:getID(), fuelInventory:getID())
				end
			end)
		end

		activator.nutNextOpen = CurTime() + 1.5
	end
end

function ENT:OnRemove()	
	local index = self:getNetVar("id")
	local index2 = self:getNetVar("fuelID")
	
	if (!nut.shuttingDown and !self.nutIsSafe and index and index2) then
		local item = nut.item.inventories[index]
		
		if (item) then
			nut.item.inventories[index] = nil

			nut.db.query("DELETE FROM nut_items WHERE _invID = "..index)
			nut.db.query("DELETE FROM nut_inventories WHERE _invID = "..index)
			
			hook.Run("StorageItemRemoved", self, item)
		end
		
		local item2 = nut.item.inventories[index2]
		if (item2) then
			nut.item.inventories[index2] = nil

			nut.db.query("DELETE FROM nut_items WHERE _invID = "..index2)
			nut.db.query("DELETE FROM nut_inventories WHERE _invID = "..index2)
			
			hook.Run("StorageItemRemoved", self, item2)
		end
	end
end

function ENT:getInv()
	return nut.item.inventories[self:getNetVar("id", 0)]
end

function ENT:Think()
	if (self.NextThinkTime && self.NextThinkTime > CurTime()) then return end
	
	local mainInventroyID = self:getNetVar("id")
	local fuelInventoryID = self:getNetVar("fuelID")
	if (!mainInventroyID || !fuelInventoryID) then
		self.NextThinkTime = CurTime() + 1
		print(tostring(self) .. ": mainInventroyID or fuelInventoryID are not set!")
		return 
	end
	
	local mainInventroy = nut.item.inventories[mainInventroyID]
	local fuelInventory = nut.item.inventories[fuelInventoryID]
	
	if (!mainInventroy || !fuelInventory) then
		self.NextThinkTime = CurTime() + 1
		print(tostring(self) .. ": mainInventroy or fuelInventory are nil!")
		return 
	end

	// Handling Fuel
	
	local hasAddedFuel = false
	for k,v in pairs(fuelInventory:getItems()) do
		local fuelAmount = self:getNetVar("fuelAmount", 0)
		local addFuelAmount = originalPlugin.FuelSources[v.uniqueID]
		if (addFuelAmount && fuelAmount + addFuelAmount <= originalPlugin.MaxFuel) then
			self:setNetVar("fuelAmount", fuelAmount + addFuelAmount)
			v:remove()
			hasAddedFuel = true
		end
	end
	
	if (hasAddedFuel && originalPlugin.SmeltingAddFuelSound && originalPlugin.SmeltingAddFuelSound != "") then
		self:EmitSound(originalPlugin.SmeltingAddFuelSound, originalPlugin.SmeltingAddFuelSoundLevel, originalPlugin.SmeltingAddFuelSoundPitch, originalPlugin.SmeltingAddFuelSoundVolume, nil, nil, nil)
	end
	
	self.SmeltingTable = self.SmeltingTable or {}
	local smeltedSomething = false
	local mainInventoryItems = {}
	for k,v in pairs(mainInventroy:getItems()) do
		local smeltingData = originalPlugin.Smeltables[v.uniqueID]
		if (!smeltingData) then continue end
		
		local itemID = v:getID()
		mainInventoryItems[itemID] = true
		
		if (!self.SmeltingTable[itemID]) then
			self.SmeltingTable[itemID] = 0
		end
		
		if (self.SmeltingTable[itemID] == smeltingData.SmeltingTime) then
			v:remove()

			for resultItem, resultCount in pairs(smeltingData.Output) do
				for i=1, resultCount do
					local succ, res = mainInventroy:add(resultItem)

					if (!succ) then
						if (res == "noSpace") then
							nut.item.spawn(resultItem, self:GetPos() + self:GetUp() * 15)
						end
					end
				end
			end
		end
		
		local fuelAmount = self:getNetVar("fuelAmount", 0)
		if (fuelAmount > 1) then
			self:setNetVar("fuelAmount", fuelAmount - 1)
			self.SmeltingTable[itemID] = self.SmeltingTable[itemID] + 1
			smeltedSomething = true
		end
	end
	
	if (originalPlugin.SmeltingSound && originalPlugin.SmeltingSound != "") then
		if (self.isPlayingSound && !smeltedSomething) then
			self.isPlayingSound = false
			self:StopSound(originalPlugin.SmeltingSound)
		elseif (!self.isPlayingSound && smeltedSomething) then
			self.isPlayingSound = true
			self:EmitSound(originalPlugin.SmeltingSound, originalPlugin.SmeltingSoundLevel, originalPlugin.SmeltingSoundPitch, originalPlugin.SmeltingSoundVolume, nil, nil, nil)
		end
	end
	for k,v in pairs(self.SmeltingTable) do
		if (!mainInventoryItems[k]) then
			self.SmeltingTable[k] = nil
		end
	end
	
	self:setNetVar("SmeltingTable", self.SmeltingTable)
	self.NextThinkTime = CurTime() + originalPlugin.FurnaceTimeBetweenTicks
end