ITEM.name = "Weapon Camouflages"
ITEM.desc = "From traditional camouflage to solid gold."
ITEM.price = 800
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_attpack_finishes"
