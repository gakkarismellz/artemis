NAME = "English"

LANGUAGE = {
	talkGive = "%s has given %s to %s.",
	talkTake = "%s has taken %s away from %s."
}