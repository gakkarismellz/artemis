ITEM.name = "Circuit Board"
ITEM.desc = "A metal circuit board with copper wiring."
ITEM.price = 25
ITEM.model = "models/illusion/eftcontainers/militaryboard.mdl"
ITEM.category = "Other"
ITEM.noBusiness = true
ITEM.uniqueID = "circuitboard"
