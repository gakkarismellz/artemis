CLOTHING = {}
BASE_CLOTHING_PRICE = 150
BASE_ADDITIVE_PRICE = 50

local tiemat = Material("artemis/clothingicons/tie_icon.png", "mips")
local shirtmat = Material("artemis/clothingicons/shirt_icon.png", "mips")

CLOTHING["models/player/suits"] = {
	name = "Suits",
	shorts = { --Replace bodygroups codename with normal people text ;p
		["ties"] = "Ties",
		["ClosedCollar_White"] = "Closed Collar Shirt",
		["ClosedCollar_Short_White"] = "Closed Collar Shirt, Short Sleeves",
		["ClosedCollar_Rolled_White"] = "Closed Collar Shirt, Rolled Sleeves",
		["OpenCollar_White"] = "Open Collar Shirt",
		["OpenCollar_Short_White"] = "Open Collar Shirt, Short Sleeves",
		["OpenCollar_Rolled_White"] = "Open Collar Shirt, Rolled Sleeves"
	},
	prices = {
		["ties"] = 10,
		["skin"] = 150,
		["body"] = 50,
		["model"] = 250
	},
	icons = {
		["body"] = shirtmat,
		["ties"] = tiemat
	},
	skins = {
		"Brown and Gray",
		"Dark gray and Black",
		"Dark Gray and light Gray, Black Shirt",
		"Dark Gray and Light Gray, White Shirt",
		"Dark Gray and Dark Gray, White Shirt",
		"Dark Gray and Dark Gray, Copper Shirt",
		"Dark Gray and Dark Gray, Black Shirt",
		"Dark Red and Light Gray, White Shirt"
	},
	models = {
		["Closed Coat Tie"] = "models/player/suits/%s_closed_coat_tie.mdl",
		["Closed Tie"] = "models/player/suits/%s_closed_tie.mdl",
		["Open Suit no Tie"] = "models/player/suits/%s_open.mdl",
		["Open Suit with Tie"] = "models/player/suits/%s_open_tie.mdl",
		["Open Suit with Waistcoat"] = "models/player/suits/%s_open_waistcoat.mdl",
		["Shirt"] = "models/player/suits/%s_shirt.mdl",
		["Shirt with Tie"] = "models/player/suits/%s_shirt_tie.mdl"
	}
}
