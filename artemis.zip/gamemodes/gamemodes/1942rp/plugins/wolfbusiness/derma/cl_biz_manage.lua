local PLUGIN = PLUGIN
function bizManage(panel)
  local biz = LocalPlayer():getChar():getBusinessInfo()
  if not biz then return end

  if not PLUGIN:CanPlayerManageBusiness(LocalPlayer()) then
    bizShowWorkerMenu(panel)
    return
  end

  --Business Name Display
  local fd = bizName(panel, biz)
  fd.fdName:SetText(biz.name)
  fd.fdDesc:SetText(biz.data.desc)

  --Business Info Part
  local pinfo = group()
  pinfo.panel = panel:Add("DPanel")
  pinfo.panel:SetSize(panel:GetWide()/2, 150)
  pinfo.panel:SetPos(panel:GetWide()/2,0)
  pinfo.panel.Paint = nil

  pinfo.panel.totm = pinfo.panel:Add("WLabel")
  pinfo.panel.totm:SetText("Total Member(s): " .. biz:getMemberCount())
  pinfo.panel.totm:SetColor(color_white)
  pinfo.panel.totm:FontSize("Large")

  pinfo.panel.funds = pinfo.panel:Add("WLabel")
  pinfo.panel.funds:SetText("Total Funds:" .. biz:getFunds() .. nut.currency.symbol)
  pinfo.panel.funds:SetColor(color_white)
  pinfo.panel.funds:SetPos(pinfo.panel.totm:GetX(), pinfo.panel.totm:GetY() + pinfo.panel.totm:GetTall() + 10)
  pinfo.panel.funds:FontSize("Large")

  --Zone Options
  -- print("zone", biz:getData("bizZone"))
  /*local zone = zones.List[biz:getData("bizZone", nil)]
  if zone and zone.name and zone.price then
    local zoneInfo = pinfo.panel:Add("WLabel")
    zoneInfo:SetText("Zone:")
    zoneInfo:FontSize("Large")
    zoneInfo:SetColor(color_white)
    follow(zoneInfo, pinfo.panel.funds)

    local zonename = pinfo.panel:Add("WLabel")
    zonename:SetText(zone.name)
    zonename:SetColor(color_white)
    follow(zonename, zoneInfo)

    local zonesell = pinfo.panel:Add("WButton")
    zonesell:SetSize(64,25)
    zonesell:SetText("Sell Zone")
    follow(zonesell, zonename, RIGHT)
    function zonesell:DoClick()
      Choice_Request("Are you sure you want to sell your zone?", function()
        netstream.Start("bizSellZone", zone)
      end)
    end
  end*/
  pinfo:FadeIn()

  --Workable Panel
  local wp = group()
  local m = group()
  m.panel = panel:Add("DPanel")
  function m.panel:Paint(w,h)
    draw.RoundedBoxEx(4, 0, 0, w, h, color_white, false, false, true, true)
  end
  m.panel:SetSize(panel:GetWide(), panel:GetTall() * 0.75)
  m.panel:SetPos(0, panel:GetTall() - m.panel:GetTall())

  --Tabs Panel
  local tabsPanel = m.panel:Add("WTabs")
  tabsPanel:SetSize(m.panel:GetSize())
  tabsPanel:SetTextColor(color_black)
  tabsPanel:SetButtonColor(Color(240,240,240))
  function tabsPanel.OnTabSwitch() --Implementing group fading
    return group()
  end
  function tabsPanel.OnTabSwitchFinished(g)
    g:FadeIn()
  end
  
  tabsPanel:AddTab("Products", bizShowProducts)
  tabsPanel:AddTab("Inventory", bizInventory)

  tabsPanel:AddTab(L"memberInfo", function(panel, g)
    g.hire = panel:Add("DButton")
    g.hire:SetText("Hire New Staff")
    g.hire:SetSize(panel:GetWide(), 30)
    g.hire:SetPos(0,panel:GetTall() - g.hire:GetTall())
    g.hire:SetColorAcc(Color(230,230,230))
    g.hire:SetupHover(BC_NEUTRAL)
    function g.hire:Paint(w,h)
      if not self:IsHovered() then
        self:SetTextColor(color_black)
      else
        self:SetTextColor(color_white)
      end
      draw.RoundedBoxEx(4, 0, 0, w, h, self.color, false, false, true, true)
    end
    function g.hire:DoClick()
      showHireMenu(biz)
    end

    g.scroll = panel:Add("DScrollPanel")
    g.scroll:SetSize(panel:GetWide(),panel:GetTall() - g.hire:GetTall())
    g.list = g.scroll:Add("DIconLayout")
    g.list:SetSize(g.scroll:GetSize())
    local function rankCatPnl(title)
      local cat = g.list:Add("DLabel")
      cat:SetText(title)
      cat:SetFont("WB_Large")
      cat:SetColor(color_white)
      cat:SetSize(g.list:GetWide(), 40)
      cat:SetContentAlignment(5)
      function cat:Paint(w,h)
        surface.SetDrawColor(60,60,60)
        surface.DrawRect(0, 0, w, h)
      end

      return cat
    end
    local function memPnl(name, rank, charID)
      local char = nut.char.loaded[charID]
	  local charName
	  if (char) then
		charName = char:getName()
	  else
	    charName = "[Offline Char #" .. charID .. "]"
	  end
      local mem = g.list:Add("DPanel")
      mem:SetSize(g.list:GetWide(), 30)
      function mem:Paint(w,h)
        surface.SetDrawColor(235, 235, 235)
        surface.DrawRect(0, 0, w, h)
      end

      --Member's Name
      mem.name = mem:Add("DLabel")
      mem.name:SetText(charName)
      mem.name:SetFont("WB_Medium")
      mem.name:SetColor(color_black)
      mem.name:SizeToContents()
      mem.name:SetPos(10,0)
      mem.name:CenterVertical()

      --Control Buttons
      local function AddBtn(name)
        local b = mem:Add("DButton")
        b:SetText(name)
        b:SetFont("WB_Small")
        b:SetColor(color_black)
        b:SetSize(150, mem:GetTall())
        b:SetContentAlignment(5)
        b:SetColorAcc(Color(225,225,225))
        b:SetupHover(Color(230,230,230))
        function b:Paint(w,h)
          surface.SetDrawColor(self.color)
          surface.DrawRect(0, 0, w, h)
        end

        return b
      end

      if PLUGIN:CanPlayerManageBusiness(LocalPlayer()) then
        local setrank = AddBtn("Set Rank")
        setrank:Dock(RIGHT)
        function setrank:DoClick()
          local menu = DermaMenu()
          for rankID, rankLang in SortedPairs(BUSINESS_RANK_NAME) do --Adding all ranks
            menu:AddOption(L(rankLang), function()
              netstream.Start("nutBizAssign", charID, rankID)
            end)
          end
          menu:Open()
        end

        local kick = AddBtn("Kick")
        kick:Dock(RIGHT)
        function kick:DoClick()
          netstream.Start("nutBizKick", charID)
        end
      end
    end

    --Adding rank categories and members
    for rank,memlist in pairs(biz.members) do
      rankCatPnl(L(BUSINESS_RANK_NAME[rank]))
      for charID,name in pairs(memlist) do
        memPnl(name, rank, charID)
      end
    end
  end)

  tabsPanel:AddTab(L"config", function(panel, g)
    local stabs = panel:Add("WTabs")
    stabs:SetSize(panel:GetWide(), panel:GetTall())
    stabs:SetTextColor(color_white)
    stabs:SetButtonColor(Color(60,60,60))
    stabs:SetPanelType("DListLayout")

    stabs:AddTab("General", function(wp)
      local function addOption(title, btnTitle, doClick)
        local pnl = wp:Add("DPanel")
        pnl:SetSize(wp:GetWide(), 30)
        function pnl:Paint(w,h)
          surface.SetDrawColor(245, 245, 245)
          surface.DrawRect(0, 0, w, h)
        end

        pnl.label = pnl:Add("DLabel")
        pnl.label:SetText(title)
        pnl.label:SetFont("WB_Small")
        pnl.label:SetColor(color_black)
        pnl.label:SizeToContents()
        pnl.label:SetPos(15,0)
        pnl.label:CenterVertical()

        pnl.btn = pnl:Add("DButton")
        pnl.btn:SetText(btnTitle)
        pnl.btn:SetSize(80, pnl:GetTall()-6)
        pnl.btn:SetPos(pnl:GetWide()-pnl.btn:GetWide()-15, 3)
        pnl.btn:SetFont("WB_Small")
        pnl.btn:SetColor(color_black)
        pnl.btn:SetColorAcc(Color(235,235,235))
        pnl.btn:SetupHover(BC_NEUTRAL)
        function pnl.btn:Paint(w,h)
          if self:IsHovered() then
            self:SetTextColor(color_white)
          else
            self:SetTextColor(color_black)
          end
          draw.RoundedBox(4, 0, 0, w, h, self.color)
        end
        pnl.btn.DoClick = doClick

        return pnl
      end

      --Adding all the options
      wp.addFunds = addOption("Add funds to your business", "Add Funds", function()
        String_Request("How much funds do you want to add?", function(val)
          val = tonumber(val)
          if not val then return end

          netstream.Start("nutBizFund", val)
        end, nil, true)
      end)

      wp.takeFunds = addOption("Take back funds you've put in your business", "Take Funds", function(val)
        String_Request("How much funds do you want to take back?", function(val)
          val = tonumber(val)
          if not val then return end

          netstream.Start("nutBizTakeFund", val)
        end, nil, false)
      end)

      wp.changeName = addOption("Change the name of your business", "Change", function(val)
        String_Request("Enter your new business name", function(val)
          netstream.Start("nutBizChangeValue", "name", val)
        end)
      end)
      wp.close = addOption("Close down your business", "Close", function(val)
        Choice_Request("Are you sure you want to close down?", function()
          netstream.Start("nutBizDelete")
        end)
      end)
    end)

    stabs:AddTab("Salaries",function(wp)
      for rank,name in pairs(BUSINESS_RANK_NAME) do
        local r = wp:Add("DPanel")
        r:SetSize(wp:GetWide(),40)
        function r:Paint(w,h)
          draw.RoundedBox(0, 0, 0, w, h, Color(245,245,245))
        end

        r.name = r:Add("DLabel")
        r.name:SetText(L(name))
        r.name:SetFont("WB_Small")
        r.name:SetColor(color_black)
        r.name:SizeToContents()
        r.name:SetPos(15)
        r.name:CenterVertical()

        r.slider = r:Add("DNumSlider")
        r.slider:SetWide(r:GetWide() * 0.70)
        r.slider:CenterHorizontal(0.65)
        r.slider.Label:Dock(0)
        r.slider.Label:SetSize(0, 0)
        r.slider.TextArea:SetFont("WB_Small")
        r.slider.TextArea:SetTextColor(color_black)
        r.slider.TextArea:DockMargin(10, 0, 0, 0)
        r.slider:SetMin(0)
        r.slider:SetMax(1000)
        r.slider:SetValue(biz:getData("salary_" .. rank, 0))
        r.slider:SetDecimals(0)
        r.slider.OnValueChanged = function()
          if timer.Exists("bizChangedSalary" .. rank) then
            timer.Start("bizChangedSalary" .. rank)
          else
            timer.Create("bizChangedSalary" .. rank, 1.5, 1, function()
              if not r.slider and IsValid(r.slider) then return end
              local val = math.Round(r.slider:GetValue())

              netstream.Start("nutBizChangeSalary", rank, val)
              nut.util.notify("You changed the " .. L(name) .. "'s salary to " .. val .. nut.currency.symbol, LocalPlayer())
            end)
          end
        end
      end

      wp.hint = wp:Add("DLabel")
      wp.hint:SetText("When you've changed the salary wait a little bit for it to apply!")
      wp.hint:SetFont("WB_Small")
      wp.hint:SetColor(color_white)
      wp.hint:SetSize(wp:GetWide(), 30)
      wp.hint:SetContentAlignment(5)
      function wp.hint:Paint(w,h)
        draw.RoundedBoxEx(4, 0, 0, w, h, BC_NEUTRAL, false, false, true, true)
      end
    end)

    stabs:ShowTabs()
  end)
  tabsPanel:ShowTabs() --Show Tabs

  --Fade in the tabs and shit
  m:FadeIn()
end

--TODO: Revise this menu
function showHireMenu(biz)
  CreateOverBlur(function(blur)
    local frame = vgui.Create("WolfFrame")
    frame:SetSize(300, 350)
    frame:Center()
    frame:MakePopup()
    frame:SetTitle("Choose your applicants")
    function frame:OnRemove()
      blur:SmoothClose()
    end

    local wp = frame:GetWorkPanel()
    local scroll = wp:Add("DScrollPanel")
    scroll:SetSize(wp:GetSize())
    local list = scroll:Add("DIconLayout")
    list:SetSize(scroll:GetSize())

    for k,v in pairs(player.GetAll()) do
      if v == LocalPlayer() then continue end
      local p = list:Add("DPanel")
      p:SetSize(list:GetWide(), 35)
      function p:Paint(w,h)
        if k % 2 != 0 then
          surface.SetDrawColor(35,35,35)
        else
          surface.SetDrawColor(40,40,40)
        end
        surface.DrawRect(0, 0, w, h)
      end

      p.name = p:Add("DLabel")
      p.name:SetText(v:Nick())
      p.name:SetFont("WB_Small")
      p.name:SetColor(color_white)
      p.name:SizeToContents()
      p.name:SetPos(10,0)
      p.name:CenterVertical()

      p.hire = p:Add("DButton")
      p.hire.rounded = 4
      p.hire:SetText("Hire")
      p.hire:SetFont("WB_Small")
      p.hire:SetColor(color_white)
      p.hire:SetSize(0,p:GetTall()-6)
      p.hire:SizeToContentsX(15)
      p.hire:SetColorAcc(BC_NEUTRAL)
      p.hire:SetupHover(getHovCol(BC_NEUTRAL))
      p.hire.Paint = BGENERALPAINT
      function p.hire:PerformLayout(w,h)
        self:SetPos(p:GetWide()-w-10, 3)
      end
      function p.hire:DoClick()
        self:SizeTo(self:GetWide()+10, self:GetTall(), 0.2, 0)
        self:SetDisabled(true)
        self:SetColorAcc(BC_AGREE)
        self:SetupHover(getHovCol(BC_AGREE))
        self:SetText("HIRED!")

        netstream.Start("bizHire", v, biz.id)
      end
    end
  end)
end
