ITEM.name = "Tan Suit"
ITEM.desc = "A decent quality suit."
ITEM.category = "Outfit"
ITEM.model = "models/props_junk/cardboard_box003b.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 400
ITEM.outfitCategory = "suit"

ITEM.newSkin = 8

--models/player/suits/male_01_closed_tie.mdl
