local BUSINESS = nut.biz.meta or {}
BUSINESS.__index = BUSINESS
debug.getregistry().Business = BUSINESS -- hi mark

function nut.biz.new()
	return setmetatable({
		name = "Unnamed Business",
		id = 0,
		members = {},
		level = 1,
		funds = BUSINESS_INITIAL_FUNDS,
		experience = 0,
		data = {}
	}, BUSINESS)
end

if (SERVER) then
	function BUSINESS:__tostring()
		return "Business [" .. self.id .. "]"
	end

	function BUSINESS:__eq(other)
		return self.id == other.id
	end

	function BUSINESS:addCharacter(char, rank, callback)
		local charID = (type(char) == "table" and char:getID() or char)

		if (charID) then
			rank = rank or BUSINESS_MEMBER
			self.members[rank] = self.members[rank] or {}
			self.members[rank][charID] = targetChar and targetChar:getName() or true -- member level.

			local targetChar = nut.char.loaded[charID]
			if (SERVER and targetChar) then
				char:setData("business", self.id, nil, player.GetAll())
				char:setData("businessRank", rank, nil, player.GetAll())
			end

			local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time())

			nut.db.updateTable({
				_lastModify = timeStamp,
			}, nil, "business", "_id = " .. self.id)

			nut.db.insertTable({
				_bizID = self.id,
				_charID = charID,
				_rank = rank,
				_name = char:getName()
			}, function(succ)
			end, "busimembers")

			netstream.Start(player.GetAll(), "nutBizSyncMember", self.id, rank, charID)
		else
			return false, "noChar"
		end

		return false, "invalidRequest"
	end

	function BUSINESS:setName(text)
		self.name = text

		local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time())
		nut.db.updateTable({
			_name = text,
			_lastModify = timeStamp,
		}, nil, "business", "_id = " .. self.id)

		netstream.Start(player.GetAll(), "nutBizSyncValue", self.id, "name", text)
	end

	function BUSINESS:adjustMemberRank(charID, rank)
		local charID = (type(char) == "table" and char:getID() or charID)

		if (charID) then
			for i = BUSINESS_MEMBER, BUSINESS_OWNER do
				if (self.members[i] and self.members[i][charID]) then
					self.members[i][charID] = nil
					break
				end
			end

			self.members[rank] = self.members[rank] or {}
			self.members[rank][charID] = targetChar and targetChar:getName() or true

			local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time())
			nut.db.updateTable({
				_rank = rank,
				_lastModify = timeStamp,
			}, nil, "busimembers", "_charID = " .. charID .. " AND _bizID = " .. self.id)

			netstream.Start(player.GetAll(), "nutBizSyncMember", self.id, rank, charID, true)

			local targetChar = nut.char.loaded[charID]
			if (targetChar and SERVER) then
				targetChar:setData("businessRank", rank, nil, player.GetAll())
			end

			return true
		else
			return false, "noMember"
		end

		return false, "invalidRequest"
	end

	function BUSINESS:removeCharacter(char, leaving)
		local charID = (type(char) == "table" and char:getID() or char)

		local removed = false
		for i = BUSINESS_MEMBER, (BUSINESS_OWNER - (leaving and 0 or 1)) do
			if (self.members[i] and self.members[i][charID]) then
				self.members[i][charID] = nil

				removed = true
				break
			end
		end

		if (removed) then
			local targetChar = nut.char.loaded[charID]
			if (targetChar and SERVER) then
				targetChar:setData("business", nil, nil, player.GetAll())
				targetChar:setData("businessRank", nil, nil, player.GetAll())
			end

			nut.db.query("DELETE FROM nut_busimembers WHERE _charID = " .. charID)
			self:sync()

			if (BUSINESS_REMOVE_EMPTY_GROUP == true and self:getMemberCount() == 0) then
				nut.biz.delete(self.id)
			end

			return true
		else
			return false, "noMember"
		end

		return false, "invalidRequest"
	end

	function BUSINESS:setData(key, value)
		self.data[key] = value

		local serialized = pon.encode(self.data)
		local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time())

		nut.db.updateTable({
			_data = serialized,
			_lastModify = timeStamp,
		}, nil, "business", "_id = " .. self.id)

		netstream.Start(player.GetAll(), "nutBizSyncData", self.id, key, value)
	end

	function BUSINESS:setExperience(amt)
		self.experience = amt

		local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time())
		nut.db.updateTable({
			_experience = amt,
			_lastModify = timeStamp,
		}, nil, "business", "_id = " .. self.id)

		netstream.Start(player.GetAll(), "nutBizSyncValue", self.id, "experience", amt)
	end

	function BUSINESS:setLevel(amt)
		self.level = amt

		local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time())
		nut.db.updateTable({
			_level = amt,
			_lastModify = timeStamp,
		}, nil, "business", "_id = " .. self.id)

		netstream.Start(player.GetAll(), "nutBizSyncValue", self.id, "level", amt)
	end

	function BUSINESS:setFunds(amt)
		self.funds = amt

		local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time())
		nut.db.updateTable({
			_funds = amt,
			_lastModify = timeStamp,
		}, nil, "business", "_id = " .. self.id)

		netstream.Start(player.GetAll(), "nutBizSyncValue", self.id, "funds", amt)
	end

	function BUSINESS:setOwner(char)
		if (char) then
			self:addCharacter(char, BUSINESS_OWNER)
		end
	end

	function BUSINESS:addExperience(amt)
		self:setExperience(self:getExperience() + amt)
	end

	function BUSINESS:addLevel(amt)
		self:setLevel(self:getLevel() + amt)
	end

	function BUSINESS:addFunds(amt)
		self:setFunds(self:getFunds() + amt)
	end
end

function BUSINESS:getMemberCount()
	local count = 0

	for i = BUSINESS_MEMBER, BUSINESS_OWNER do
		if (self.members[i]) then
			count = count + table.Count(self.members[i])
		end
	end

	return count
end

function BUSINESS:getID()
	return self.id
end

function BUSINESS:getName()
	return self.name
end

function BUSINESS:getMemberRank(char)
	return char:getData("businessRank", BUSINESS_MEMBER)
end

function BUSINESS:getMembersByRank(rank)
	return self.members[rank] or {}
end

function BUSINESS:getMember(charID)
	local member, rank

	for i = BUSINESS_MEMBER, BUSINESS_OWNER do
		if (self.members[i] and self.members[i][charID]) then
			member = self.members[i][charID]
			rank = i

			break;
		end
	end

	return member, rank
end

function BUSINESS:getData(key, default)
	return self.data[key] or default
end

function BUSINESS:getExperience()
	return self.experience
end

function BUSINESS:getLevel()
	return self.level
end

function BUSINESS:getFunds()
	return tonumber(self.funds)
end

-- returns
function BUSINESS:getOwner(char)
	local that

	if (self.members[BUSINESS_OWNER]) then
		for k, v in pairs(self.members[BUSINESS_OWNER]) do
			that = k
			break;
		end
	end

	char = nut.char.loaded[that]

	if (char) then
		local client = char:getPlayer()

		if (IsValid(client)) then
			return client
		end

		return char
	end

	return that
end

do
	function BUSINESS:unsync(recipient)
		recipient = recipient or player.GetAll()

		netstream.Start(recipient, "nutBizRemove", self.id)
	end

	function BUSINESS:sync(recipient)
		recipient = recipient or player.GetAll()

		netstream.Start(recipient, "nutBizSync", self.id, self:getSyncInfo())
	end

	--client does not need every data.
	function BUSINESS:getSyncInfo()
		return {
			name = self.name,
			level = self.level,
			experience = self.experience,
			id = self.id,
			data = self.data,
			funds = self.funds,
			members = self.members
		}
	end
end

nut.biz.meta = BUSINESS
