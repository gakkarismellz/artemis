ITEM.name = "Paper Mask"
ITEM.desc = "maskDesc"
ITEM.model = "models/sal/halloween/bag.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.outfitCategory = "hat"
ITEM.price = 200
ITEM.worldModel = true
ITEM.pacData = {
		[1] = {
			["children"] = {
				[1] = {
					["children"] = {
					},
					["self"] = {
						["Angles"] = Angle(-8.6999998092651, 0, 0),
						["UniqueID"] = "KAPPERA",
						["Position"] = Vector(-3.6549999713898, 0, -2.2090001106262),
						["Bone"] = "eyes",
						["Model"] = "models/sal/halloween/bag.mdl",
						["ClassName"] = "model",
					},
				},
			},
			["self"] = {
				["EditorExpand"] = true,
				["UniqueID"] = "KAPPERA2",
				["ClassName"] = "group",
				["Name"] = "my outfit",
				["Description"] = "add parts to me!",
			},
		},
}