ITEM.name = "The Secret of Alpha Male"
ITEM.bookDesc = "strBookDesc"
ITEM.model = "models/props_lab/binderblue.mdl"
ITEM.attribute = "str"
ITEM.attributeAmount = 1
ITEM.price = 100000