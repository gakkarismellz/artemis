ITEM.name = "Hat"
ITEM.desc = "hatDesc"
ITEM.model = "models/props_junk/cardboard_box001a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.outfitCategory = "hat"
ITEM.price = 150
ITEM.pacData = {
[1] = {
	["children"] = {
		[1] = {
			["children"] = {
			},
			["self"] = {
				["ClassName"] = "model",
				["Position"] = Vector(-3.93310546875, 0.0029296875, -2.2197265625),
				["Size"] = 0.953,
				["Bone"] = "eyes",
				["Model"] = "models/sal/acc/fix/mask_4.mdl",
				["UniqueID"] = "MASK_01_PART",
			},
		},
	},
	["self"] = {
		["EditorExpand"] = true,
		["UniqueID"] = "MASK_01_OUTFIT",
		["ClassName"] = "group",
	},
},

}