ITEM.name = "First Aid Kit"
ITEM.model = "models/props_lab/box01a.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.healAmount = 15
ITEM.healSeconds = 1
ITEM.price = 120
ITEM.forceRender = true
ITEM.iconCam = {
	ang	= Angle(8.7384700775146, 146.57766723633, 0),
	fov	= 5.1088362048183,
	pos	= Vector(106.22052764893, -70.098968505859, 19.561912536621)
}

