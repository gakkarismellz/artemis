local PLUGIN = PLUGIN
PLUGIN.name = "Corkboard"
PLUGIN.author = "Zoephix"
PLUGIN.desc = "Adds a interactive corkboard"

PLUGIN.wanted = PLUGIN.wanted or {}

nut.util.include("sv_plugin.lua")

nut.flag.add( "W", "Access to the warrant board" )

if not CLIENT then return end

netstream.Hook("UseCorkboard", function()
    if IsValid(PLUGIN.panel) then
        PLUGIN.panel:Remove()
    end

    PLUGIN.panel = vgui.Create("DFrame")
    PLUGIN.panel:SetTitle("")
    PLUGIN.panel:SetSize(ScrW() * 0.3, ScrH() * 0.4)
    PLUGIN.panel:Center()
    PLUGIN.panel:MakePopup()
    PLUGIN.panel.Paint = function(this, w, h)
        draw.RoundedBox(5, 0, 0, w, h, Color(25, 25, 25, 225))
    end

    PLUGIN.panel.wantedTable = PLUGIN.panel:Add("DListView")
    PLUGIN.panel.wantedTable:Dock(FILL)
    PLUGIN.panel.wantedTable:SetMultiSelect(false)
    PLUGIN.panel.wantedTable:AddColumn("Name Of Wanted")
    PLUGIN.panel.wantedTable:AddColumn("Link For Warrant")
    PLUGIN.panel.wantedTable.OnRowSelected = function(list, index, panel)
        local menu = DermaMenu()
            local remove = menu:AddOption(
                "Remove",
                function()
                    netstream.Start("RemoveCorkboardWanted", panel:GetColumnText(1), panel:GetColumnText(2))
                end
            )
            remove:SetIcon("icon16/delete.png")

            local view = menu:AddOption(
                "View",
                function()
                    gui.OpenURL(panel:GetColumnText(2))
                end
            )
            view:SetIcon("icon16/zoom.png")
        menu:Open()
    end

    for text, link in pairs(PLUGIN.wanted) do
        PLUGIN.panel.wantedTable:AddLine(text, link)
    end

    local add = PLUGIN.panel.wantedTable:Add("DButton")
    add:Dock(BOTTOM)
    add:SetText("Create New Warrant")
    add.DoClick = function()
        Derma_StringRequest(
            "Add warrant",
            "Input name",
            "",
            function(text)
                Derma_StringRequest(
                    "Add warrant",
                    "Input link",
                    "",
                    function(link)
                        netstream.Start("UpdateCorkboardWanted", {text = text, link = link})
                    end
                )
            end
        )
    end
end)

netstream.Hook("UpdateCorkboardWanted", function(data)
    PLUGIN.wanted[data.text] = data.link

    if IsValid(PLUGIN.panel) then
        PLUGIN.panel.wantedTable:Clear()

        for text, link in pairs(PLUGIN.wanted) do
            PLUGIN.panel.wantedTable:AddLine(text, link)
        end
    end
end)

netstream.Hook("GetCorkboardWanted", function(data)
    PLUGIN.wanted = data
end)
