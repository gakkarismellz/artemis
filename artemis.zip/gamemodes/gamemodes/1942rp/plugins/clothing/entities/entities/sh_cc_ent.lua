ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName		= "Clothing Chooser"
ENT.Author			= "Robert Bearson"
ENT.Category = "NutScript"

if SERVER then
	function ENT:Initialize()
    self:SetModel("models/mossman.mdl")
		self:SetUseType(SIMPLE_USE)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:DrawShadow(true)
		self:SetSolid(SOLID_OBB)
		self:PhysicsInit(SOLID_OBB)
    self:DropToFloor()

		local physObj = self:GetPhysicsObject()
		if (IsValid(physObj)) then
			physObj:EnableMotion(false)
			physObj:Sleep()
		end

    timer.Simple(1, function()
  		if (IsValid(self)) then
  			self:setAnim()
  		end
  	end)
	end

  function ENT:setAnim()
  	for k, v in ipairs(self:GetSequenceList()) do
  		if v:lower():find("idle") and v ~= "idlenoise" then
  			return self:ResetSequence(k)
  		end
  	end

  	self:ResetSequence(4)
  end

	function ENT:Use(ply)
  	netstream.Start(ply, "openBGShop")
		-- netstream.Start(ply, "OpenClothingChooser", unpack(posT))
	end
end
