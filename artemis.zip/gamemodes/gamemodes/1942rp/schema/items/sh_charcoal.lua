ITEM.name = "Charcoal"
ITEM.desc = "A byproduct of burnt wood used to create ammunition."
ITEM.price = 25
ITEM.model = "models/comradebear/props/codww2/resource/ore_coal.mdl"
ITEM.category = "Other"
ITEM.noBusiness = true
ITEM.uniqueID = "charcoal"