local PLUGIN = PLUGIN

function PLUGIN.WardrobeTab(wp, g)
	local ply = LocalPlayer()
	g.create = wp:Add("WButton")
	g.create:SetText("Save Current Outfit")
	g.create:SetFont("WB_Medium")
	g.create:SetSize(wp:GetWide()-10, 40)
	g.create:SetAccentColor(BC_NEUTRAL)
	g.create:SetPos(5,wp:GetTall()-g.create:GetTall()-5)
	function g.create:DoClick()
		String_Request(PLUGIN.strings.outsavename, function(txt)
			local payload = PLUGIN:GetPreviewPayload()
			netstream.Start("saveOutfit", payload, txt)
		end)
	end

	function wp:ShowOutfits()
		g.scroll = wp:Add("WScrollList")
		g.scroll:SetSize(wp:GetWide(),wp:GetTall()-g.create:GetTall()-10)
		g.list = g.scroll:GetList()

		local function applyOutfit(outfit)
			--Applying outfit on preview model
			local pMdl = PLUGIN.pMdl
			pMdl:SetModel(outfit.model)
			pMdl:SetSkin(outfit.skin or 0)
			pMdl:ResetSequence(2)

			for bk,bv in pairs(outfit.bgs) do
				pMdl:SetBodygroup(bk, bv)
			end
		end

		local outfits = ply:getChar():getData("outfits", {})
		local curSel
		for k,v in pairs(outfits) do
			local ob = g.list:Add("WButton")
			ob:SetText(v.name)
			ob:SetFont("WB_Medium")
			ob:SetSize(g.list:GetWide(), 40)
			ob:SetAccentColor(PLUGIN.listButtonColor)
			function ob:PaintOver(w,h)
				if curSel == self then
					PLUGIN.showBorder(w,h)
				end
			end
			function ob:DoRightClick()
				local rmenu = DermaMenu()
				rmenu:AddOption("Delete Outfit"):SetIcon("icon16/cross.png")
				rmenu:AddOption("Rename"):SetIcon("icon16/user_edit.png")
				rmenu:Open()
				function rmenu:OptionSelected(opt, optText)
					if optText == "Delete Outfit" then
						Choice_Request("Are you sure you want to delete this outfit?", function()
							netstream.Start("deleteOutfit", k)
						end)
					end

					if optText == "Rename" then
						String_Request("What would you like to rename the outfit to?", function(txt)
							netstream.Start("renameOutfit", k, txt)
						end)
					end
				end
			end
			ob.apply = ob:Add("WButton")
			ob.apply:SetText("Apply")
			ob.apply:SetSize(80, ob:GetTall()-4)
			ob.apply:Dock(RIGHT)
			ob.apply:DockMargin(2, 2, 2, 2)
			ob.apply:SetAccentColor(BC_NEUTRAL)
			ob.apply:SetAlpha(0)
			ob.apply:Hide()
			function ob.apply:DoClick()
				self:GInflate(nil, true)
				netstream.Start("applyOutfit", v)
			end
			function ob:ShowApply()
				self.apply:Show()
				self.apply:AlphaTo(255, 0.2)
			end
			function ob:DoClick()
				curSel = self
				applyOutfit(v)

				--Hide other apply buttons
				for _,p in pairs(g.list:GetChildren()) do
					p.apply:SetAlpha(0)
					p.apply:Hide()
				end

				--Show apply on the active button
				self:ShowApply()
			end
		end
	end
	wp:ShowOutfits()

	--Update the tab from the serverside
	netstream.Hook("updateOutfitTab", function()
		if wp.ShowOutfits then
			for k,v in pairs(g.list:GetChildren()) do
				if v and IsValid(v) then v:Remove() end
			end
			wp:ShowOutfits()
		end
	end)
end

local nextReq = CurTime()
hook.Add("Clothing.canSwitchTab", "CanSwitchToWardrobe", function(tabBtn, tabName)
	if tabName ~= "Wardrobe" then return true end
	local changed = PLUGIN:CheckForChanges()
	if changed and nextReq <= CurTime() then
		Choice_Request(PLUGIN.strings.wanswitchchange, function()
			nextReq = CurTime() + 5
			tabBtn:DoClick()
			PLUGIN:SetDefaultPreviewCos()
		end)

		return false
	end

	return true
end)