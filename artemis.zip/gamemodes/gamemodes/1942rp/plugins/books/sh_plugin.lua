PLUGIN.name = "Books"
PLUGIN.author = "Chessnut"
PLUGIN.desc = "Adds books that you can read."