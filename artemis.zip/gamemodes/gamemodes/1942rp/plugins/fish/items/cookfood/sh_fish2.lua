ITEM.name = "Fish"
ITEM.uniqueID = "food_fish2"
ITEM.model = "models/props/de_inferno/goldfish.mdl"
ITEM.hungerAmount = 15
ITEM.foodDesc = "A common fish."
ITEM.quantity = 2
ITEM.price = 199
ITEM.width = 2
ITEM.height = 1
ITEM.noBusiness = true
ITEM.flag = "z"

ITEM.attribBoosts = { ["stm"] = 4 }

function ITEM:getDesc()
	local str = self.foodDesc

	if(self:getData("customDesc") != nil) then
		str = self:getData("customDesc")
	end
	
	if (self.mustCooked != false) then
		str = str .. "\nThis food must be cooked."
	end

	if (self.cookable != false) then
		str = str .. "\nFood Status: %s."
	end

	if(self.quantity) then
		str = str .. "\nPortions remaining: " .. self:getData("quantity", self.quantity)
	end
		
	return Format(str, COOKLEVEL[(self:getData("cooked") or 1)][1])
end

function ITEM:getName()
	local name = self.name
	
	if(self:getData("customName") != nil) then
		name = self:getData("customName")
	end
	
	return Format(name)
end