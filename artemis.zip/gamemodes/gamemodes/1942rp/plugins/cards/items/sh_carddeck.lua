ITEM.name = "Deck of Cards"
ITEM.desc = "A deck of 1932 Skat-Karte Nr. 88 Playing Cards"
ITEM.price = 4
ITEM.model = "models/rhodesia/carddeck.mdl"
ITEM.skin = 1
ITEM.uniqueID = "carddeck"