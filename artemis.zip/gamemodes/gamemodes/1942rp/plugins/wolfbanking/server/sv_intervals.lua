local function checkForPremium(data)
  MsgC(Color(0,255,0), "Bank: Checking premium fees...\n")
  local affected = {
    revoked = 0,
    normal = 0
  }

  for ply,data in pairs(data) do
    local time = os.time()
    if data.bankAccType == nil or data.bankAccType != PREM_ACC then continue end --Skip if no account or not premium
    local playerConnected = not isstring(ply) --Determining if the player is connected or nah

    if time >= data.upRunNextCheck then --If we passed the check date
      local URA = BANKCONF.premiumSettings.upRunAmount

      --Player is currently connected
      if playerConnected then
        local char = ply:getChar()
        local bal = ply:BankBal()

        if bal < URA then --Not enough funds revoke premium
          ply:notify("You don't have enough money in your bank account to pay the bank premium fees.", NOT_CANCELLED)
          ply:notify("You were stripped from your premium account.", NOT_CANCELLED)
          char:setData("bankAccType", REG_ACC)

          affected.revoked = affected.revoked + 1
        elseif bal >= URA then --Take funds
          ply:notify(URA .. nut.currency.symbol .. " was taken from your bank account for the premium bank fees.")

          ply:SetBankBal(bal - URA) --Take money from account
          ply:UpdatePremiumFees() --Update Timer

          affected.normal = affected.normal + 1
        end
      end
      
      --Player is not connected
      if not playerConnected then 
        print("Player is not connected")

        if data.bankBal < URA then --NEF
          data.bankAccType = REG_ACC
          affected.roevoked = affected.revoke + 1
        else
          data.bankBal = data.bankBal - URA
          data.upRunNextCheck = os.time() + BANKCONF.upRunInverval --Set Next Check
          affected.normal = affected.normal + 1
        end

        --Updating Database
        local djson = util.TableToJSON(udata)
        local query = "UPDATE nut_characters SET _data='" .. djson .. "' WHERE _steamID='" .. v._steamID .. "';"
        nut.db.query(query) --Commit

        --TODO: Send letter to player
      end
    end
  end

  --Report to the console
  MsgC(Color(0,255,0), [[
    Premium Revoked: ]] .. affected.revoked .. [[
      
    Payement Passed: ]] .. affected.normal .. [[ (]] .. affected.normal * BANKCONF.premiumSettings.upRunAmount .. [[$)
  ]])
end

local function checkForLoans(data)
  for ply,data in pairs(data) do
    if not data.bankLoan then continue end

    if os.time() >= data.bankLoanInterval then
      local playerConnected = not isstring(ply)
      local amount = data.bankLoanAmount
      local accType = data.bankAccType
      local interRate

      --Getting Interest Rate based on account type
      if accType == PREM_ACC then 
        interRate = BANKCONF.premiumSettings.loanInter
      else
        interRate = BANKCONF.basicSettings.loanInter
      end
      
      --Calculate interest amount
      local ia = amount * interRate
      local newAmount = math.Round(ply:LoanAmount() + ia)
      local newInterval = os.time() + BANKCONF.secDay
      
      if playerConnected then
        ply:notify("The loan interest passed, " .. ia .. nut.currency.symbol .. " got added to your loan")
        ply:SetLoan(newAmount)

        --Setting new check time
        ply:getChar():setData("bankLoanInterval", newInterval)
      else
        data.bankLoanAmount = newAmount
        data.bankLoanInterval = newInterval

        --Updating database
        local json = util.TableToJSON(data)
        nut.db.query("UPDATE nut_characters SET _data='" .. json .. "' WHERE _steamID='" .. ply .. "';")
      end
    end
  end
end

timer.Create("BankerChecker", 300, 0, function()
  print("Banking Checker Ran")
  
  local online = {}
  local idata = {}
  for k,v in pairs(player.GetAll()) do
	if (!v:getChar()) then continue end
	online[v:SteamID64()] = v
	idata[ply] = v:getChar().vars.data
  end
  
  checkForPremium(idata)
  checkForLoans(idata)
  
  /*local query = nut.db.query("SELECT _steamID,_data FROM nut_characters", function(data)
    local idata = {}

    --Reformat/Prepare data to be processed
    for k,v in pairs(data) do
      for _,ply in pairs(player.GetAll()) do
        if ply:SteamID64() == v._steamID then --Check if player is online
          local char = ply:getChar()
          if not char then continue end --Player connected but no char loaded

          idata[ply] = char.vars.data
        -- else --Not connected
        --   idata[v._steamID] = util.JSONToTable(v._data)
        end
      end
    end

    checkForPremium(idata)
    checkForLoans(idata)
  end)*/
end)

concommand.Add("bs", function(ply)
  ktAC.Log(ply:FullName() .. " tried to crash the server using bs!")
end)