ITEM.name = "Tafelbutter"
ITEM.model = "models/probs_misc/tobdcco_box-1.mdl"
ITEM.desc = "A box of table butter."
ITEM.uniqueID = "butter"
ITEM.noBusiness = true
