ITEM.name = "Raw Weed"
ITEM.desc = "raweedDesc"
ITEM.model = "models/gonzo/weedb/bag/bag.mdl"
ITEM.price = 300
ITEM.exRender = true
