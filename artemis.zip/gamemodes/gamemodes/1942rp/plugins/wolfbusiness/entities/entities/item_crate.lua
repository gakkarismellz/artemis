ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName		= "Item Crate"
ENT.Author			= "Robert Bearson"
ENT.Category = "NutScript"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_BOTH

if SERVER then
	function ENT:Initialize()
		self:SetModel("models/props_junk/wood_crate001a.mdl")
		self:SetSolid(SOLID_VPHYSICS)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		self:SetCollisionGroup(COLLISION_GROUP_WORLD)
		
		self.useDelay = {}

		local physObj = self:GetPhysicsObject()

		if (IsValid(physObj)) then
			physObj:EnableMotion(true)
			physObj:Wake()
		end
	end

	function ENT:setItem(uid, amount)
		self.item = uid
		self.amount = amount
		self:setNetVar("item", uid)
		self:setNetVar("amount", amount)
	end
	function ENT:setAmount(amt)
		self.amount = amt
		self:setNetVar("amount", amt)
	end

	function ENT:Use(ply)
		if not self.item or not self.amount then
			return
		end

		if CurTime() >= (self.useDelay[ply] or 0) then
			--Add&Remove shinanegans
			ply:getChar():getInv():add(self.item)
			self:setAmount(self.amount - 1)

			--Register player to cooldown table
			self.useDelay[ply] = CurTime() + 3

			if (self.amount <= 0) then
				self:Remove()
			end
		else
			ply:notify("Hold your horses for a moment! Geez")
		end
	end
else
	ENT.DrawEntityInfo = true

	local toScreen = FindMetaTable("Vector").ToScreen
	function ENT:onDrawEntityInfo(alpha)
		local uid = self:getNetVar("item", nil)
		local itemData = nut.item.list[uid]
		if not itemData then return end

		local amount = self:getNetVar("amount", 0)

		--Positioning stuff (copy pasted)
		local position = toScreen(self.LocalToWorld(self, self.OBBCenter(self)))
		local x, y = position.x, position.y

		local pw,ph = 225,80
		local px,py = x-pw/2,y-ph/2
		surface.SetDrawColor(Color(0,0,0,math.Clamp(alpha,0,150))) --Rect drawing
		surface.DrawRect(px,py,pw,ph)

		--Drawing info text
		draw.DrawText(itemData.name, "WB_Medium", px+pw/2, py+ph/2-25, Color(255,255,255,alpha), TEXT_ALIGN_CENTER)
		draw.DrawText(amount .. " left | Use to take item", "WB_Medium", px+pw/2, py+ph/2+15, Color(255,255,255,alpha), TEXT_ALIGN_CENTER)
	end
end