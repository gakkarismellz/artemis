function nut.biz.create(callback)
	local ponNull = pon.encode({})
	local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time())

	nut.db.insertTable({
			_name = BUSINESS_DEFUALT_NAME,
			_lastModify = timeStamp,
			_timeCreated = timeStamp,
			_level = 1,
			_funds = BUSINESS_INITIAL_FUNDS,
			_members = "{}",
			_experience = 0,
			_data = ponNull
	}, function(succ, bizID)
		if (succ ~= false) then
			local biz = nut.biz.new()
			biz.id = bizID
			nut.biz.loaded[bizID] = biz

			if (callback) then
				biz:sync()
				callback(biz)
			end
		end
	end, "business")
end

function nut.biz.delete(id)
	local biz = nut.biz.loaded[id]

	if (biz) then
		local affectedPlayers = {}

		for k, v in ipairs(player.GetAll()) do
			local char = v:getChar()

			if (char) then
				local charBiz = char:getBusiness()

				if (charBiz == id) then
					char:setData("business", nil, nil, player.GetAll())
					char:setData("businessRank", nil, nil, player.GetAll())
					table.insert(affectedPlayers, v)
				end
			end
		end

		hook.Run("OnOranizationDeleted", biz, affectedPlayers)
		biz:unsync()
		nut.biz.loaded[id] = nil
		nut.db.query("DELETE FROM nut_business WHERE _id IN (" .. biz.id .. ")")

		return true
	else
			return false, "invalidBiz"
	end
end

function nut.biz.syncAll(recipient)
	local bizData = {}

	for k, v in pairs(nut.biz.loaded) do
		bizData[k] = v:getSyncInfo()
	end

	netstream.Start(recipient, "nutBizSyncAll", bizData)
end

function nut.biz.purge(callback)
	local timeStamp = os.date("%Y-%m-%d %H:%M:%S", os.time() - BUSINESS_AUTO_DELETE_TIME)

	nut.db.query("DELETE FROM nut_business WHERE _lastModify <= '" .. timeStamp .. "'", function(data, data2)
		if (callback) then
			callback()
		end
	end)
end

function nut.biz.load(id, callback)
	local biz = nut.biz.new()

	nut.db.query("SELECT _id, _name, _level, _experience, _funds, _data FROM nut_business WHERE _id IN (" .. id .. ")", function(data)
		if (data) then
			for k, v in ipairs(data) do
				local biz = nut.biz.new()
				biz.id = tonumber(v._id)
				biz.name = v._name
				biz.level = tonumber(v._level)
				biz.funds = tonumber(v._funds)
				biz.experience = tonumber(v._experience)
				biz.data = pon.decode(v._data)
				nut.biz.loaded[biz.id] = biz

				nut.db.query("SELECT _bizID, _charID, _rank, _name FROM nut_busimembers WHERE _bizID IN (" .. biz.id .. ")", function(data)
					if (data) then
						for k, v in ipairs(data) do
							local rank = tonumber(v._rank)
							biz.members[rank] = biz.members[rank] or {}
							biz.members[rank][tonumber(v._charID)] = v._name
						end
					end

					if (callback) then
						callback(biz)
					end
				end)
			end
		end
	end)
end

function nut.biz.loadAll(callback)
	local biz = nut.biz.new()

	nut.db.query("SELECT _id, _name, _level, _experience, _funds, _data FROM nut_business", function(data)
		if (data) then
			for k, v in ipairs(data) do
				local biz = nut.biz.new()
				biz.id = tonumber(v._id)
				biz.name = v._name
				biz.level = tonumber(v._level)
				biz.experience = tonumber(v._experience)
				biz.funds = tonumber(v._funds)
				biz.data = pon.decode(v._data)
				nut.biz.loaded[biz.id] = biz

				nut.db.query("SELECT _bizID, _charID, _rank, _name FROM nut_busimembers WHERE _bizID IN (" .. biz.id .. ")", function(data)
					if (data) then
						for k, v in ipairs(data) do
							local rank = tonumber(v._rank)
							biz.members[rank] = biz.members[rank] or {}
							biz.members[rank][tonumber(v._charID)] = v._name
						end
					end

					if (callback) then
						callback(biz)
					end
				end)
			end
		end
	end)
end

--Hooks
function PLUGIN:PlayerInitialSpawn(client)
	nut.biz.syncAll(client)
	local fookinData = {}

	for k, v in ipairs(player.GetAll()) do
		if (v == client) then continue end
		local char = v:getChar()

		if (char) then
			local id = char:getID()

			if (char:getBusiness() ~= -1) then
				fookinData[id] = {char:getData("business"), char:getData("businessRank")}
			end
		end
	end

	netstream.Start(client, "nutBizCharSync", fookinData)
end

function PLUGIN:InitializedPlugins()
	nut.biz.purge(function()
		nut.biz.loadAll(function(biz)
			hook.Run("OnBusinessLoaded", biz)
		end)
	end)
end

function PLUGIN:CanChangeBusinessVariable(client, key, value)
	return true
end

function PLUGIN:CanCreateBusiness(client)
	local char = client:getChar()

	if (char) then
		if (char:getBusinessInfo()) then return false, "bizExists" end
		local inv = char:getInv()

		if (inv) then
			if (inv:hasItem("permit_biz")) then
				return true
			else
				return false, "requirePermit"
			end
		end
	end

	return false
end

function PLUGIN:OnCreateBusiness(client, business)
	local char = client:getChar()

	if (char) then
		local inv = char:getInv()

		if (inv) then
			--inv:remove("permit_biz", false, true)
			for k, v in pairs(inv:getItemsByUniqueID("permit_biz", true)) do
				v:remove()
				-- Only remove one.

				return
			end
		end
	end
end

function PLUGIN:PlayerCanJoinBusiness()
	return true
end