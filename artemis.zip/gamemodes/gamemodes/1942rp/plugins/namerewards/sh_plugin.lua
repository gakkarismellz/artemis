PLUGIN.name = "Steam Name Rewards"
PLUGIN.author = "JustJosh"
PLUGIN.desc = "Gives your players rewards for having a certain message in their steam name"

nut.config.add("snrActive", true, "Whether or not Steam Name Rewards are activated on the server.", nil, {
category = "Steam Name Rewards"
})

nut.config.add("snrAPIKey", "34EB5EB5F1243214266B9ACA927E2620", "Your Steam API key. Needed for the addon to function.", nil, {
category = "Steam Name Rewards"
})

nut.config.add("snrPrizeCooldown", 5, "The amount of days between when players will receive rewards", nil, {
category = "Steam Name Rewards",
data = {min=1, max=7},
})

nut.config.add("snrPrizePhrase", "[TP-N]", "The phrase people need to have in their names to receive prizes", nil, {
category = "Steam Name Rewards",
})

nut.config.add("snrSecondaryPrizePhrase", "TP-N.co", "The secondary phrase people need to have in their names to receive secondary prizes", nil, {
category = "Steam Name Rewards",
})

nut.config.add("snrChatCommand", "!steamname", "The command players need to type to receive their rewards", nil, {
category = "Steam Name Rewards",
})

if SERVER && nut.config.get("snrActive") then
    util.AddNetworkString("snrMenuCheck")
    concommand.Add("sqlQuery", function( ply, cmd, args )
        print(ply:Name())
    end)
    function PLUGIN:PlayerSay(ply, text)
        if text == nut.config.get("snrChatCommand") then
            net.Start("snrMenuCheck")
            net.Send(ply)
            return ""
        end
    end

    function PLUGIN:MenuCheck()
        net.Receive("snrMenuCheck", function(len, ply)
            self:CheckPlayer(ply)
        end)
    end

    function PLUGIN:CheckSQL()
        if !sql.TableExists("snrData") then
            sql.Query("CREATE TABLE snrData(SteamID VARCHAR, Reclaim INTEGER, Prize INTEGER)")
            print("[Steam Name Rewards] Created SQL Table")
        end
        print("[Steam Name Rewards] SQL Connection Check Complete")
        --sql.Query("DROP TABLE snrData")
    end

    function PLUGIN:PlayerSpawn(ply)
        timer.Simple("60", function()
            if (!IsValid(ply)) then return end
            self:CheckPlayer(ply)
        end)
    end


    function PLUGIN:CheckPrizePlayers()
        local players = sql.Query("SELECT * FROM snrData WHERE Prize != 0")
        if players != nil then
            for k, ply in pairs(players) do
                local steamid = ply["SteamID"]
                self:GetSteamName(steamid, function(steamname)
					if (!ply || !IsValid(ply)) then return end
					local prize = ply["Prize"]
					if prize == "1" then
						if !(string.find(steamname, nut.config.get("snrPrizePhrase"))) then
							sql.Query("UPDATE snrData SET Prize=0 WHERE SteamID='"..steamid.."'")
						end
					elseif prize == "2" then
						if !(string.find(steamname, nut.config.get("snrSecondaryPrizePhrase"))) then
							sql.Query("UPDATE snrData SET Prize=0 WHERE SteamID='"..steamid.."'")
						end
					end
				end)
            end
        end

        for k,v in pairs(player.GetAll()) do
            self:CheckPlayer(v)
        end
    end

    function PLUGIN:GetSteamName(steamid, callBack)
        http.Fetch("http://api.steampowered.com/ISteamUser/GetPlayerSummaries/v0002/?key="..nut.config.get("snrAPIKey").."&steamids="..steamid,
        function( body, len, headers, code )
            local body = util.JSONToTable(body)
			if (!body) then return end
            local players = body["response"]["players"]
            name = players[1] and players[1]["personaname"] or "BOT"
            body = nil 
            players = nil
			if (callBack && isfunction(callBack)) then
				callBack(name)
			end
        end,
        function(error)
            print("[Steam Name Rewards] Error received: "..error)
        end)
    end

    function PLUGIN:GetReclaimTime()
        return os.time() + 86400*nut.config.get("snrPrizeCooldown")
    end

    function PLUGIN:CheckPlayer(ply)
        local steamid = ply:SteamID64()
        self:GetSteamName(steamid, function(steamname)
			if (!ply || !IsValid(ply)) then return end
			local results = sql.Query("SELECT * FROM snrData WHERE SteamID = '"..steamid.."'")
			if (string.find(steamname, nut.config.get("snrSecondaryPrizePhrase"))) then
				if results == nil then
					sql.Query("INSERT INTO snrData(SteamID, Reclaim, Prize) VALUES ("..steamid..", "..self:GetReclaimTime()..", 2)")
					ply:notify("Thank you for supporting our servers! You will receive your prize in "..nut.config.get("snrPrizeCooldown").." days!")
				else
					for k,v in pairs(results) do
						local prize = v["Prize"]
						local reclaim = v["Reclaim"]
						if prize == "0" then
							sql.Query("UPDATE snrData SET Reclaim="..self:GetReclaimTime()..", Prize=2 WHERE SteamID='"..steamid.."'")
							ply:notify("Thank you for supporting our servers again! You will receive your prize in "..nut.config.get("snrPrizeCooldown").." days!")
						elseif prize == "2" then
							local time = os.time()
							if util.StringToType(reclaim, "int") < time then
								self:GivePrize(ply, "2")
							end
						end
					end
				end
			elseif (string.find(steamname, nut.config.get("snrPrizePhrase"))) then
				if results == nil then
					sql.Query("INSERT INTO snrData(SteamID, Reclaim, Prize) VALUES ("..steamid..", "..self:GetReclaimTime()..", 1)")
					ply:notify("Thank you for supporting our servers! You will receive your prize in "..nut.config.get("snrPrizeCooldown").." days!")
				else
					for k,v in pairs(results) do
						local prize = v["Prize"]
						local reclaim = v["Reclaim"]
						if prize == "0" then
							sql.Query("UPDATE snrData SET Reclaim="..self:GetReclaimTime()..", Prize=2 WHERE SteamID='"..steamid.."'")
							ply:notify("Thank you for supporting our servers again! You will receive your prize in "..nut.config.get("snrPrizeCooldown").." days!")
						elseif prize == "1" then
							local time = os.time()
							if util.StringToType(reclaim, "int") < time then
								self:GivePrize(ply, "1")
							end
						end
					end
				end
			end
		end)
    end

    function PLUGIN:GivePrize(ply, prize)
        if ply:IsPlayer() then
            local char = ply:getChar()
            local steamid = ply:SteamID64()
            if prize == "1" then
                char:giveMoney(3000)
                ply:notify("You have received 3000RM for having "..nut.config.get("snrPrizePhrase").." in your name for "..nut.config.get("snrPrizeCooldown").." days!")
                sql.Query("UPDATE snrData SET Reclaim="..self:GetReclaimTime()..", Prize=1 WHERE SteamID='"..steamid.."'")
            elseif prize == "2" then
                char:giveMoney(3500)
				if (char:getFaction() == FACTION_civy) then
					char:setData("loyalPoint", char:getData("loyalPoint", 0) + 2, false, player.GetAll())
					ply:notify("You have received 3500RM and 2 Loyalist Points for having "..nut.config.get("snrPrizePhrase").." in your name for "..nut.config.get("snrPrizeCooldown").." days!")
				else
					ply:notify("You have received 3500RM for having "..nut.config.get("snrPrizePhrase").." in your name for "..nut.config.get("snrPrizeCooldown").." days!")
				end
                sql.Query("UPDATE snrData SET Reclaim="..self:GetReclaimTime()..", Prize=2 WHERE SteamID='"..steamid.."'")
            end
        end
    end

    local nextrun = os.time() + 3600
    function PLUGIN:RunPrizeCheck()
        hook.Add("Think", "RunPrizeCheck", function()
            if nextrun < os.time() then
                self:CheckPrizePlayers()
                nextrun = os.time() + 3600
            end
        end)
    end

    PLUGIN:CheckSQL()
    //PLUGIN:CheckPrizePlayers()
    PLUGIN:RunPrizeCheck()
    PLUGIN:MenuCheck()
end

if CLIENT && nut.config.get("snrActive") then
    net.Receive("snrMenuCheck", function()
        local snrMenu = vgui.Create("DFrame")
        snrMenu:SetSize(500, 200)
        snrMenu:Center()
        snrMenu:SetSizable(false)
        snrMenu:SetDraggable(false)
        snrMenu:MakePopup()
        snrMenu:SetTitle("Steam Name Rewards")
        snrMenu.lblTitle:SetTextColor(Color(255,255,255))
        snrMenu.btnClose.Paint = function( self, w, h )
            if self:IsHovered() then
                draw.RoundedBox(0, 10, 5, w-10, h-10, Color(183, 55, 85))
            else
                draw.RoundedBox(0, 10, 5, w-10, h-10, Color(135, 45, 53))
            end
            draw.DrawText("x", nil, 21, 5, Color(255,255,255), TEXT_ALIGN_CENTER)
        end

        local snrExplanation = vgui.Create("DLabel", snrMenu)
        snrExplanation:SetPos(5, 25)
        snrExplanation:SetTextColor(Color(255,255,255))
        snrExplanation:SetText("You will receive 3000RM for having "..nut.config.get("snrPrizePhrase").." in your name.\nYou will receive 3500RM and 2 Loyalist Points for having "..nut.config.get("snrSecondaryPrizePhrase").." in you name.\n\nRemember: The phrase must be in you name for a consecutive "..nut.config.get("snrPrizeCooldown").. " days!\nYou will not get rewards for both phrases at the same time. Only one!\n\nIf your rewards do not come through press the Check Rewards button down below.")
        snrExplanation:SizeToContents()

        local snrCheckButton = vgui.Create("DButton", snrMenu)
        snrCheckButton:SetSize(120,50)
        snrCheckButton:SetPos(250-60, 140)
        snrCheckButton:SetText("Check Rewards")
        snrCheckButton.DoClick = function()
            net.Start("snrMenuCheck")
            net.SendToServer()
        end

    end)
end