local PLUGIN = PLUGIN
PLUGIN.name = "Prop Spawn Delay"
PLUGIN.author = "Zoephix"
PLUGIN.desc = "Adds a delay to object spawning."

-- delay in seconds
PLUGIN.delay = 2.5

if SERVER then
	function PLUGIN:PlayerSpawnObject(ply, model, skin)
		if ply.objSpawnDelay and ply.objSpawnDelay > CurTime() then return false end
		ply.objSpawnDelay = CurTime() + self.delay
	end
end
