local PLUGIN = PLUGIN
local function updateTab(ply)
	timer.Simple(0.2, function()
		netstream.Start(ply, "updateOutfitTab")
	end)
end

netstream.Hook("saveOutfit", function(ply, payload, outfitName)
	payload.name = outfitName --Setting outfit name to payload

	--Saving outfit to char
	local char = ply:getChar()
	local outs = char:getData("outfits", {})
	table.insert(outs, payload)

	char:setData("outfits", outs)
	updateTab(ply)

	--Notify player
	ply:notify(string.format(PLUGIN.strings.outsavesucc, outfitName))
end)

netstream.Hook("deleteOutfit", function(ply, id)
	if ply.getChar and ply:getChar() then
		local char = ply:getChar()
		local outs = char:getData("outfits")
		table.remove(outs, id)
		char:setData("outfits", outs)
		updateTab(ply)
	end
end)

netstream.Hook("renameOutfit", function(ply, id, newName)
	if ply.getChar and ply:getChar() then
		local char = ply:getChar()
		local outs = char:getData("outfits")
		outs[id].name = newName
		char:setData("outfits", outs)
		updateTab(ply)
	end
end)

netstream.Hook("applyOutfit", function(ply, outfit)
	ply:getChar():setModel(outfit.model)
	ply:SetSkin(outfit.skin or 0)
	ply:ResetSequence(2)

	for bk,bv in pairs(outfit.bgs) do
		ply:SetBodygroup(bk, bv)
	end
	ply:getChar():setData("groups", outfit.bgs)

	ply:notify("Applied Outfit '" .. outfit.name .. "'!", NOT_SUCCESS)
end)