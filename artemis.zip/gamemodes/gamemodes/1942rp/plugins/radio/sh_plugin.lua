PLUGIN.name = "Radio"
PLUGIN.author = "Black Tea"
PLUGIN.desc = "You can communicate with other people in distance."
local RADIO_CHATCOLOR = Color(100, 255, 50)

-- This is how initialize Language in Single File.
local langkey = "english"
local langTable = {
	radioFreq = "Frequency",
	radioSubmit = "Submit",
	radioNoRadio = "You don't have any radio to adjust.",
	radioNoRadioComm = "You don't have any radio to communicate",
	radioFormat = "%s radios in \"%s\"",
}

function PLUGIN:PluginLoaded()
	table.Merge(nut.lang.stored[langkey], langTable)
end

if CLIENT then
  hook.Add("Think", "checkIfVoicePanelIsValid", function()
    /*if g_VoicePanelList and IsValid(g_VoicePanelList) then
      g_VoicePanelList:SetVisible(false)
    end*/
  end)
end

if (CLIENT) then
	local PANEL = {}
	function PANEL:Init()
		self.number = 0
		self:SetWide(70)

		local up = self:Add("DButton")
		up:SetFont("Marlett")
		up:SetText("t")
		up:Dock(TOP)
		up:DockMargin(2, 2, 2, 2)
		up.DoClick = function(this)
			self.number = (self.number + 1)% 10
			surface.PlaySound("buttons/lightswitch2.wav")
		end

		local down = self:Add("DButton")
		down:SetFont("Marlett")
		down:SetText("u")
		down:Dock(BOTTOM)
		down:DockMargin(2, 2, 2, 2)
		down.DoClick = function(this)
			self.number = (self.number - 1)% 10
			surface.PlaySound("buttons/lightswitch2.wav")
		end

		local number = self:Add("Panel")
		number:Dock(FILL)
		number.Paint = function(this, w, h)
			draw.SimpleText(self.number, "nutDialFont", w/2, h/2, color_white, 1, 1)
		end
	end

	vgui.Register("nutRadioDial", PANEL, "DPanel")

	PANEL = {}

	function PANEL:Init()
		self:SetTitle(L("radioFreq"))
		self:SetSize(330, 220)
		self:Center()
		self:MakePopup()

		self.submit = self:Add("DButton")
		self.submit:Dock(BOTTOM)
		self.submit:DockMargin(0, 5, 0, 0)
		self.submit:SetTall(25)
		self.submit:SetText(L("radioSubmit"))
		self.submit.DoClick = function()
			local str = ""
			for i = 1, 5 do
				if (i != 4) then
					str = str .. tostring(self.dial[i].number or 0)
				else
					str = str .. "."
				end
			end
			netstream.Start("radioAdjust", str, self.itemID)

			self:Close()
		end

		self.dial = {}
		for i = 1, 5 do
			if (i != 4) then
				self.dial[i] = self:Add("nutRadioDial")
				self.dial[i]:Dock(LEFT)
				if (i != 3) then
					self.dial[i]:DockMargin(0, 0, 5, 0)
				end
			else
				local dot = self:Add("Panel")
				dot:Dock(LEFT)
				dot:SetWide(30)
				dot.Paint = function(this, w, h)
					draw.SimpleText(".", "nutDialFont", w/2, h - 10, color_white, 1, 4)
				end
			end
		end
	end

	function PANEL:Think()
		self:MoveToFront()
	end

	vgui.Register("nutRadioMenu", PANEL, "DFrame")

	surface.CreateFont("nutDialFont", {
		font = "Agency FB",
		size = 100,
		weight = 1000
	})

	surface.CreateFont("nutRadioFont", {
		font = "Lucida Sans Typewriter",
		size = math.max(ScreenScale(7), 17),
		weight = 100
	})

	netstream.Hook("radioAdjust", function(freq, id)
		local adjust = vgui.Create("nutRadioMenu")

		if (id) then
			adjust.itemID = id
		end

		if (freq) then
			for i = 1, 5 do
				if (i != 4) then
					adjust.dial[i].number = tonumber(freq[i])
				end
			end
		end
	end)
else
	include("sv_plugin.lua")
	
	netstream.Hook("radioAdjust", function(client, freq, id)
		local inv = (client:getChar() and client:getChar():getInv() or nil)

		if (inv) then
			local item

			if (id) then
				item = nut.item.instances[id]
			else
				item = inv:hasItem("radio")
			end

			local ent = item:getEntity()

			if (item and (IsValid(ent) or item:getOwner() == client)) then
				(ent or client):EmitSound("buttons/combine_button1.wav", 50, 170)
				item:setData("freq", freq, player.GetAll(), false, true)
			else
				client:notifyLocalized("radioNoRadio")
			end
		end
	end)

	/* Do we need it?
	nut.command.add("freq", {
		syntax = "<string name> [string flags]",
		onRun = function(client, arguments)
			local inv = client:getChar():getInv()

			if (inv) then
				local detect = {
					"radio",
					"sradio",
					"pager"
				}

				for k, v in ipairs(detect) do
					item = inv:hasItem(v)
				end

				if (item) then


					item:setData("freq", arguments[1], nil, nil, true)
				else
					client:notify("You do not have any radio to adjust.")
				end
			end
		end
	})
*/
end

-- Yelling out loud.
local find = {
	["radio"] = false,
	["sradio"] = true
}
local function endChatter(listener)
	timer.Simple(1, function()
		if (!listener:IsValid() or !listener:Alive() or hook.Run("ShouldRadioBeep", listener) == false) then
			return false
		end

		listener:EmitSound("npc/metropolice/vo/off"..math.random(1, 3)..".wav", math.random(60, 70), math.random(80, 120))
	end)
end

nut.chat.register("radio", {
	format = "%s says in radio: \"%s\"",
	font = "nutRadioFont",
	onGetColor = function(speaker, text)
		return RADIO_CHATCOLOR
	end,
	onCanHear = function(speaker, listener)
		local dist = speaker:GetPos():Distance(listener:GetPos())
		local speakRange = nut.config.get("chatRange", 280)
		local listenerEnts = ents.FindInSphere(listener:GetPos(), speakRange)
		local listenerInv = listener:getChar():getInv()
		local freq

		if (!CURFREQ or CURFREQ == "") then
			return false
		end

		if (dist <= speakRange) then
			return true
		end

		
		

		if (listenerInv) then
			for k, v in pairs(listenerInv:getItems()) do
				if (freq) then
					break
				end

				for id, far in pairs(find) do
					if (v.uniqueID == id and v:getData("power", false) == true) then
						if (CURFREQ == v:getData("freq", "000.0")) then
							local playerFactionID = nut.faction.indices[listener:getChar():getFaction()].uniqueID
							
							if (EncryptedFrequencies && EncryptedFrequencies[CURFREQ] && !EncryptedFrequencies[CURFREQ][playerFactionID]) then
								local decrypted = false
								
								for k, v in pairs(listenerInv:getItems()) do
									if (v.decryptionKey && (v.decryptionKey.all || v.decryptionKey[CURFREQ])) then
										decrypted = true
										break
									end
								end

								if (!decrypted) then
									netstream.Start(listener, "cMsg", speaker, "radio", "[" .. table.Random({"garbled sounds", "muffled noise", "interference", "loud static", "echoing ping"}) .. "]", true)
									return false
								end
							end
							
							endChatter(listener)
							
							return true
						end

						break
					end
				end
			end
		end

		if (!freq) then
			for k, v in ipairs(listenerEnts) do
				if (freq) then
					break
				end

				if (v:GetClass() == "nut_item") then
					local itemTable = v:getItemTable()

					for id, far in pairs(find) do
						if (far and itemTable.uniqueID == id and v:getData("power", false) == true) then
							if (CURFREQ == v:getData("freq", "000.0")) then
								local playerFactionID = nut.faction.indices[listener:getChar():getFaction()].uniqueID
								
								if (EncryptedFrequencies && EncryptedFrequencies[CURFREQ] && !EncryptedFrequencies[CURFREQ][playerFactionID]) then
									local decrypted = false
									
									for k, v in pairs(listenerInv:getItems()) do
										if (v.decryptionKey && (v.decryptionKey.all || v.decryptionKey[CURFREQ])) then
											decrypted = true
											break
										end
									end

									if (!decrypted) then
										netstream.Start(listener, "cMsg", speaker, "radio", "[" .. table.Random({"garbled sounds", "muffled noise", "interference", "loud static", "echoing ping"}) .. "]", true)
										return false
									end
								end
							
								endChatter(listener)

								return true
							end
						end
					end
				end
			end
		end

		return false
	end,
	onCanSay = function(speaker, text)
		local schar = speaker:getChar()
		local speakRange = nut.config.get("chatRange", 280)
		local speakEnts = ents.FindInSphere(speaker:GetPos(), speakRange)
		local speakerInv = schar:getInv()
		local freq


		
		if (speakerInv) then
			for k, v in pairs(speakerInv:getItems()) do
				if (freq) then
					break
				end

				for id, far in pairs(find) do
					if (v.uniqueID == id and v:getData("power", false) == true) then
						freq = v:getData("freq", "000.0")

						break
					end
				end
			end
		end

		if (!freq) then
			for k, v in ipairs(speakEnts) do
				if (freq) then
					break
				end

				if (v:GetClass() == "nut_item") then
					local itemTable = v:getItemTable()

					for id, far in pairs(find) do
						if (far and itemTable.uniqueID == id and v:getData("power", false) == true) then
							freq = v:getData("freq", "000.0")

							break
						end
					end
				end
			end
		end

		
		if (freq) then
			local playerFactionID = nut.faction.indices[schar:getFaction()].uniqueID
			
			if (EncryptedFrequencies && EncryptedFrequencies[freq] && !EncryptedFrequencies[freq][playerFactionID]) then
				local decrypted = false
				
				for k, v in pairs(speakerInv:getItems()) do
					if (v.decryptionKey && (v.decryptionKey.all || v.decryptionKey[freq])) then
						decrypted = true
						break
					end
				end
				
				if (!decrypted) then
					speaker:notify("This is an encrypted radio frequency that you cannot access without a decryption key.")
					return false
				end
			end
			
			CURFREQ = freq
			speaker:EmitSound("npc/metropolice/vo/on"..math.random(1, 2)..".wav", math.random(50, 60), math.random(80, 120))
		else
			speaker:notifyLocalized("radioNoRadioComm")
			return false
		end
	end,
	prefix = {"/r", "/radio"},
})

if (CLIENT) then
	netstream.Hook("EncryptedFreqMenu", function(EncryptedFreq, selectItem)
		local frame = vgui.Create("DFrame");
		frame:SetSize(600, 484);
		frame:Center()
		frame:SetTitle("Encrypted Frequencies")
		frame:MakePopup()

		local panel1 = vgui.Create("DPanel", frame)
		panel1:SetWidth(200)
		panel1:Dock(LEFT)


		local freqPanels = {}

		local listView1 = vgui.Create("DListView", panel1)
		listView1:SetHeight(400)
		listView1:Dock(TOP)
		listView1:AddColumn("Frequency")
		listView1.OnRowSelected = function(pnl, rowindex, row)
			frame.listView2:Clear()
			for k,v in pairs(EncryptedFreq[row.freq]) do
				local line = frame.listView2:AddLine(k)
				line.freq = row.freq
				line.faction = k
				
			end
		end
		
		local buttonDelFreq = vgui.Create("DButton", panel1)
		buttonDelFreq:Dock(TOP)
		buttonDelFreq:SetText("Remove from Encrypted")
		buttonDelFreq.DoClick = function()
			if (listView1:GetSelected() && listView1:GetSelected()[1]) then
				netstream.Start("delEncryptedFrequency", listView1:GetSelected()[1].freq)
				surface.PlaySound("UI/buttonclick.wav")
				frame:Close()
			end
		end

		local miniPanel1 = vgui.Create("DPanel", panel1)
		miniPanel1:SetHeight(22)
		miniPanel1:Dock(TOP)
		
		local textEntry1 = vgui.Create("DTextEntry", miniPanel1)
		textEntry1:SetWidth(170)
		textEntry1:Dock(LEFT)
		
		local addButton1 = vgui.Create("DButton", miniPanel1)
		addButton1:SetWidth(30)
		addButton1:SetText("Add")
		addButton1:Dock(LEFT)
		addButton1.DoClick = function()
			local freq = textEntry1:GetValue()
			if (freq && #freq > 0) then
				netstream.Start("addEncryptedFrequency", freq)
				surface.PlaySound("UI/buttonclick.wav")
				frame:Close()
			end
		end
		
		local panel2 = vgui.Create("DPanel", frame)
		panel2:SetWidth(200)
		panel2:Dock(LEFT)
		
		local listView2 = vgui.Create("DListView", panel2)
		listView2:SetHeight(400)
		listView2:Dock(TOP)
		listView2:AddColumn("Faction")
		frame.listView2 = listView2

		local buttonDelFaction = vgui.Create("DButton", panel2)
		buttonDelFaction:Dock(TOP)
		buttonDelFaction:SetText("Remove faction from Frequency")
		buttonDelFaction.DoClick = function()
			if (listView2:GetSelected() && listView2:GetSelected()[1]) then
				netstream.Start("delEncryptedFrequencyFaction", listView2:GetSelected()[1].freq, listView2:GetSelected()[1].faction)
				surface.PlaySound("UI/buttonclick.wav")
				frame:Close()
			end
		end
		
		local miniPanel2 = vgui.Create("DPanel", panel2)
		miniPanel2:SetHeight(22)
		miniPanel2:Dock(TOP)
		
		local textEntry2 = vgui.Create("DTextEntry", miniPanel2)
		textEntry2:SetWidth(170)
		textEntry2:Dock(LEFT)
		
		local addButton2 = vgui.Create("DButton", miniPanel2)
		addButton2:SetWidth(30)
		addButton2:SetText("Add")
		addButton2:Dock(LEFT)
		addButton2.DoClick = function()
			local faction = textEntry2:GetValue()
			if (listView1:GetSelected() && listView1:GetSelected()[1] && faction && #faction > 0) then
				netstream.Start("addEncryptedFrequencyFaction", listView1:GetSelected()[1].freq, faction)
				surface.PlaySound("UI/buttonclick.wav")
				frame:Close()
			end
		end

		local panel3 = vgui.Create("DPanel", frame)
		panel3:SetSize(200)
		panel3:Dock(LEFT)
		
		local listView3 = vgui.Create("DListView", panel3)
		listView3:Dock(FILL)
		listView3:AddColumn("Faction ID List")
		listView3.OnRowSelected = function(pnl, tx, row)
			textEntry2:SetValue(row.faction)
		end
		
		for k,v in pairs (nut.faction.indices) do
			local line = listView3:AddLine(v.uniqueID)
			line.faction = v.uniqueID
		end
		
		for k,v in pairs(EncryptedFreq) do
			local line = listView1:AddLine(k)
			line.freq = k
			freqPanels[k] = line
		end
		
		if (selectItem && freqPanels[selectItem]) then
			listView1:SelectItem(freqPanels[selectItem])
		end
	end)
end

nut.command.add("radioencryption", {
	syntax = "",
	adminOnly = true,
	onRun = function(client, arguments)
		netstream.Start(client, "EncryptedFreqMenu", EncryptedFrequencies)
	end
})
