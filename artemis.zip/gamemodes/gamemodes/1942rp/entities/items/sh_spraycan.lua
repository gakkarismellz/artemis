ITEM.name = "Spray Can"
ITEM.desc = "sprayCanDesc"
ITEM.model = "models/Items/battery.mdl"
ITEM.price = 500