ENT.Type = "anim"
ENT.PrintName	= "Taxi NPC"
ENT.Author	= "Typhon Networks"
ENT.Category = "Typhon NPCs"

ENT.Spawnable	= true
ENT.AdminOnly	= true