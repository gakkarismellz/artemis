ITEM.name = "Empty Pot"
ITEM.uniqueID = "pot_empty"
ITEM.model = "models/props_junk/terracotta01.mdl"
ITEM.desc = "An empty pot."
ITEM.width = 2
ITEM.height = 2
ITEM.price = 10
ITEM.permit = "permit_fake"
ITEM.category = "Miscellaneous"
ITEM.data = { producing2 = 0, growth = 0 }
ITEM.color = Color(50, 255, 50)

ITEM.functions.Plant = {
	name = "Plant Weed",
	icon = "icon16/cog.png",
	sound = "buttons/lightswitch2.wav",
	onRun = function(item)
		local client = item.player
		local position = client:getItemDropPos()
		local inventory = client:getChar():getInv()
		
		local seed = inventory:hasItem("drug_weed_seed")	
		local soil = inventory:hasItem("soil")	
			
		if (!seed or !soil) then
			client:notifyLocalized("You need a soil and seeds!") return false
		end
			
		seed:remove()
		soil:remove()
			
		if(!inventory:add("drug_weed_plant")) then --if the inventory has space, put it in the inventory
			nut.item.spawn("drug_weed_plant", position) --if not, drop it on the ground
		end

		return true
	end
}

ITEM.functions.Plant2 = {
	name = "Plant Poppy",
	icon = "icon16/cog.png",
	sound = "buttons/lightswitch2.wav",
	onRun = function(item)
		local client = item.player
		local position = client:getItemDropPos()
		local inventory = client:getChar():getInv()
		
		local seed = inventory:hasItem("drug_poppy_seed")	
		local soil = inventory:hasItem("soil")	
			
		if (!seed or !soil) then
			client:notifyLocalized("You need a soil and seeds!") return false
		end
			
		seed:remove()
		soil:remove()
			
		if(!inventory:add("drug_poppy_plant")) then --if the inventory has space, put it in the inventory
			nut.item.spawn("drug_poppy_plant", position) --if not, drop it on the ground
		end

		return true
	end
}