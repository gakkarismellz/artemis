ITEM.name = "Shotgun Ammo Kit"
ITEM.desc = "Allows you to switch your shotgun between Buck and Flechette ammunition."
ITEM.price = 150
ITEM.model = "models/Items/combine_rifle_cartridge01.mdl"
ITEM.give_attachment = "doi_atow_ammotypes_shotguns"
