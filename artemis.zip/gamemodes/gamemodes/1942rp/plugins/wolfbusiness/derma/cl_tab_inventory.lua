function bizInventory(panel, g)
  local biz = LocalPlayer():getChar():getBusinessInfo()
  local inv = biz:getData("inv", {})

  --Display something else if empty
  if table.Count(inv) <= 0 then
    g.noInv = panel:Add("DLabel")
    g.noInv:SetText("Nothing in your inventory yet!")
    g.noInv:SetFont("WB_Medium")
    g.noInv:SetColor(color_black)
    g.noInv:SizeToContents()
    g.noInv:Center()
    return
  end


  g.scroll = panel:Add("WScrollList")
  g.scroll:SetSize(panel:GetWide(), panel:GetTall())
  local list = g.scroll:GetList()
  for k,v in pairs(inv) do
    local item = BUSINESS_PRODUCTS[k]
    local p = list:Add("DPanel")
    p:SetSize(list:GetWide(), 80)
    function p:Paint(w,h)
      draw.RoundedBox(0,0,0,w,h,Color(240,240,240))
    end

    p.model = p:Add("DModelPanel")
    p.model:SetModel(item.model)
    p.model:SetSize(p:GetTall(), p:GetTall())
    p.model:SetLookAt(p.model.Entity:OBBCenter())
    function p.model:LayoutEntity(ent)
      ent:SetAngles(Angle(0,45,0))
    end

    p.name = p:Add("DLabel")
    p.name:SetText(k)
    p.name:SetFont("WB_Small")
    p.name:SetColor(color_black)
    p.name:CenterHorizontal(0.20)
    p.name:CenterVertical()

    p.count = p:Add("DLabel")
    p.count:SetText("Count:" .. v)
    p.count:SetFont("WB_Small")
    p.count:SetColor(color_black)
    p.count:Center()

    p.spawn = p:Add("WButton")
    p.spawn:SetWide(165)
    p.spawn.round = 0
    p.spawn:SetAccentColor(BC_NEUTRAL)
    p.spawn:Dock(RIGHT)
    function p.spawn:DoClick()
      self:SetDisabled(true) --Disable for no spamming

      if item.crateSpawn then
        Empty_Popup(function(panel)
          local wp = panel:GetWorkPanel()
          
          local amtSel = wp:Add("DNumSlider") --Amount selector
          amtSel:SetSize(wp:GetWide() - 100, 100)
          amtSel:SetText("Amount")
          amtSel:SetMinMax(1,v)
          amtSel:SetValue(1)
          amtSel:SetDecimals(0)
          amtSel.TextArea:SetTextColor(color_white)
          amtSel:Center()

          local done = wp:Add("WButton")
          done:SetAccentColor(BC_NEUTRAL)
          done:SetText("Spawn")
          done.corners = {false,false,true,true}
          done:SetSize(wp:GetWide(), 30)
          done:SetPos(0, wp:GetTall()-done:GetTall())
          function done:DoClick()
            netstream.Start("bizSpawnShipment", k, amtSel:GetValue())
            panel:Close()
          end
        end)
      else
        netstream.Start("bizSpawnShipment", k, 1)
        self:Flash("Spawned!", BC_WARNING, 2, true)
        nut.gui.menu:AlphaTo(0,0.2,0.5,function() nut.gui.menu:Remove() end)
      end
    end

    --Change spawn text if create spawn
    if item.crateSpawn then
      p.spawn:SetText("Spawn Crate")
    else
      p.spawn:SetText("Spawn")
    end
  end
end
