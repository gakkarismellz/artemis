local function ClothingChooser(charPos, charAng, camPos, camAng)

	-- local CAMPOS = camPos or Vector(816.520569,-104.082191,-79.968796) --Temp
	-- local CAMANG = camAng or Angle(3.138972,4.567669,0.000000) --Temp
	-- local CEPOS =  charPoss or Vector(960.227051,-105.041985,-135)
	-- local CEANG = charAng or Angle(6.717735,165.053421,0.000000)

	local dummy = ents.CreateClientProp()
	dummy:Spawn()
	dummy:SetPos(charPos)
	dummy:SetAngles(charAng)
	dummy:SetSolid(SOLID_VPHYSICS)
	dummy:SetMoveType(MOVETYPE_VPHYSICS)
	dummy:SetModel(LocalPlayer():GetModel())
	dummy:SetSequence(2)

	--Camera View
	local CCPos,CCAng
	hook.Add("CalcView", "ClothingView", function(ply, origin, angles, fov)
		local view = {}
		view.origin = CCPos or origin
		view.angles = CCAng or angles
		view.fov = fov
		view.drawviewer = false

		ply:DrawViewModel(false)

		return view
	end)

	local frame = vgui.Create("DPanel")
	frame:SetSize(ScrW()*0.25, ScrH())
	frame:MakePopup()

	--Some useful vars
	frame.bgs = {}
	frame.model = LocalPlayer():GetModel()
	frame.err = false
	frame.errStr = ""
	frame.camStart = CurTime()
	frame.camDur = 0.8
	function frame:Paint(w,h)
		nut.util.drawBlur(self,8)
		draw.RoundedBox(4, 0, 0, w, h, Color(80,80,80,50))

		--Camera Lerp/Think
		if CurTime() <= self.camStart+self.camDur then
			local dt = math.TimeFraction(self.camStart, self.camStart+self.camDur, CurTime())
			local lvec = LerpVector(dt, LocalPlayer():GetPos()+LocalPlayer():GetViewOffset(), camPos)
			local lang = LerpAngle(dt, LocalPlayer():GetAngles(), camAng)
			CCPos,CCAng = lvec,lang
		end

		--Error Drawing
		if self.err then
			surface.SetDrawColor(BC_CRITICAL)
			draw.NoTexture()
			surface.DrawPoly({
				{x=w/2,y=h/2-125},
				{x=w/2+80,y=h/2},
				{x=w/2-80,y=h/2}
			})

			draw.DrawText(self.errStr, "WB_Small", w/2, h/2+60, color_white, TEXT_ALIGN_CENTER)
		end
	end
	function frame:OnRemove()
		hook.Remove("CalcView", "ClothingView")
		dummy:Remove()
	end
	function frame:OnKeyCodePressed(key)
		if key == KEY_F1 then
			self:Remove()
		end
	end

	--Buy Button
	frame.buy = frame:Add("DButton")
	frame.buy:SetSize(frame:GetWide(), 45)
	frame.buy:SetPos(0,frame:GetTall()-frame.buy:GetTall())
	frame.buy:SetText("Buy")
	frame.buy:SetFont("WB_Medium")
	frame.buy:SetColorAcc(Color(250,250,250,50))
	frame.buy:SetupHover(Color(250,250,250,80))
	frame.buy.payScreen = false
	function frame.buy:Paint(w,h)
		if not self:IsEnabled() then
			self:SetTextColor(Color(60,60,60))
			draw.RoundedBox(0, 0, 0, w, h, Color(120,100,100,75))
			return
		end

		draw.RoundedBox(0, 0, 0, w, h, self.color)
		self:SetTextColor(color_white)
	end
	function frame.buy:DoClick()
		self:GInflate()
		self.payScreen = true

		frame.scroll:LayeredFade(function()
			frame.scroll:Hide()

			local price = 0
			price = price + BASE_ADDITIVE_PRICE * table.Count(frame.bgs)
			if frame.model ~= LocalPlayer():GetModel() then
				price = price + BASE_CLOTHING_PRICE
			end
			
			local totalPnl = frame:Add("DPanel")
			totalPnl:SetSize(frame:GetWide(),50)
			totalPnl:Center()
			function totalPnl:Paint(w,h)
				draw.RoundedBox(0, 0, 0, w, h, Color(80,80,80,150))
			end

			local total = totalPnl:Add("DLabel")
			total:SetText("Total: " .. nut.currency.symbol .. " " .. price)
			total:SetFont("WB_Medium")
			total:SizeToContents()
			total:Center()

			--Changing Buy Button
			self.Think = nil
			self:SetColor(BC_NEUTRAL)
			self:SetColorAcc(BC_NEUTRAL)
			self:SetupHover(WB:ColorBrighten(BC_NEUTRAL))
			self:SetText("Complete Purchase")
			function self:DoClick()
				self:GInflate()

				netstream.Start("BuyOutfit", frame.bgs, frame.model, price)
				frame:AlphaTo(0, 0.2, 0.2, function()
					frame:Remove()
				end)
			end
		end)
	end
	function frame.buy:Think()
		if frame.model ~= LocalPlayer():GetModel() or table.Count(frame.bgs) >= 1 then
			self:SetDisabled(false)
		else
			self:SetDisabled(true)
		end
	end

	--Showing clothing item
	frame.scroll = frame:Add("DScrollPanel")
	frame.scroll:SetSize(frame:GetWide(), frame:GetTall()-frame.buy:GetTall())
	frame.list = frame.scroll:Add("DIconLayout")
	frame.list:SetSize(frame.scroll:GetSize())
	function frame.scroll:LayeredFade(callback)
		self.ogw,self.ogh = self:GetSize()
		self:SizeTo(self:GetWide()*4, self:GetTall()*4, 0.2, 0.3, -1)
		self:AlphaTo(0, 0.2, 0.2, callback)

		function self:Think()
			frame.list:SetSize(self:GetSize())
		end
	end

	local ogModel = LocalPlayer():GetModel()
	local startp,endp = ogModel:lower():find("male")
	if not startp then
		frame.err = true
		frame.errStr = "Model is invalid."
		return
	end
	local modelClass = ogModel:sub(startp, endp+3)
	
	for k,v in pairs(CLOTHING.Suits) do
		if k == "shorts" then continue end
		local b = frame.list:Add("DButton")
		b:SetText(k)
		b:SetFont("WB_Medium")
		b:SetColor(color_white)
		b:SetColorAcc(Color(250,250,250,60))
		b:SetupHover(Color(250,250,250,80))
		function b:Think()
			self:SetSize(frame.list:GetWide(), 50)
		end
		function b:Paint(w,h)
			draw.RoundedBox(0, 0, 0, w, h, self.color)
			if dummy.mdlIndex and dummy.mdlIndex == k then
				surface.SetDrawColor(color_white)
				surface.DrawRect(0, 0, 2, h)

				surface.DrawLine(w-20, 5, w-5, h/2)
				surface.DrawLine(w-20, h-5, w-5, h/2)
			end
		end
		function b:DoClick()
			if dummy.mdlIndex == k then
				self:GInflate()
				
				frame.scroll:LayeredFade(function()
					frame.scroll:Hide() 
					ShowBodyGroupPanel(frame, dummy)
				end)
				
			else
				for _,mdl in pairs(v) do
					if mdl:find(modelClass) then
						dummy:SetModel(mdl)
						dummy:ResetSequence(2)
						frame.model = mdl

						dummy.mdlIndex = k
						break
					end
				end
			end
		end
	end
end

netstream.Hook("OpenClothingChooser", ClothingChooser)

concommand.Add("cc", function()
	ClothingChooser()
end)