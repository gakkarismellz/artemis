ITEM.name = "Baking Powder"
ITEM.model = "models/the_cocaine_factory/utility/soda.mdl"
ITEM.desc = "A 500g box of Baking Powder."
ITEM.uniqueID = "bakingsoda"
ITEM.noBusiness = true
