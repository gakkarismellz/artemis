ITEM.name = "Desk"
ITEM.desc = "Generic Desk"
ITEM.uniqueID = "prop_desk"
ITEM.model = "models/props_interiors/Furniture_Desk01a.mdl"
ITEM.price = 100