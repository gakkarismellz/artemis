ITEM.name = "Fire Axe"
ITEM.desc = "A wooden axe with a hardened steel blade."
ITEM.model = "models/weapons/tfa_nmrih/w_me_axe_fire.mdl"
ITEM.class = "weapon_hl2axe"
ITEM.weaponCategory = "primary"
ITEM.width = 1
ITEM.height = 3
ITEM.price = 50
ITEM.permit = "permit_gen"

ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}