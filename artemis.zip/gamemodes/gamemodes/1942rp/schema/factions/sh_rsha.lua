FACTION.name = "Reichssicherheitshauptamt"
FACTION.desc = ""
FACTION.color = Color(153,0,0)
FACTION.isDefault = false
FACTION.models = {}
FACTION.isGloballyRecognized = false

FACTION_rsha = FACTION.index
