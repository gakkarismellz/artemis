FACTION.name = "Nationalsozialistische Deutsche Arbeiterpartei"
FACTION.desc = "The members of the Third German Reich."
FACTION.color = Color(255, 170, 0)
FACTION.isDefault = false
FACTION.models = {
	"models/nazirp/group03/female_01.mdl",
	"models/nazirp/group03/female_02.mdl",
	"models/nazirp/group03/female_06.mdl",
	"models/nazirp/group03/female_07.mdl",
	"models/nazirp/group03/female_08.mdl",
	"models/nazirp/group03/female_09.mdl",
	"models/nazirp/group03/male_02.mdl",
	"models/nazirp/group03/male_04.mdl",
	"models/nazirp/group03/male_06.mdl",
	"models/nazirp/group03/male_07.mdl",
	"models/nazirp/group03/male_08.mdl",
	"models/nazirp/group03/male_09.mdl"
}
FACTION.isGloballyRecognized = false

FACTION_ssver = FACTION.index
