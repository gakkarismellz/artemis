local PLUGIN = PLUGIN
PLUGIN.name = "Door Snapshots"
PLUGIN.author = "Killing Torcher"
PLUGIN.desc = "Saves a snapshot of doors based on position"
PLUGIN.authorizedRanks = {
	senioradmin = true,
	superadmin = true,
	headadmin = true,
	communitymanager = true,
	founder = true
}

PLUGIN.canOverwrite = {
	founder = true
}

timer.Simple(5, function()
	if (string.Explode(":", game.GetIPAddress())[2] == "27018") then
		PLUGIN.authorizedRanks = {
			senioradmin = true,
			superadmin = true,
			headadmin = true,
			communitymanager = true,
			founder = true,
			admin = true,
			moderator = true
		}
		
		if (SERVER && ktAC) then
			ktAC.Log("Authorized ranks for door snapshot plugin are in dev mode.")
		end
	end
end)

nut.command.add("baddoorcount", {
	syntax = "",
	adminOnly = true,
	onRun = function(client, arguments)
		if (!PLUGIN.authorizedRanks[client:GetUserGroup()]) then
			return "You are not authorized to use this command."
		end
		
		local count = 0
		
		for k,v in pairs(ents.GetAll()) do
			if (!IsValid(v) || !v:isDoor()) then continue end
			if (v:getNetVar("disabled") || v:getNetVar("hidden") || v:getNetVar("noSell") || v:getNetVar("faction")) then continue end // Considered to be set-up
			
			count = count + 1
		end
		
		return Either(count == 0, "There are no doors left to be set up!", "There are " .. count .. " doors remaining to be set-up.")
	end
})

nut.command.add("findbaddoor", {
	syntax = "<noPopup>",
	adminOnly = true,
	onRun = function(client, arguments)
		if (!PLUGIN.authorizedRanks[client:GetUserGroup()]) then
			return "You are not authorized to use this command."
		end
		
		local closest
		local closestDistance = -1
		for k,v in pairs(ents.GetAll()) do
			if (!IsValid(v) || !v:isDoor()) then continue end
			if (v:getNetVar("disabled") || v:getNetVar("hidden") || v:getNetVar("noSell") || v:getNetVar("faction")) then continue end // Considered to be set-up
			
			local dist = v:GetPos():Distance(client:GetPos())
			if (closestDistance == -1 || dist < closestDistance) then
				closestDistance = dist
				closest = v
			end
		end
		
		if (!IsValid(closest)) then
			return "There are no more doors waiting to be set-up."
		else
			netstream.Start(client, "ShowBadDoor", closest:GetPos())
			if (arguments[1]) then return end
			return "The closest door awaiting set up will be displayed on your hud for 30 seconds!"
		end
	end
})

if (CLIENT) then
	netstream.Hook("ShowBadDoor", function(doorPos)
		ShowBadDoor = doorPos
		ShowBadDoorTime = SysTime() + 30
	end)
	
	function PLUGIN:HUDPaint()
		local client, sx, sy, scrPos, marginx, marginy, x, y, teamColor, distance, factor, size, alpha
		local dimDistance = 1024
		client = LocalPlayer()
		

		if (ShowBadDoor) then
			if (SysTime() > ShowBadDoorTime) then
				ShowBadDoor = nil
				return
			end
			
			sx, sy = surface.ScreenWidth(), surface.ScreenHeight()
			
			scrPos = ShowBadDoor:ToScreen()
			marginx, marginy = sx*.1, sy*.1
			x, y = math.Clamp(scrPos.x, marginx, sx - marginx), math.Clamp(scrPos.y, marginy, sy - marginy)
			teamColor = Color(255, 100, 100)
			distance = client:GetPos():Distance(ShowBadDoor)
			factor = 1 - math.Clamp(distance/dimDistance, 0, 1)
			size = math.max(10, 32*factor)
			alpha = math.Clamp(255*factor, 80, 255)
			
			surface.SetDrawColor(teamColor.r, teamColor.g, teamColor.b, alpha)
			surface.DrawLine(sx * 0.5, sy * 0.5, x, y)
			surface.DrawLine(x - size/2, y - size/2, x + size/2, y + size/2, 2)
			surface.DrawLine(x + size/2, y - size/2, x - size/2, y + size/2, 2)

			nut.util.drawText("Bad Door", x, y - size, ColorAlpha(teamColor, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, nil, alpha)

		end
	end
end
nut.util.include("sv_doorsnapshots.lua")
nut.util.include("cl_doorsnapshots.lua")