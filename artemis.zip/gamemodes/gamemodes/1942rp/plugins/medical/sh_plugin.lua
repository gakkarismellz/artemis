PLUGIN.name = "Medical Base"
PLUGIN.author = ""
PLUGIN.desc = ""