function bizShowWorkerMenu(panel)
	local biz = LocalPlayer():getChar():getBusinessInfo()
	local char = LocalPlayer():getChar()

	--Display Business Name
	local fd = bizName(panel)
	fd.fdName:SetText(biz.name)
	fd.fdDesc:SetText(biz.data.desc)
	
	--Workable menu
	local g = group()
	g.panel = panel:Add("DPanel")
	g.panel:SetSize(panel:GetWide(), panel:GetTall() * 0.75)
	g.panel:SetPos(0, panel:GetTall() - g.panel:GetTall())
	function g.panel:Paint(w,h)
		draw.RoundedBox(0, 0, 0, w, h, Color(0,0,0,80))
	end

	--Panel Title
	g.title = g.panel:Add("DLabel")
	g.title:SetText("Worker's Menu")
	g.title:SetFont("WB_Medium")
	g.title:SetColor(color_white)
	g.title:SetSize(g.panel:GetWide(), 25)
	g.title:SetContentAlignment(5)
	function g.title:Paint(w,h)
		draw.RoundedBoxEx(0, 0, 0, w, h, Color(0,0,0,150))
	end

	--Player Rank
	local rank = char:getBusinessRank()
	g.rank = g.panel:Add("DLabel")
	g.rank:SetText("Your Current Rank: " .. L(BUSINESS_RANK_NAME[rank]))
	g.rank:SetFont("WB_Large")
	g.rank:SetColor(color_white)
	g.rank:SizeToContents()
	g.rank:SetPos(15,40)

	--Player Salary
	g.sal = g.panel:Add("DLabel")
	g.sal:SetText("Your Current Salary: " .. biz:getData("salary_" .. rank, DEFAULT_SALARY) .. nut.currency.symbol)
	g.sal:SetFont("WB_Large")
	g.sal:SetColor(color_white)
	g.sal:SetPos(g.rank:GetX(), g.rank:GetY() + g.rank:GetTall() + 15)
	g.sal:SizeToContents()

	--Player Resign
	g.res = g.panel:Add("WButton")
	g.res:SetText("Resign")
	g.res:SetSize(150,30)
	g.res:SetAccentColor(BC_WARNING)
	g.res:CenterHorizontal()
	g.res:CenterVertical(0.75)
	function g.res:DoClick()
		Choice_Request("Are you sure you want to resign", function()
			netstream.Start("nutBizExit")
			timer.Simple(0.5, function()
				nut.gui.menu:AlphaTo(0, 0.2, 0, function()
					nut.gui.menu:Remove()
				end)
			end)
		end)
	end
end