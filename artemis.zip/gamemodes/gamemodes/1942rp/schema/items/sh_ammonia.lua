ITEM.name = "Ammonia"
ITEM.model = "models/winningrook/gtav/meth/ammonia/ammonia.mdl"
ITEM.desc = "A white jug of ammonia, a liquid compound of nitrogen and hydrogen."
ITEM.uniqueID = "ammonia"
ITEM.price = 20
ITEM.width = 2
ITEM.height = 2
ITEM.noBusiness = true
