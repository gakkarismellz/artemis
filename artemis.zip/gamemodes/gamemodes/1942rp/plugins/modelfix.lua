PLUGIN.name = "Model Fix"
PLUGIN.desc = "Replaces outdated citizen models with the new ones."
PLUGIN.author = "Zoephix"

PLUGIN.models = {
	["models/player/zelpa/female_01_b_extended.mdl"] = "models/stahl/humans/female/female_01.mdl",
	["models/player/zelpa/female_02_b_extended.mdl"] = "models/stahl/humans/female/female_02.mdl",
	["models/player/zelpa/female_04_b_extended.mdl"] = "models/stahl/humans/female/female_04.mdl",
	["models/player/zelpa/female_06_b_extended.mdl"] = "models/stahl/humans/female/female_06.mdl",
	["models/player/zelpa/male_02_extended.mdl"] = "models/player/suits/male_02_open_tie.mdl",
	["models/player/zelpa/male_04_extended.mdl"] = "models/player/suits/male_04_open_tie.mdl",
	["models/player/zelpa/male_05_extended.mdl"] = "models/player/suits/male_05_open_tie.mdl",
	["models/player/zelpa/male_06_extended.mdl"] = "models/player/suits/male_06_open_tie.mdl",
	["models/player/zelpa/male_07_extended.mdl"] = "models/player/suits/male_07_open_tie.mdl",
	["models/player/zelpa/male_08_extended.mdl"] = "models/player/suits/male_08_open_tie.mdl",
	["models/player/zelpa/male_09_extended.mdl"] = "models/player/suits/male_09_open_tie.mdl",
	["models/player/zelpa/male_10_extended.mdl"] = "models/player/suits/male_09_open_tie.mdl"
}

function PLUGIN:PlayerLoadedChar(ply, char, oldChar)
	local model = self.models[ply:GetModel()]

	if model then
		ply:SetModel(model)
		char:setModel(model)
		ply:SetupHands()
	end
end
