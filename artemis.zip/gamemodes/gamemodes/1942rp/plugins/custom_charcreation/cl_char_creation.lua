local PANEL = {}
local gradient = surface.GetTextureID("vgui/gradient-u")
local gradient2 = surface.GetTextureID("vgui/gradient-d")
local test = 0
net.Receive("gayboy",function()
	test = test  + 1
	end)
net.Receive("gayboyd",function()
	test = 0
	end)

function PANEL:Init()
	local fastMode = nut.localData.fastcharsel
	local fadeSpeed = fastMode and 0 or 1

	if (IsValid(nut.gui.loading)) then
		nut.gui.loading:Remove()
	end

	if (!nut.localData.intro && !fastMode) then
		timer.Simple(0.1, function()
			vgui.Create("nutIntro", self)
		end)
	else
		self:playMusic()
	end

	if (IsValid(nut.gui.char) or (LocalPlayer().getChar and LocalPlayer():getChar())) then
		nut.gui.char:Remove()
		fadeSpeed = 0
    end

  function self:OnKeyCodePressed(key)
    if key == KEY_F1 and fadeSpeed == 0 then
      self:Remove()
    end
  end

	nut.gui.char = self

	self:SetSize(ScrW(),ScrH())
	self:MakePopup()
	self:Center()
	self:ParentToHUD()

	self.darkness = self:Add("DPanel")
	self.darkness:Dock(FILL)
	self.darkness.Paint = function(this, w, h)
		surface.SetDrawColor(0, 0, 0)
		surface.DrawRect(0, 0, w, h)
	end
	self.darkness:SetZPos(99)
  self.darkness:AlphaTo(0, 2 * fadeSpeed, 0, function()
		self.darkness:SetZPos(-99)
	end)

  self.sideBar = self:Add("DPanel")
  self.sideBar:SetSize(self:GetWide()/4, self:GetTall())
  self.sideBar:SetPos(0,0)
  function self.sideBar:Paint(w,h)
    nut.util.drawBlur(self, 4)
    draw.RoundedBox(0,0,0,w,h,Color(33, 34, 41, 240))
  end

	self.sideBar.title = self.sideBar:Add("DLabel")
	self.sideBar.title:SetContentAlignment(5)
	-- self.sideBar.title:SetText(L2("schemaName") or SCHEMA.name or L"unknown")
	local tx = "Berlin, Germany - 1943"
	local overrideDate = nut.config.get("f1date")
	if (overrideDate) then
		tx = "Berlin, Germany - " .. overrideDate
	end
	self.sideBar.title:SetText(tx)
	self.sideBar.title:SetFont("nutBigFont")
	self.sideBar.title:SizeToContents()
  self.sideBar.title:SetPos(0, 64)
  self.sideBar.title:CenterHorizontal()
	self.sideBar.title:SetTextColor(color_white)
	self.sideBar.title:SetZPos(100)
	self.sideBar.title:SetAlpha(0)
	self.sideBar.title:AlphaTo(255, fadeSpeed, 3 * fadeSpeed)
	self.sideBar.title:SetExpensiveShadow(2, Color(0, 0, 0, 200))

	self.sideBar.subTitle = self.sideBar:Add("DLabel")
	self.sideBar.subTitle:SetContentAlignment(5)
	self.sideBar.subTitle:SetFont("nutMediumFont")
	-- self.sideBar.subTitle:SetText(L2("schemaDesc") or SCHEMA.desc or L"noDesc")
	self.sideBar.subTitle:SetText("")
	self.sideBar.subTitle:SetTextColor(Color(170, 170, 170))

	self.sideBar.subTitle:SetPos(10, 64 + self.sideBar.title:GetTall() + 10)
	self.sideBar.subTitle:SetWrap(true)
	self.sideBar.subTitle:SetSize(self.sideBar:GetWide()-20,80)

	self.sideBar.subTitle:SetAlpha(0)
	self.sideBar.subTitle:AlphaTo(255, 4 * fadeSpeed, 3 * fadeSpeed)
	self.sideBar.subTitle:SetExpensiveShadow(2, Color(0, 0, 0, 200))

	local list = self:Add("DListLayout")
	list:SetSize(self.sideBar:GetWide(),self.sideBar:GetTall()/2)
	list:CenterVertical()

	local function putWPBeside(wp, panel)
		local bx, by = list:LocalToScreen(panel:GetPos())
		wp:SetPos(self.sideBar:GetWide(), by-(wp:GetTall()/2) + (panel:GetTall()/2))
	end

	local opts = {
  	["Choose Character"] = function(panel, btnPnl)
			if LocalPlayer():IsFrozen() then return end
			if not LocalPlayer():Alive() then return end

			local fastMode = nut.localData.fastcharsel
			function panel:Paint(w,h)
				nut.util.drawBlur(self, 4)
				draw.RoundedBox(0,0,0,w,h,Color(30, 30, 30, 240))
			end

			panel:SetSize(0,200)
			putWPBeside(panel, btnPnl)

			panel:SetAlpha(0)
			panel:AlphaTo(255,fastMode and 0 or 0.3)
			panel:SizeTo(self:GetWide()-self.sideBar:GetWide(),panel:GetTall(),fastMode and 0 or 0.5,0,-1,function()
				panel.scroll = panel:Add("DScrollPanel")
				panel.scroll:SetSize(panel:GetSize())
				panel.scroll:Center()

				panel.list = panel.scroll:Add("DIconLayout")
				panel.list:SetSize(panel.scroll:GetWide()-10, panel.scroll:GetTall()-10)
				panel.list:SetPos(5,5)
				panel.list:SetSpaceX(5)

				for k,v in pairs(nut.characters) do
					local char = nut.char.loaded[v]

					local c = panel.list:Add("DButton")
					c:SetText("")
					c:SetSize(panel.list:GetTall(), panel.list:GetTall()-6)
					function c:Paint(w,h)
						draw.RoundedBox(4,0,0,w,h,Color(45, 45, 45))
					end

					c:SetAlpha(0)
					c:AlphaTo(255,fastMode and 0 or 0.2,0,function()
						c.mdl = c:Add("DModelPanel")
						c.mdl:SetSize(c:GetSize())
						c.mdl:SetModel(char:getModel())
						c.mdl:SetFOV(20)
						local head = c.mdl.Entity and IsValid(c.mdl.Entity) and c.mdl.Entity:LookupBone("ValveBiped.Bip01_Head1") --Look at the model head
				    if head and head >= 0 then
				      c.mdl:SetLookAt(c.mdl.Entity:GetBonePosition(head))
				    end
						function c.mdl:LayoutEntity(ent)
				      ent:SetAngles(Angle(0,45,0))
				      ent:ResetSequence(2)
				    end
						function c.mdl.DoClick(this)
							if LocalPlayer():getChar() and LocalPlayer():getChar():getID() == v then
								nut.util.notify("You're currently using this character", LocalPlayer())
								return
							end

							self.darkness:SetZPos(999)
							self.darkness:AlphaTo(255,fastMode and 0 or 1,0,function()
								self.darkness:AlphaTo(0,fastMode and 0 or 0.5,0,function() self.darkness:Remove() self:Remove() end)
								netstream.Start("charChoose", v)
							end)
						end

						c.name = c:Add("DLabel")
						c.name:SetSize(c:GetWide(),30)
						c.name:SetText(char:getName())
						c.name:SetFont("nutSmallFont")
						c.name:SetColor(color_white)
						c.name:SetContentAlignment(5)
						function c.name:Paint(w,h)
            	draw.RoundedBox(0,0,0,w,h,Color(30,30,30,80))
						end
					end)

					timer.Simple(fastMode and 0 or 0.2,function()
						if (!c || !IsValid(c) || !c.Add) then return end
						c.delete = c:Add("DButton")
						c.delete:SetText("Delete")
						c.delete:SetColor(color_white)
						c.delete:SetFont("nutSmallFont")
						c.delete:SetSize(c:GetWide(),25)
						c.delete:SetPos(0,c:GetTall()-c.delete:GetTall())
						c.delete:SetAlpha(0)
						c.delete:AlphaTo(255,fastMode and 0 or 0.2)
						c.delete:SetZPos(99)
						function c.delete:Paint(w,h)
							if self:IsHovered() then
								draw.RoundedBoxEx(4,0,0,w,h,Color(235,85,85),false,false,true,true)
							else
								draw.RoundedBoxEx(4,0,0,w,h,Color(225,75,75),false,false,true,true)
							end
						end
						function c.delete.DoClick(this)
							local menu = DermaMenu()
								local confirm = menu:AddSubMenu(L("delConfirm", char:getName()))
								confirm:AddOption(L"no"):SetImage("icon16/cross.png")
								confirm:AddOption(L"yes", function()
									net.Start("antiexploit")
									net.SendToServer()
									if (test > 0) then self.wp:Remove() return end
									netstream.Start("charDel", char:getID())
									self.wp:Remove()
								end):SetImage("icon16/tick.png")
							menu:Open()
						end
					end)
				end
			end)
		end,
		["Create Character"] = function(panel, btnPnl)
			function panel:Paint(w,h)
				nut.util.drawBlur(self, 4)
				draw.RoundedBox(0,0,0,w,h,Color(30, 30, 30, 240))
			end

			panel:SetSize(0,500)
			putWPBeside(panel, btnPnl)

			local payload = {}

			panel:SetAlpha(0)
			panel:AlphaTo(255,0.3)
			panel:SizeTo(self:GetWide()-self.sideBar:GetWide(),panel:GetTall(),0.5,0,-1,function()
				local function fillInfo()
					local mdl = panel:Add("DModelPanel")
					mdl:SetSize(panel:GetWide()/3,panel:GetTall())
					mdl:SetModel(nut.faction.indices[payload.faction].models[payload.model])
					if (IsValid(mdl.Entity)) then
						mdl.Entity:SetAngles(Angle(0, 60, 0))
					end
					mdl:SetFOV(50)
					mdl:SetAlpha(0)
					mdl:AlphaTo(255,0.2)
					local head = mdl.Entity:LookupBone("ValveBiped.Bip01_Head1") --Look at the model head
					
					if head and head >= 0 then
					  mdl:SetLookAng(Angle(0, 180, 0))
					  mdl:SetCamPos(mdl.Entity:GetBonePosition(head) + Vector(100, 0, -10))
					end
					
					mdl.LayoutEntity = function(pnl, ent)
						ent:ResetSequence(2)
						
						if (!IsValid(pnl:GetEntity())) then
							pnl.Dragging = nil
						else
							if (!pnl.Dragging && input.IsMouseDown(MOUSE_LEFT) && pnl:IsHovered()) then
								pnl.Dragging = true
								
								pnl.DragStartX, pnl.DragStartY = input.GetCursorPos()
								pnl.StartAngles = pnl:GetEntity():GetAngles()
							elseif (pnl.Dragging && !input.IsMouseDown(MOUSE_LEFT)) then
								pnl.Dragging = nil
							elseif (pnl.Dragging) then
								local curX, curY = input.GetCursorPos()
								local deltaX, deltaY = curX - pnl.DragStartX, curY - pnl.DragStartY
								
								pnl:GetEntity():SetAngles(pnl.StartAngles + Angle(0, deltaX, 0))
							end
						end
					end
					
					
					
					mdl.PaintOver = function(pnl, w, h)
						draw.RoundedBox(0,w-3,0,3,h,Color(100, 100, 100))
						draw.SimpleText("Drag to Rotate", "nutSmallFont", 5, h, color_white, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
					end
					
					local bodyGroupCombos = {}
					
					if (IsValid(mdl.Entity)) then
						mdl:SetHeight(panel:GetTall()/2)
						local bodyGroupsPanel = panel:Add("DScrollPanel")
						bodyGroupsPanel:SetPos(0, panel:GetTall()/2)
						bodyGroupsPanel:SetSize(panel:GetWide()/3, panel:GetTall()/2)
						
						for k,v in pairs(mdl.Entity:GetBodyGroups()) do
							if (v.num > 1) then
								local bgPartPanel = vgui.Create("DPanel", bodyGroupsPanel)
								bgPartPanel:Dock(TOP)
								bgPartPanel:SetHeight(30)
								bgPartPanel:DockPadding(5, 5, 5, 0)
								bgPartPanel:DockMargin(0, 5, 0, 0)
								
								local nameLbl = vgui.Create("DLabel", bgPartPanel)
								nameLbl:Dock(LEFT)
								nameLbl:SetFont("nutMediumFont")
								nameLbl:SetText(v.name)
								nameLbl:SizeToContents()
								
								local comboPanel = vgui.Create("DComboBox", bgPartPanel)
								comboPanel:SetWidth(panel:GetWide()/6)
								comboPanel.bodyGroupID = v.id
								comboPanel:Dock(RIGHT)
								table.insert(bodyGroupCombos, comboPanel)
								
								function comboPanel:Paint(w,h)
									draw.RoundedBox(4,0,0,w,h,Color(200,200,200))
								end
								
								local first = true
								for submodelID, submodelName in pairs(v.submodels) do
									local nameRaw = string.StripExtension(submodelName)
									if (!nameRaw || nameRaw == "") then
										nameRaw = "(No name)"
									end
									
									comboPanel:AddChoice(nameRaw, submodelID, first)
									
									if (first) then
										first = false
									end
								end
								
								function comboPanel:OnSelect(index, value, data)
									if (IsValid(mdl.Entity)) then
										mdl.Entity:SetBodygroup(comboPanel.bodyGroupID, data)
									end
								end
							end
						end
					end
					


					--Basic Informations
					local basicInfos = panel:Add("DPanel")
					basicInfos:SetSize(panel:GetWide()-mdl:GetWide(),170)
					basicInfos:SetPos(mdl:GetWide(),0)
					function basicInfos:Paint(w,h)
						draw.RoundedBox(0,0,h-3,w,3,Color(100,100,100))
					end

					basicInfos.title = basicInfos:Add("DLabel")
					basicInfos.title:SetText("Basic Information")
					basicInfos.title:SetFont("nutMediumFont")
					basicInfos.title:SetColor(color_white)
					basicInfos.title:SizeToContents()
					basicInfos.title:SetPos(5,10)

					local function styleTE(te)
						function te:Paint(w,h)
							if self:HasFocus() then
								draw.RoundedBox(4,0,0,w,h,color_white)
							else
								draw.RoundedBox(4,0,0,w,h,Color(210, 210, 210))
							end
							self:DrawTextEntryText(color_black,nut.config.get("color"),color_black)
						end
					end

					local nameEntry = basicInfos:Add("DTextEntry")
					nameEntry:SetSize(200,30)
					nameEntry:SetPos(((basicInfos:GetWide()/2)/2)-nameEntry:GetWide()/2, basicInfos:GetTall()/2-nameEntry:GetTall()/2 +20)
					styleTE(nameEntry)

					local refreshBtn = basicInfos:Add("DButton")
					refreshBtn:SetSize(30, 30)
					refreshBtn:SetPos(((basicInfos:GetWide()/2)/2)+nameEntry:GetWide()/2, basicInfos:GetTall()/2-nameEntry:GetTall()/2 +20)
					refreshBtn.IconMaterial = Material("icon16/arrow_refresh.png")
					refreshBtn:SetTooltip("Generate a new random name")
					refreshBtn:SetText("")
					refreshBtn.Paint = function(pnl, w, h)
						surface.SetDrawColor(color_white)
						surface.SetMaterial(refreshBtn.IconMaterial)
						surface.DrawTexturedRect(w/2 - 8, h/2 - 8, 16, 16)
					end
					
					refreshBtn.DoClick = function()
						if (g_randomNamePopulating) then return end
						g_randomNamePopulating = true
						
						local mdlString = nut.faction.indices[payload.faction].models[payload.model]
						
						local queryUrl = "https://randomname.de/?format=json&count=1&gender="
						if (mdlString:find("female", 1, true)) then 
							queryUrl = queryUrl .. "f"
						else 
							queryUrl = queryUrl .. "m"
						end
						
						local blockPanel = vgui.Create("DPanel", nameEntry)
						blockPanel.Paint = function(pnl, w, h) 
							surface.SetDrawColor(Color(0, 0, 0, 150)) 
							surface.DrawRect(0, 0, w, h)
						end
						blockPanel:Dock(FILL)
						
						http.Fetch(queryUrl, function(body)
							g_randomNamePopulating = nil
							if (IsValid(blockPanel)) then blockPanel:Remove() end
							
							local tbl = util.JSONToTable(body)
							
							if (!tbl || !tbl[1] || !tbl[1].firstname || !tbl[1].lastname) then
								nut.util.notify("Name API returned Invalid Format. Response printed to console.")
								print(body)
								return
							end
							
							nameEntry:SetValue(tbl[1].firstname .. " " .. tbl[1].lastname) 
						end,
						function(errorStr)
							nut.util.notify("Failed to query name API: " .. errorStr)
							
							g_randomNamePopulating = nil
							if (IsValid(blockPanel)) then blockPanel:Remove() end
						end)
					end
					
					refreshBtn:DoClick()
					
					local nameLabel = basicInfos:Add("DLabel")
					nameLabel:SetText("Name: ")
					nameLabel:SetFont("nutSmallFont")
					nameLabel:SetColor(color_white)
					nameLabel:SizeToContents()
					local x,y = nameEntry:GetPos()
					nameLabel:SetPos(x+nameEntry:GetWide()/2-nameLabel:GetWide()/2,y - nameLabel:GetTall()-10)

					local descEntry = basicInfos:Add("DTextEntry")
					descEntry:SetSize(200,30)
					descEntry:SetPos(((basicInfos:GetWide()/2)/2)*3-descEntry:GetWide()/2, basicInfos:GetTall()/2-descEntry:GetTall()/2 +20)
					styleTE(descEntry)


					local descLabel = basicInfos:Add("DLabel")
					descLabel:SetText("Description: ")
					descLabel:SetFont("nutSmallFont")
					descLabel:SetColor(color_white)
					descLabel:SizeToContents()
					local x,y = descEntry:GetPos()
					descLabel:SetPos(x+descEntry:GetWide()/2-descLabel:GetWide()/2,y - descLabel:GetTall()-10)

					local autoDescCheckBox = basicInfos:Add("DCheckBoxLabel")
					autoDescCheckBox:SetText("Auto-Generate")
					autoDescCheckBox:SetFont("nutSmallFont")
					autoDescCheckBox:SetTextColor(color_white)
					autoDescCheckBox:SizeToContents()
					autoDescCheckBox:SetPos(x+descEntry:GetWide()/2-autoDescCheckBox:GetWide()/2,y + autoDescCheckBox:GetTall()+20)
					function autoDescCheckBox:OnChange(bVal)
						if (!bVal && IsValid(autoDescCheckBox.blockPanel)) then
							autoDescCheckBox.blockPanel:Remove()
						elseif (bVal) then
							autoDescCheckBox.blockPanel = descEntry:Add("DPanel")
							autoDescCheckBox.blockPanel:Dock(FILL)
							autoDescCheckBox.blockPanel.Paint = function(pnl, w, h)
								surface.SetDrawColor(Color(0, 0, 0, 150))
								surface.DrawRect(0, 0, w, h)
							end
							
							descEntry:SetValue("")
						end
					end
					autoDescCheckBox:SetValue(true)
					autoDescCheckBox:SetToolTip("Warning: Uncheck this only if you understand the rules regarding descriptions.")
					
					--Additional information
					local add = panel:Add("DScrollPanel")
					add:SetSize(panel:GetWide()-mdl:GetWide(),panel:GetTall()-basicInfos:GetTall()-30)
					add:SetPos(mdl:GetWide(), basicInfos:GetTall())

					local list = add:Add("DIconLayout")
					list:SetSize(add:GetWide()-15, add:GetTall())

					local alt = true
					local values = {}
					for k,v in SortedPairs(charCharacteristics) do
						local val = list:Add("DPanel")
						val:SetSize(list:GetWide(), 40)
						val.alt = alt
						
						function val:Paint(w,h)
							if self.alt then
								draw.RoundedBox(0,0,0,w,h,Color(35,35,40))
							else
								draw.RoundedBox(0,0,0,w,h,Color(30,30,35))
							end
						end

						val.title = val:Add("DLabel")
						val.title:SetText(k)
						val.title:SetFont("nutSmallFont")
						val.title:SetColor(color_white)
						val.title:SetSize(val:GetWide()/2-10, val:GetTall())
						val.title:SetPos(10,0)

						if not istable(v) and v == "string" then
							val.edit = val:Add("DTextEntry")
							val.edit:SetSize(val:GetWide()/2-10,val:GetTall()-10)
							val.edit:SetPos(val:GetWide()/2+5,5)
							styleTE(val.edit)
						elseif not istable(v) and v == "number" then
							val.edit = val:Add("DNumberWang")
							val.edit:SetSize(val:GetWide()/2-10,val:GetTall()-10)
							val.edit:SetPos(val:GetWide()/2+5,5)
							val.edit:SetMinMax(20,100)
							val.edit:SetDecimals(0)
							val.edit:SetValue(20)
							
							if (k == "Age") then
								val.edit:SetMinMax(13, 100)
								val.edit:SetValue(20)
							elseif (k == "Weight") then
								val.edit:SetMinMax(80, 300)
								val.edit:SetValue(160)
							end
							
							function val.edit:Think()
								if self:GetValue() > self:GetMax() then
									self:SetValue(self:GetMax())
								elseif (self:GetValue() < self:GetMin()) then
									self:SetValue(self:GetMin())
								end
							end
							
							styleTE(val.edit)
						elseif istable(v) and v.valueType == "choice" then
							val.edit = val:Add("DComboBox")
							val.edit:SetSize(val:GetWide()/2-10,val:GetTall()-10)
							val.edit:SetPos(val:GetWide()/2+5,5)
							
							function val.edit:Paint(w,h)
								draw.RoundedBox(4,0,0,w,h,Color(200,200,200))
							end
							
							for _,c in pairs(v.choices) do
								local select = false
								if c == v.choices[1] then select = true end
								val.edit:AddChoice(c,nil,select)
							end
						end

						values[k] = val.edit

						alt = not alt
					end

					local finish = panel:Add("DButton")
					finish:SetText("Finish")
					finish:SetFont("nutSmallFont")
					finish:SetColor(color_white)
					finish:SetSize(panel:GetWide()-mdl:GetWide(),panel:GetTall()-basicInfos:GetTall()-add:GetTall())
					finish:SetPos(mdl:GetWide(),panel:GetTall()-finish:GetTall())
					
					function finish:Think()
						local disable = false
						for name,pnl in pairs(values) do
							if not pnl:GetValue() or pnl:GetValue() == "" or not nameEntry:GetValue() or nameEntry:GetValue() == "" or not descEntry:GetValue() or (descEntry:GetValue() == "" && autoDescCheckBox:GetChecked() == false) then
								disable = true
								break
							end
						end
						self:SetDisabled(disable)
					end
					
					function finish:Paint(w,h)
						if self:GetDisabled() then
							draw.RoundedBox(0,0,0,w,h,Color(30, 30, 30))
							return
						end

						if self:IsHovered() and not self:GetDisabled() then
							draw.RoundedBox(0,0,0,w,h,Color(50,155,205))
						else
							draw.RoundedBox(0,0,0,w,h,Color(45,150,200))
						end
					end
					
					function finish:DoClick()
						local vals = {}
						
						for k,v in pairs(values) do
							if v:GetValue() then
								vals[k] = v:GetValue()
							end
						end

						payload.data = {}
						payload.name = nameEntry:GetValue()
						
						if (!autoDescCheckBox:GetChecked()) then
							payload.desc = descEntry:GetValue()
						else
							local gender = "Male"
							if (nut.faction.indices[payload.faction].models[payload.model]:find("female", 1, true)) then
								gender = "Female"
							end
							
							local function firstLetterCap(str)
								if (#str > 0) then
									str = string.upper(str[1]) .. string.sub(str, 2, #str)
								end
								
								return str
							end

							payload.desc = vals["Age"] .. "-year-old " .. gender .. " | About " .. vals["Height"] .. " tall, weighing approximately " .. vals["Weight"] .. " lbs | " .. firstLetterCap(vals["Hair Color"]) .. " hair and " .. firstLetterCap(vals["Eye Color"]) .. " eyes"
							
							
							/*
							  ["Age"] = "number",
							  ["Date of Birth"] = "string",
							  ["Place of Birth"] = "string",
							  ["Height"] = "string",
							  ["Hair Color"] = "string",
							  ["Eye Color"] = "string",
							  ["Religion"] = "string",
							  ["Blood Type"] = {valueType = "choice", choices={"O+", "O-", "A+", "A-", "B+", "B-", "AB+", "AB-"}},
								["Occupation"] = "string",
							  ["Weight"] = "number"
							*/
						end

						payload.steamID = LocalPlayer():SteamID64()

						for k,v in SortedPairsByMemberValue(nut.char.vars, "index") do --Checking the variables
							local value = payload[k]
							v.onValidate = false
							
							if v.onValidate then
								local result = {v.onValidate(value, payload, LocalPlayer())}

								if result[1] == false then
									nut.util.notify(tostring((unpack(result,2))) or "Unknown Error", LocalPlayer())
									return
								end
							end
						end

						--Setting additonal information
						netstream.Start("setCharCharacteristics", vals, false)

						local extraData = {}
						extraData.groups = {}
						
						for k,v in pairs(bodyGroupCombos) do
							local value, data = v:GetSelected()
							extraData.groups[v.bodyGroupID] = data
						end
						
						netstream.Start("charCreate", payload, extraData)
						netstream.Hook("charAuthed", function(fault, ...) --Check for server response
							if type(fault) == "string" then
								nut.util.notify(L(fault,...))
								return
							end

							if type(fault) == "table" then --Updating the characters table
								nut.characters = fault
							end

							netstream.Start("charChoose", nut.characters[#nut.characters]) --Choose latest character
							
							local darkness = vgui.Create("DPanel")
							darkness:MakePopup()
							function darkness:Paint(w,h) 
								draw.RoundedBox(0,0,0,w,h,Color(0,0,0))
							end
							darkness:AlphaTo(255,1,1,function()
								
								nut.gui.char:Remove()

								darkness:AlphaTo(0,1,0,function()
									if darkness and IsValid(darkness) then darkness:Remove() end
								end)
							end)
						end)
					end
				end

				local function showModels(fac)
					if (!panel || !IsValid(panel) || !panel.Add) then return end
					panel.scroll = panel:Add("DScrollPanel")
					panel.scroll:SetSize(panel:GetSize())
					panel.list = panel.scroll:Add("DIconLayout")
					panel.list:SetSize(panel.scroll:GetSize())

					for k,v in pairs(fac.models) do
						local mp = panel.list:Add("DPanel")
						mp:SetSize(panel.list:GetWide()/4,panel.list:GetTall())
						mp.color = Color(0,0,0,0)
						function mp:Paint(w,h)
							draw.RoundedBox(0,0,0,w,h,self.color)
						end

						mp.mdl = mp:Add("DModelPanel")
						mp.mdl:SetSize(mp:GetSize())
						mp.mdl:SetModel(v)
						local spine = mp.mdl.Entity:LookupBone("ValveBiped.Bip01_Spine")
						if spine and spine >= 0 then
							mp.mdl:SetLookAt(mp.mdl.Entity:GetBonePosition(spine))
							mp.mdl:SetFOV(50)
						end
						function mp.mdl:LayoutEntity(ent)
							ent:ResetSequence(2)
							ent:SetAngles(Angle(0,45,0))
						end
						function mp.mdl:Think()
							if self:IsHovered() then
								mp.color = Color(55, 55, 55)
							else
								mp.color = Color(0,0,0,0)
							end
						end
						function mp.mdl:DoClick()
							for _,pnl in pairs(panel.list:GetChildren()) do
								pnl:AlphaTo(0,0.2,0,function()
									if pnl and IsValid(pnl) then
										pnl:Remove()
									end
								end)
							end

							payload.model = k
							fillInfo()
						end
					end
				end

				local function chooseFaction()
					local facs = {}
					local wlists_raw = (LocalPlayer():getNutData("whitelists", {}))
					for k,v in pairs(nut.faction.indices) do --Looking for joinable factions
						if (v.isDefault == nil or v.isDefault == true) or (wlists_raw[SCHEMA.folder] != nil && wlists_raw[SCHEMA.folder][v.uniqueID] == true) then
							facs[#facs+1] = k
						end
					end

					panel.title = panel:Add("DLabel")
					panel.title:SetText("Choose your faction")
					panel.title:SetFont("nutMediumFont")
					panel.title:SetColor(color_white)
					panel.title:SetPos(10,10)
					panel.title:SizeToContents()

					--Displaying buttons
					local count = 0
					local maxcolumn = 6
				
					local buts = {}
					local fPanel = panel:Add("DPanel")
					fPanel:SetSize(panel:GetWide(), panel:GetTall())
					fPanel:SetPos(0, 0)
					fPanel.Paint = nil
					for k,v in pairs(facs) do
						local fac = nut.faction.indices[v]

						local f = fPanel:Add("DButton")
						f:SetText(fac.name)
						f:SetFont("nutSmallFont")
						f:SetColor(color_white)
						f:SetSize(200,40)
						f:SetPos(15 + 215 * math.floor(count / maxcolumn) + panel:GetWide()/2 - (math.ceil(#facs / maxcolumn) * 215 + 15)/2, 50 + count % maxcolumn * 65)
						function f:Paint(w,h)
							if self:IsHovered() then
								draw.RoundedBox(0,0,0,w,h,fac.color)
							else
								draw.RoundedBox(0,0,0,w,h,Color(fac.color.r-5,fac.color.g-5,fac.color.b-5))
							end
						end
						function f:DoClick()
							payload.faction = v
							panel.title:AlphaTo(0,0.5,0,function() if panel.title and IsValid(panel.title) then panel.title:Remove() end end)
							for _,pnl in pairs(buts) do
								pnl:AlphaTo(0,0.2,0,function()
									pnl:Remove()
								end)
							end

							timer.Simple(0.4, function()
								showModels(fac)
							end)
						end

						buts[#buts+1] = f
						count = count+1
					end

				end
				chooseFaction()
			end)
		end,
		["Disconnect"] = function()
			RunConsoleCommand("disconnect")
		end
  }

	--Display the tabs
	local curTab
	local function createWorkPanel(callback)
		local delay = 0
		if self.wp and IsValid(self.wp) then
			self.wp:AlphaTo(0,0.2,0,function()
				if self.wp and IsValid(self.wp) then self.wp:Remove() end
			end)

			delay = 0.3
		end

		local wp = self:Add("DPanel")
		wp:SetSize(self:GetWide()-self.sideBar:GetWide(),self:GetTall())
		wp:SetPos(self.sideBar:GetWide(),0)
		wp.Paint = nil
		wp:SetAlpha(0)
		wp:AlphaTo(255,0.2,delay,function()
			self.wp = wp
			if callback then callback(wp) end
		end)

		return wp
	end
	local function switchTab(openFnc, btnPnl)
		for _,pnl in pairs(list:GetChildren()) do --Disable buttons
			pnl:SetDisabled(true)
		end

		local wp = createWorkPanel(function(wp)
			for _,pnl in pairs(list:GetChildren()) do --Disable buttons
				pnl:SetDisabled(false)
			end

			openFnc(wp, btnPnl)
		end)
	end

	for name,open in SortedPairs(opts) do
		local o = list:Add("DButton")
		AccessorFunc(o,"color","Color")
		o.color = Color(30, 30, 40, 0)
		o:SetTall(40)
		o:SetText(name)
		o:SetTextColor(color_white)
		o:SetFont("nutMediumFont")
		function o:Paint(w,h)
			draw.RoundedBox(0,0,0,w,h,self.color)

			if self == curTab then
				draw.RoundedBox(0,0,0,4,h,color_white)
			end
		end
		function o:OnCursorEntered()
			self:ColorTo(Color(30, 30, 40, 240),0.2)
		end
		function o:OnCursorExited()
			self:ColorTo(Color(30, 30, 40, 0),0.2)
		end

		function o:DoClick()
			if curTab == self then return end --Already in there
			curTab = self
			switchTab(open, self)
		end
	end

	--Resizing list
	list:SetTall(40*table.Count(opts))
	list:CenterVertical(0.4)

	self.icon = self:Add("DHTML")
	self.icon:SetPos(ScrW() - 96, 8)
	self.icon:SetSize(86, 86)
	self.icon:SetHTML([[
		<html>
			<body style="margin: 0; padding: 0; overflow: hidden;">
				<img src="]]..nut.config.get("logo", "http://nutscript.rocks/nutscript.png")..[[" width="86" height="86" />
			</body>
		</html>
	]])
	self.icon:SetToolTip(nut.config.get("logoURL", "http://nutscript.rocks"))

	self.icon.click = self.icon:Add("DButton")
	self.icon.click:Dock(FILL)
	self.icon.click.DoClick = function(this)
		gui.OpenURL(nut.config.get("logoURL", "http://nutscript.rocks"))
	end
	self.icon.click:SetAlpha(0)
	self.icon:SetAlpha(150)

	local x, y = ScrW() * 0.1, ScrH() * 0.3
	local i = 1

	self.buttons = {}
	surface.SetFont("nutMenuButtonFont")

end

function PANEL:playMusic()
	if (nut.menuMusic) then
		nut.menuMusic:Stop()
		nut.menuMusic = nil
	end

	timer.Remove("nutMusicFader")

	local source = nut.config.get("music", ""):lower()

	if (source:find("%S")) then
		local function callback(music, errorID, fault)
			if (music) then
				music:SetVolume(0.5)

				nut.menuMusic = music
				nut.menuMusic:Play()
			else
				MsgC(Color(255, 50, 50), errorID.." ")
				MsgC(color_white, fault.."\n")
			end
		end

		if (source:find("http")) then
			sound.PlayURL(source, "noplay", callback)
		else
			sound.PlayFile("sound/"..source, "noplay", callback)
		end
	end

	for k, v in ipairs(engine.GetAddons()) do
		if (v.wsid == "207739713" and v.mounted) then
			return
		end
	end

	Derma_Query(L"contentWarning", L"contentTitle", L"yes", function()
		gui.OpenURL("http://steamcommunity.com/sharedfiles/filedetails/?id=207739713")
	end, L"no")
end

function PANEL:OnRemove()
	if (nut.menuMusic) then
		local fraction = 1
		local start, finish = RealTime(), RealTime() + 10

		timer.Create("nutMusicFader", 0.1, 0, function()
			if (nut.menuMusic) then
				fraction = 1 - math.TimeFraction(start, finish, RealTime())
				nut.menuMusic:SetVolume(fraction * 0.5)

				if (fraction <= 0) then
					nut.menuMusic:Stop()
					nut.menuMusic = nil

					timer.Remove("nutMusicFader")
				end
			else
				timer.Remove("nutMusicFader")
			end
		end)
	end
end
--vgui.Register("nutCharMenu", PANEL, "EditablePanel")

/*hook.Add("CreateMenuButtons", "nutCharButton", function(tabs)
	tabs["Characters"] = function(panel)
		nut.gui.menu:Remove()
		vgui.Create("nutCharMenu")
	end
end)*/
