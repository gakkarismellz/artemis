ITEM.name = "Flashlight"
ITEM.model = "models/codww2/other/flashlighttl122.mdl"
ITEM.desc = "A regular flashlight with batteries included."
ITEM.price = 30
ITEM.permit = "permit_gen"
ITEM.category = "General"

ITEM:hook("drop", function(item)
	if (item.player:FlashlightIsOn()) then
		item.player:Flashlight(false)
	end
end)

function ITEM:onTransfered()
	local client = self:getOwner()

	if (IsValid(client) and client:FlashlightIsOn()) then
		client:Flashlight(false)
	end
end