ITEM.name = "General Permit"
ITEM.uniqueID = "permit_gen"
ITEM.model = "models/props_c17/paper01.mdl"
ITEM.desc = "A permit that allows one to order general items."