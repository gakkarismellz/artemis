function WIKI:pageEditor(panel, topic)
  local cc = {}

  --Title
  local nutCol = nut.config.get("color")
  cc.PETitle = panel:Add("DLabel")
  cc.PETitle:SetPos(5,5)
  cc.PETitle:SetText("Create New Topic")
  cc.PETitle:SetFont("WB_Large")
  cc.PETitle:SetAlpha(0)
  cc.PETitle:AlphaTo(255,0.3,0.15)
  cc.PETitle:SizeToContents()

  --Content Editor
  cc.CE = panel:Add("DPanel")
  cc.CE:SetSize(panel:GetWide(), panel:GetTall()-50)
  cc.CE:SetPos(0,50)
  function cc.CE:Paint(w,h)
  end

  local lct = {}
  --Topic Title
  cc.titleLabel = cc.CE:Add("DLabel")
  cc.titleLabel:SetText("Topic Title")
  cc.titleLabel:SetPos(10,20)
  cc.titleLabel:SetFont("WB_Small")
  cc.titleLabel:SizeToContents()
  cc.titleLabel:SetTextColor(color_white)

  cc.title = cc.CE:Add("DTextEntry")
  cc.title:SetSize(175,30)
  cc.title:SetPos(cc.titleLabel:GetX()+cc.titleLabel:GetWide()+15, cc.titleLabel:GetY()-cc.title:GetTall()/6)
  function cc.title:Paint(w,h)
    draw.RoundedBox(4,0,0,w,h,color_white)
    self:DrawTextEntryText(color_black,nutCol,color_black)
  end

  --I'm Done Editing
  cc.done = panel:Add("DButton")
  cc.done:SetSize(200, 30)
  cc.done:SetText("Done Editing")
  cc.done:SetFont("WB_Small")
  cc.done:SetColor(color_white)
  cc.done:SetPos(cc.title:GetX() + cc.title:GetWide()+15, 65)
  WB:StyleButton(cc.done, WB:ColorBrighten(BC_NEUTRAL), BC_NEUTRAL, 4, true)
  function cc.done:DoClick()
    local title = cc.title:GetText()
    if not title or title == "" or title == " " then
        self:Flash("Enter a title first", BC_CRITICAL, 1)
      return
    end

    local lct = {}
    for k,v in pairs(cc.lctlist:GetChildren()) do --Building linear content table
      if not v.lct then continue end
      v.lct.ns = {}
      v.lct.ns.half = v.half

      lct[#lct+1] = v.lct
    end

    lct.topicName = title

    --Saving topic
    local filename = cc.title:GetText():lower()
    netstream.Start("saveIGWTopic", filename:Replace(" ", ""), lct)

    --Closing editing
    for k,v in pairs(cc) do
      if isfunction(v) then continue end
      v:Remove()
    end

    --Show old menu section
    for k,v in pairs(panel:GetChildren()) do
      if not v:IsVisible() then
        v:Show()
        v:SetAlpha(255)
      end
    end

    cc.PETitle:Remove()

    --Moving back
    panel.pse:MoveTo(0, 0, 0.2, 0, -1)
  end

  --How to display different types??
  local function displayText(ns, content)
    ns.lct = {
      type = "text",
      content = content
    }

    local function SizeStyleTextDisplay(pnl)
      pnl:SetSize(ns:GetWide()-30, ns:GetTall()-45)
      pnl:SetPos(15,15)
    end

    local rttext
    local function CreateRT(text)
      rttext = ns:Add("RichText")
      SizeStyleTextDisplay(rttext)
      rttext:SetFontInternal("WB_Small")
      rttext:InsertColorChange(255,255,255,255)
      rttext:AppendText(text)
    end
    CreateRT(content)

    --Controls
    local cons = ns:CreateControls()
    cons:AddBtn("Edit Section", function(this)
      rttext:Remove()

      local te = ns:Add("DTextEntry")
      SizeStyleTextDisplay(te)
      te:SetMultiline(true)
      te:SetText(ns.lct.content)
      function te:Paint(w,h)
        draw.RoundedBox(4, 0, 0, w, h, color_white)
        self:DrawTextEntryText(color_black, nutCol, color_black)
      end
      this.normalPaint = this.Paint
      function this:Paint(w,h)
        draw.RoundedBox(4, 0, 0, w, h, Color(0, 120, 255))
      end
      this.te = te
    end, function(this)
      local te = this.te

      CreateRT(te:GetText()) --Update/Recreate text
      ns.lct.content = te:GetText()
      te:Remove() --Remove edit text entry
      this.te = nil

      --Reset normal button behavior
      this.Paint = this.normalPaint
      this:ResetClick()
    end)
    cons:DrawBtns()
  end

  local function displayImage(ns,url,vfiw,vfih)
    ns.lct = {
      type = "image",
      url = url
    }
    ns.noDraw = false
    ns.fiw,ns.fih = vfiw or nil, vfih or nil --Setting in current env
    ns.lct.iw,ns.lct.ih = ns.fiw,ns.fih --Setting on lct

    --Download the image
    local webimage = WebMaterial(url, "smooth")
    webimage:Download()

    --Painting the image
    function ns:PaintOver(w,h)
      local wmat = webimage:GetMaterial()

      if wmat and self.noDraw == false then
        --Draw Image
        local iw = ns.fiw or wmat:Width()
        local ih = ns.fih or wmat:Height()
        surface.SetMaterial(wmat)
        surface.SetDrawColor(255, 255, 255)
        surface.DrawTexturedRect(w/2-iw/2, 0, math.Clamp(iw,iw,panel:GetWide()),ih)

        ns.wmat = wmat
        ns:SetTall(ih+30)
      end
    end

    --Controls
    local cons = ns:CreateControls()
    cons:AddBtn("Set Size", function()
      ns.noDraw = true --Don't draw the image for a sec mate.
      local over = ns:Add("DPanel")
      over:SetSize(ns:GetSize())
      over:Center()

      over.sizex = over:Add("DTextEntry")
      over.sizex:SetSize(45,30)
      over.sizex:SetPos(over:GetWide()/2-over.sizex:GetWide()-15)
      over.sizex:CenterVertical(0.2)
      over.sizex:SetText(ns.fiw or ns.wmat:Width())
      function over.sizex:Paint(w,h)
        draw.RoundedBox(4, 0, 0, w, h, Color(250,250,250))
        self:DrawTextEntryText(Color(0,0,0), nutCol, Color(0,0,0))
      end

      over.sizey = over:Add("DTextEntry")
      over.sizey:SetSize(45,30)
      over.sizey:SetPos(over:GetWide()/2+15)
      over.sizey:CenterVertical(0.2)
      over.sizey:SetText(ns.fih or ns.wmat:Height())
      function over.sizey:Paint(w,h)
        draw.RoundedBox(4, 0, 0, w, h, Color(250,250,250))
        self:DrawTextEntryText(Color(0,0,0), nutCol, Color(0,0,0))
      end

      --Done
      over.done = over:Add("DButton")
      over.done:SetText("Set Image Size")
      over.done:SetSize(180,35)
      over.done:SetColor(color_white)
      over.done:SetFont("WB_Small")
      over.done:CenterVertical(0.8)
      over.done:CenterHorizontal()
      function over.done:DoClick()
        local sx,sy = over.sizex:GetText(), over.sizey:GetText()

        if not sx or sx == "" or not sy or sy == "" then
          return
        end

        ns.fiw = tonumber(sx)
        ns.fih = tonumber(sy)
        ns.lct.iw,ns.lct.ih = ns.fiw,ns.fih
        over:AlphaTo(0,0.2,0,function()
          over:Remove()
          ns.noDraw = false
        end)

        --Re-adding the new sec button
        local c = cc.lctlist:GetChildren()
        c[#c]:Remove()
        timer.Simple(0.5, function()
          cc:newSecBtn()
        end)
      end

      WB:StyleButton(over.done, WB:ColorBrighten(BC_NEUTRAL), BC_NEUTRAL, 4, true)
    end)
    cons:DrawBtns()

    function cons:Think()
      self:SetPos(0,ns:GetTall()-self:GetTall())
    end
  end

  local function displayVideo(ns,url)
    ns.lct = {
      type = "video",
      url = url
    }

    ns:SetTall(ns:GetTall()*2)
    local dhtml = ns:Add("DHTML")
    dhtml:SetSize(500, ns:GetTall()-30)
    function dhtml:Think()
      dhtml:Center()
    end

    local h = '<video style="width:100%; height:100%;" loop muted autoplay><source src="$vid" type="video/webm"></video>'
    dhtml:SetHTML(h:Replace("$vid", url))

    --Default Controls
    local cons = ns:CreateControls()
    cons:DrawBtns()
  end

  local function createNSPanel()
    local ns = cc.lctlist:Add("DPanel")

    --Thinking... about half panels or whatever
    ns.half = false
    ns.dhalfc = false --Double half cancels out
    if hp and hp.half and not hp.dhalfc then
      ns:SetSize(cc.lctlist:GetWide()/2-2, hp:GetTall())
      ns.half = true
      ns.dhalfc = true
    else
      ns:SetSize(cc.lctlist:GetWide(), 150)
    end

    ns:SetAlpha(0) --Disappear!

    function ns:Paint(w,h)
      draw.RoundedBox(4,0,0,w,h,Color(150,150,150,50))
    end

    --Control Buttons
    function ns:CreateControls() --Allows easy creation for conrtol buttons (edit,remove,etc)
      self.conts = self:Add("DPanel")
      self.conts:SetSize(self:GetWide(), 30)
      self.conts:SetPos(0,self:GetTall()-self.conts:GetTall())
      function self.conts:Paint(w,h)
        draw.RoundedBoxEx(4, 0, 0, w, h, Color(20,20,20,30))
      end

      self.conts.scroll = self.conts:Add("DScrollPanel")
      self.conts.scroll:SetSize(self.conts:GetSize())
      self.conts.list = self.conts:Add("DIconLayout")
      self.conts.list:SetSize(self.conts.scroll:GetSize())

      local controlBtns = {}
      function self.conts:AddBtn(text, onClick, onCommitEdit)
        controlBtns[#controlBtns+1] = {
          text = text,
          onClick = onClick or function() end,
          onCommitEdit = onCommitEdit or nil
        }
      end
      function self.conts:DrawBtns()
        for k,v in pairs(controlBtns) do
          local b = self.list:Add("DButton")
          b:SetText(v.text)
          b:SetColor(color_white)
          b:SetTall(self:GetTall())
          b:SetWide(self.list:GetWide()/#controlBtns)
          WB:StyleButton(b, BC_NEUTRAL, Color(115, 115, 115, 100), 4, true)
          local function normalClick(self)
            if v.onCommitEdit then
              v.onClick(self)
              self.DoClick = v.onCommitEdit
            else
              v.onClick(self)
            end
          end
          function b:ResetClick()
            b.DoClick = normalClick
          end
          b.DoClick = normalClick
        end
      end

      --Default Buttons
      self.conts:AddBtn("Split Horizontally", function()
        if not ns.half then
          self.conts:SetAlpha(0)
          ns.half = true
          ns:SizeTo(ns:GetWide()/2-2, ns:GetTall(), 0.2, 0, nil, function()
            self.conts.scroll:SetWide(ns:GetWide())
            self.conts.list:SetWide(self.conts.scroll:GetWide())
            self.conts.list:Clear()
            self.conts:DrawBtns()
            self.conts:AlphaTo(255,0.2,0)
          end)
        end
      end)

      self.conts:AddBtn("Remove Section", function()
        ns:AlphaTo(0,0.3)
        ns:SizeTo(ns:GetWide(), 0, 0.4, 0, nil, function()
          ns:Remove()
        end)
      end)

      return self.conts
    end

    return ns
  end

  --List Layout
  cc.lctscroll = cc.CE:Add("DScrollPanel")
  cc.lctscroll:SetSize(cc.CE:GetWide()-20, cc.CE:GetTall()-60)
  cc.lctscroll:SetPos(10,60)
  cc.lctlist = cc.lctscroll:Add("DIconLayout")
  cc.lctlist:SetSize(cc.lctscroll:GetSize())
  cc.lctlist:SetSpaceY(4)
  cc.lctlist:SetSpaceX(2)

  --New Sections
  function cc:newSecBtn()
    local newsec = cc.lctlist:Add("DButton")
    newsec:SetText("Add New Section")
    newsec:SetTextColor(color_white)
    newsec:SetSize(120,30)
    newsec:CenterHorizontal()
    makeSmoothHover(newsec, Color(0,96,255), Color(0, 86, 245), 4)
    function newsec:DoClick()
      self:AlphaTo(0,0.2,0,function()
        self:Remove()

        local hp = cc.lctlist:GetChildren()[#cc.lctlist:GetChildren()-1] or nil

        --[[CREATING NEW SECTION]]--
        local ns = createNSPanel()
        ns:AlphaTo(255,0.2,0,function()
          local function contentEditing(type) --Changes input type relative to type of content
            --Confirm Edit
            local commitBtn = ns:Add("DButton")
            commitBtn:SetText("Commit")
            commitBtn:SetTextColor(Color(0,0,0))
            function commitBtn:Think()
              commitBtn:SetPos(0,ns:GetTall()-self:GetTall()-5)
              commitBtn:CenterHorizontal()
            end
            function commitBtn:Paint(w,h)
              if self:GetDisabled() then
                draw.RoundedBox(4,0,0,w,h,Color(249, 63, 63))
              else
                draw.RoundedBox(4,0,0,w,h,Color(255,255,255))
              end
            end

            --TEXT HANDLING--
            if type == "text" then
              editor = ns:Add("DTextEntry")
              editor:SetSize(ns:GetWide()-30, ns:GetTall()-50)
              editor:SetPos(0,15)
              editor:CenterHorizontal()
              editor:SetMultiline(true)
              editor:SetAlpha(0)
              editor:AlphaTo(255,0.2,0)
              editor.OnKeyCodePressed = ns.HookKeyPress

              function editor:Paint(w,h)
                draw.RoundedBox(4,0,0,w,h,color_white)
                self:DrawTextEntryText(color_black,nutCol,color_black)
              end
              function editor:Commit()
                displayText(ns, self:GetText())

                cc:newSecBtn() --Show New Section Button
                self:Remove() --Remove Editor
              end
            end

            --IMAGE HANDLING--
            if type == "img" then
              editor = ns:Add("DTextEntry")
              editor:SetSize(150,30)
              editor:Center()
              function editor:Paint(w,h)
                draw.RoundedBox(4,0,0,w,h,color_white)
                self:DrawTextEntryText(color_black,nutCol,color_black)
              end
              function editor:Think()
                if not commitBtn then
                  return
                end
                local val = self:GetText()
                if val:find(".jpeg") or val:find(".png") or val:find(".jpg") then
                  commitBtn:SetText("Commit")
                  commitBtn:SetDisabled(false)
                else
                  commitBtn:SetDisabled(true)
                  commitBtn:SetText("URL must be a web image url finishing in .png/.jpg")
                  commitBtn:SizeToContents()
                  commitBtn:SetSize(commitBtn:GetWide()+20, 30)
                end
              end
              function editor:Commit()
                displayImage(ns, self:GetText())
                self:AlphaTo(0,0.2,0,function() self:Remove() end)

                cc:newSecBtn()
              end
            end

            --[[VIDEO HANDLING]]--
            if type == "video" then
              local hint = ns:Add("DLabel")
              hint:SetText("Enter WebM Link (http://example.com/something.webm)")
              hint:SetFont("WB_Small")
              hint:SizeToContents()
              hint:SetColor(color_white)
              hint:CenterHorizontal()
              hint:CenterVertical(0.2)

              editor = ns:Add("DTextEntry")
              editor:SetSize(150,30)
              editor:Center()
              function editor:Paint(w,h)
                draw.RoundedBox(4,0,0,w,h,color_white)
                self:DrawTextEntryText(color_black,nutCol,color_black)
              end
              function editor:Commit()
                displayVideo(ns, self:GetText())
                self:Remove()
                hint:Remove()
                cc:newSecBtn()
              end
            end

            --Commit DoClick
            function commitBtn:DoClick()
              editor:Commit()
              self:AlphaTo(0,0.2,0,function() self:Remove() end)
            end
          end

          --Show content options
          local bscroll = ns:Add("DScrollPanel")
          bscroll:SetSize(153*3, 30)
          bscroll:Center()
          local blist = bscroll:Add("DIconLayout")
          blist:SetSize(bscroll:GetSize())
          blist:SetSpaceX(3)

          local function addOpt(name)
            local o = blist:Add("DButton")
            o:SetText(name)
            o:SetFont("WB_Small")
            o:SetTextColor(color_black)
            o:SetSize(150, blist:GetTall())
            makeSmoothHover(o, Color(255,255,255,200), Color(245,245,245,200))
            return o
          end

          --Creating content options
          blist.text = addOpt("Text")
          blist.img = addOpt("Image")
          blist.video = addOpt("Video")

          local function removeBtns()
            bscroll:AlphaTo(0,0.2,0,function() bscroll:Remove() end)
          end

          function blist.text:DoClick()
            removeBtns()
            contentEditing("text")
          end
          function blist.img:DoClick()
            removeBtns()
            contentEditing("img")
          end
          function blist.video:DoClick()
            removeBtns()
            contentEditing("video")
          end
        end)
      end)
    end
  end

  --Displaying topic edit panels
  if topic then
    for k,v in pairs(topic) do
      if k == "topicName" then
        cc.title:SetText(v)
        continue
      end

      local ns = createNSPanel()
      ns:AlphaTo(255,0.2)

      if v.ns.half then
        ns:SetWide(ns:GetWide()/2-2)
        ns.half = true
      end

      --Display right content
      if v.type == "text" then
        displayText(ns, v.content)
      elseif v.type == "image" then
        displayImage(ns, v.url, v.iw or nil, v.ih or nil)
      elseif v.type == "video" then
        displayVideo(ns, v.url)
      end
    end
  end

  cc:newSecBtn()
end
