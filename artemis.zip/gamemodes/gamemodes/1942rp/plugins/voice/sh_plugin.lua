PLUGIN.name = "DoD Voice Lines"
PLUGIN.author = "Chancer"
PLUGIN.desc = "Allows certain factions to use DoD voice lines."

nut.voice = {}
nut.voice.list = {}
nut.voice.checks = nut.voice.checks or {}
nut.voice.chatTypes = {}

function nut.voice.defineClass(class, onCheck, onModify, global)
	nut.voice.checks[class] = {class = class:lower(), onCheck = onCheck, onModify = onModify, isGlobal = global}
end

function nut.voice.getClass(client)
	local definitions = {}

	for k, v in pairs(nut.voice.checks) do
		if (v.onCheck(client)) then
			definitions[#definitions + 1] = v
		end
	end

	return definitions
end

function nut.voice.register(class, key, replacement, source, max)
	class = class:lower()
	
	nut.voice.list[class] = nut.voice.list[class] or {}
	nut.voice.list[class][key:lower()] = {replacement = replacement, source = source}
end

function nut.voice.getVoiceList(class, text, delay)
	local info = nut.voice.list[class]
	
	if (!info) then
		return
	end
	
	if(!info[text]) then
		return
	end

	local output = {}
	local original = string.Explode(" ", text)
	local exploded = string.Explode(" ", text:lower())
	local phrase = ""
	local skip = 0
	local current = 0

	max = max or 5

	for k, v in ipairs(exploded) do
		if (k < skip) then
			continue
		end

		if (current < max) then
			local i = k
			local key = v

			local nextValue, nextKey

			while (true) do
				i = i + 1
				nextValue = exploded[i]
				
				if (!nextValue) then
					break
				end

				nextKey = key.." "..nextValue

				if (!info[nextKey]) then
					i = i + 1

					local nextValue2 = exploded[i]
					local nextKey2 = nextKey.." "..(nextValue2 or "")

					if (!nextValue2 or !info[nextKey2]) then
						i = i - 1

						break
					end

					nextKey = nextKey2
				end

				key = nextKey
			end

			if (info[key]) then			
				local source = info[key].source
				
				if (type(source) == "table") then
					source = table.Random(source)
				else
					source = tostring(source)
				end
				
				output[#output + 1] = {source, delay or 0.1}
				phrase = phrase..info[key].replacement.." "
				skip = i
				current = current + 1

				continue
			end
		end

		phrase = phrase..original[k].." "
	end
	
	if (phrase:sub(#phrase, #phrase) == " ") then
		phrase = phrase:sub(1, -2)
	end

	return #output > 0 and output or nil, phrase
end

--[[
	Define your voice classes here. The function goes:
	nut.voice.defineClass(class, onCheck(client)[, onModify(client, sounds)])
	Class is the same class that starts the nut.voice.register
	It is case-insensitive. The onCheck passes the player trying
	to use the class. Return true to allow them to use the class.
--]]

netstream.Hook("voicePlay", function(sounds, volume, index)
	if (index) then
		local client = Entity(index)

		if (IsValid(client)) then
			nut.util.emitQueuedSounds(client, sounds, nil, nil, volume)
		end
	else
		nut.util.emitQueuedSounds(LocalPlayer(), sounds, nil, nil, volume)
	end
end)

function PLUGIN:PlayerMessageSend(client, chatType, message, anonymous, receivers)
	if (!nut.voice.chatTypes[chatType]) then
		return
	end

	for _, definition in ipairs(nut.voice.getClass(client)) do
		local sounds, message = nut.voice.getVoiceList(definition.class, message)

		if (sounds) then
			local volume = 80

			if (chatType == "w") then
				volume = 60
			elseif (chatType == "y") then
				volume = 150
			end
			
			if (definition.onModify) then
				if (definition.onModify(client, sounds, chatType, message) == false) then
					continue
				end
			end

			if (definition.isGlobal) then
				netstream.Start(nil, "voicePlay", sounds, volume)
			else
				netstream.Start(nil, "voicePlay", sounds, volume, client:EntIndex())

				if (chatType == "radio" and receivers) then
					for k, v in pairs(receivers) do
						if (receivers == client) then
							continue
						end

						netstream.Start(nil, "voicePlay", sounds, volume * 0.5, v:EntIndex())
					end
				end
			end

			return message
		end
	end
end


-- What type of chat modes support voice commands:
nut.voice.chatTypes["ic"] = true
nut.voice.chatTypes["w"] = true
nut.voice.chatTypes["y"] = true
nut.voice.chatTypes["radio"] = true

nut.voice.defineClass("soldier", function(client)
	local char = client:getChar()
	local soldierFactions = {}
		
		soldierFactions[FACTION_heer or 99] = true
		soldierFactions[FACTION_luftwaffe or 99] = true
		soldierFactions[FACTION_okw or 99] = true
		soldierFactions[FACTION_police or 99] = true
		soldierFactions[FACTION_rsha or 99] = true
		soldierFactions[FACTION_waffen or 99] = true
		soldierFactions[FACTION_ssver or 99] = true
		soldierFactions[FACTION_ssa or 99] = true
		soldierFactions[FACTION_sicher or 99] = true
		soldierFactions[FACTION_waffen or 99] = true
		--soldierFactions[FACTION_SURVIVOR or 99] = true

	if(soldierFactions[char:getFaction()]) then
		return true
	else
		return false
	end
end)


--[[
-- Example of citizen class that requires the ciitzen to have 'y' flag.
nut.voice.defineClass("citizen", function(client)
	return client:getChar():hasFlags("y")
end)
--]]

nut.voice.register("soldier", "yes sir!", "Yes, sir!", "ger_yessir.wav")
nut.voice.register("soldier", "no!", "No!", "ger_negative.wav")
nut.voice.register("soldier", "all clear", "All Clear!", "ger_yessir3.wav")
nut.voice.register("soldier", "understood", "I understand!", "ger_yessir2.wav")
nut.voice.register("soldier", "stick together", "Stick together!", "ger_sticktogether.wav")
nut.voice.register("soldier", "covering fire", "Covering fire!", "ger_coveringfire.wav")
nut.voice.register("soldier", "grenade", "Grenade!", "ger_grenadein.wav")
nut.voice.register("soldier", "good shot", "Good shot!", "ger_niceshot.wav")
nut.voice.register("soldier", "thanks", "Thanks!", "ger_thanks.wav")
nut.voice.register("soldier", "drop weapons", "Drop your weapons!", "ger_dropweapons.wav")
nut.voice.register("soldier", "flank left", "Unit, flank left!", "ger_flankleft.wav")
nut.voice.register("soldier", "flank right", "Unit, flank right!", "ger_flankright.wav")
nut.voice.register("soldier", "cease fire", "Cease fire!", "ger_ceasefire.wav")
nut.voice.register("soldier", "backup", "I need backup!", "ger_backup.wav")
nut.voice.register("soldier", "sniper", "Sniper!", "ger_sniper.wav")
nut.voice.register("soldier", "fire left", "We're under attack from the left!", "ger_incomingfireleft.wav")
nut.voice.register("soldier", "fire right", "We're under attack from the right!", "ger_incomingfireright.wav")
nut.voice.register("soldier", "area clear", "Area clear!", "ger_areaclear.wav")
nut.voice.register("soldier", "behind us", "They're behind us!", "ger_enemybehind2.wav")
nut.voice.register("soldier", "need ammo", "I need ammo!", "ger_needammo2.wav")
nut.voice.register("soldier", "go!", "Go, go, go!", "ger_gogogo2.wav")
nut.voice.register("soldier", "cover", "Take cover!", "ger_takecover.wav")
nut.voice.register("soldier", "spread out", "Soldiers, spread out!", "ger_spreadout.wav")
nut.voice.register("soldier", "ready", "Ready to go!", "ger_prepare.wav")
nut.voice.register("soldier", "secure", "Objective is secure!", "ger_objectivesecure.wav")
nut.voice.register("soldier", "move up", "Move up, soldiers!", "ger_moveupmg3.wav")
nut.voice.register("soldier", "move out", "Move out, men!", "ger_moveout.wav")
nut.voice.register("soldier", "mg ahead", "Machine gun ahead!", "ger_mgahead.wav")
nut.voice.register("soldier", "medic", "Medic!", "ger_medic2.wav")
nut.voice.register("soldier", "hold position", "Hold this position!", "ger_holdposition.wav")
nut.voice.register("soldier", "fall back", "Fall back!", "ger_fallback.wav")
nut.voice.register("soldier", "enemy ahead", "Enemy ahead!", "ger_enemyahead.wav")
nut.voice.register("soldier", "change position", "Change position!", "ger_changeposition.wav")
nut.voice.register("soldier", "ready to attack", "Ready to attack, let's go!", "ger_attack4.wav")
nut.voice.register("soldier", "we have him", "We have him, go ahead!", "ger_wegothim.wav")

