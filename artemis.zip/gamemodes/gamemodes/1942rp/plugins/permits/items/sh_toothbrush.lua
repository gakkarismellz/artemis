ITEM.name = "Toothbrush"
ITEM.model = "models/props/cs_militia/toothbrushset01.mdl"
ITEM.width = 1
ITEM.height = 1
ITEM.price = 1
ITEM.permit = "permit_gen"
ITEM.category = "General"
