local PLUGIN = PLUGIN or {}
local charPos = Vector(-7318.651367, 5527.993164, 7969.031250) -- setpos -7318.651367 5527.993164 8032.031250;setang 13.138625 -93.782852 0.000000
local charAng = Angle(0, -90, 0.000000)
local camPos = Vector(-7324.507813, 5361.954102, 8038.031250) -- setpos -7324.507813 5361.954102 8038.031250;setang 16.336000 87.840889 0.000000
local camAng = Angle(16.336000, 87.840889, 0.000000)

PLUGIN.catButtonColor = Color(55,55,55)
PLUGIN.listButtonColor = Color(45,45,45)
PLUGIN.pMdl = PLUGIN.pMdl or nil

local list
local nutcol = nut.config.get("color") or nil
local receipt = {}

function PLUGIN.showBorder(w,h,green)
  local nutcol = nutcol or nut.config.get("color")
  green = green or false
  local lh = 1
  if green then
    surface.SetDrawColor(Color(60,220,60))
  else
    surface.SetDrawColor(nutcol)
  end

  surface.DrawRect(0,0,w,lh)
  surface.DrawRect(w-lh,0,lh,h)
  surface.DrawRect(0,0,lh,h-lh)
  surface.DrawRect(0,h-lh,w,lh)
end

function PLUGIN:getClothingConfig()
  for k,v in pairs(CLOTHING) do
    if self.pMdl:GetModel():lower():find(k:lower()) then
      return v
    end
  end
end

--Function to spawn preview
function PLUGIN:SetDefaultPreviewCos()
  --Setting the bodygroups from the player to model
  local abg = {}
  for k,v in pairs(LocalPlayer():GetBodyGroups()) do
    if v.id > 0 then
      self.pMdl:SetBodygroup(v.id, LocalPlayer():GetBodygroup(v.id))
    end
  end
  self.pMdl:SetSkin(LocalPlayer():GetSkin()) --Get and set skin
  self.pMdl:SetModel(LocalPlayer():GetModel())
  self.pMdl:ResetSequence(2)
end

local function spawnPreview(charPos, charAng)
  local ply = LocalPlayer()
  local pMdl = ClientsideModel(LocalPlayer():GetModel())
  pMdl:ResetSequence(2)
  pMdl:SetSolid(SOLID_VPHYSICS)
	pMdl:SetMoveType(MOVETYPE_VPHYSICS)

  --Setting pos and ang
  pMdl:SetPos(charPos)
  pMdl:SetAngles(charAng)

  PLUGIN.pMdl = pMdl
  PLUGIN:SetDefaultPreviewCos()
end

--Cam lerp to the good cam pos
local function transitionToCamPos(camPos, camAng)
  local ply = LocalPlayer()
  local startPos = LocalPlayer():EyePos()
  local startAng = ply:GetAngles()
  local qa = ANIM:CreateQuickAnim(2, startPos, startAng, camPos, camAng)
  qa:Start()

  hook.Add("CalcView", "ClothesShopCam", function(ply, pos, angles, fov)
    local view = {}
    local posLerp, angLerp = qa:Think()

  	view.origin = posLerp
  	view.angles = angLerp
  	view.fov = fov
  	view.drawviewer = true

    return view
  end)
end


local function openBGShop()
  local nutcol = nut.config.get("color")
  transitionToCamPos(camPos, camAng) --Custom camera angle
  spawnPreview(charPos, charAng) --The playermodel preview

  local frame = vgui.Create("WolfFrame")
  frame:SetSize(ScrW()/3,ScrH())
  frame:MakePopup()
  frame:SetPos(0,0)
  frame:SetTitle("Clothing Shop")
  function frame:OnRemove()
    hook.Remove("CalcView", "ClothesShopCam") --Remove calc view on exit
    PLUGIN.pMdl:Remove() --Remove Preview Model
  end
  local wp = frame:GetWorkPanel()

  local tabs = {}
  tabs.Shop = PLUGIN.ShopTab
  tabs.Wardrobe = PLUGIN.WardrobeTab

  --Displaying tabs
  local function getTabPanel()
    if wp.tpnl and IsValid(wp.tpnl) then
      wp.tpnl:Remove()
    end

    wp.tpnl = wp:Add("DPanel")
    wp.tpnl:SetSize(wp:GetWide(), wp:GetTall()-wp.scroll:GetTall())
    wp.tpnl:SetPos(0,wp.scroll:GetTall())

    return wp.tpnl
  end

  local selTab
  PLUGIN.selTabName = "Shop"
  wp.scroll = wp:Add("WScrollList")
  wp.scroll:SetSize(wp:GetWide(), 40)
  local list = wp.scroll:GetList(0,0)
  for k,v in pairs(tabs) do
    local tab = list:Add("WButton")
    tab:SetText(k)
    tab:SetSize(list:GetWide() / 2, wp.scroll:GetTall())
    tab:SetAccentColor(Color(35,35,35))
    tab.round = 0
    function tab:PaintOver(w,h)
      if selTab == self then
        surface.SetDrawColor(nutcol)
        surface.DrawRect(0,h-2,w,2)
      end
    end
    function tab:DoClick()
      if hook.Run("Clothing.canSwitchTab", tab, k) == false then return end

      self:GInflate(Color(100,100,100,20), true)
      timer.Simple(0.2, function()
        local tp = getTabPanel()
        local tg = group()
        v(tp, tg)

        PLUGIN.selTabName = k

        tg:FadeIn()
      end)

      selTab = self
    end

    --Select default tab
    if k == "Shop" then
      tab:DoClick()
    end
  end
end

netstream.Hook("openBGShop", openBGShop)